
import json

def microstate_coverage(labels, states=(0, 1, 2)):
    labeled = [x for x in labels if x >= 0]
    n = len(labeled)
    coverage = {}
    for s in states:
        c = sum(1 for x in labeled if x == s)
        coverage[str(s)] = round(100.0 * c / n, 4) if n else 0.0
    return coverage, n

if __name__ == "__main__":
    with open("/input/request.json") as f:
        req = json.load(f)
    labels = req["input"]["labels"]
    coverage, n = microstate_coverage(labels)
    result = {"coverage_pct": coverage, "n_labeled": n}
    with open("/workspace/result.json", "w") as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result))
