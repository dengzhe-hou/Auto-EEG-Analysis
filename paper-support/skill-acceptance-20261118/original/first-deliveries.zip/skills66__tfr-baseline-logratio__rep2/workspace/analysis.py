
import json
import numpy as np
from mne.time_frequency import tfr_array_morlet

req = json.load(open("/input/request.json"))
inp = req["input"]
sfreq = float(inp["sfreq"])
tmin = float(inp["tmin"])
E = np.array(inp["epochs_uV"], dtype=float)  # (trials, channels, times)
sample_indices = [int(i) for i in inp["sample_indices"]]
channels = inp["channels"]

freqs = np.array([10.0])
n_cycles = np.array([5.0])

# single-trial complex-valued TFR via Morlet, zero-mean wavelets, decim=1
# output: (trials, channels, freqs, times)
tfr_power = tfr_array_morlet(
    E, sfreq=sfreq, freqs=freqs, n_cycles=n_cycles,
    output="power", zero_mean=True, decim=1, n_jobs=1,
)
# average across trials to obtain mean power per channel
power = tfr_power.mean(axis=0)[:, 0, :]  # (channels, times)

times = tmin + np.arange(E.shape[-1]) / sfreq

# baseline window inclusive [-0.5, -0.125] s
bmask = (times >= -0.5) & (times <= -0.125)
base = power[:, bmask].mean(axis=1)  # mean baseline power per channel

ratio = power / base[:, None]
values_full = np.log10(ratio)

values = []
for ch in range(E.shape[1]):
    values.append([float(values_full[ch, s]) for s in sample_indices])
times_s = [float(times[s]) for s in sample_indices]

result = {"values": values, "times_s": times_s, "channels": channels,
          "sample_indices": sample_indices}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result)[:1000])
