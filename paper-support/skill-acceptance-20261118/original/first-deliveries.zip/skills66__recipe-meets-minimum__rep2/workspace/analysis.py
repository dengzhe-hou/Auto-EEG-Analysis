
import json

with open("/input/request.json") as f:
    req = json.load(f)["input"]

RECIPE = {
    "version": "v0.1.0",
    "min_channels": 16,
    "min_sfreq": 200,
    "min_trials_per_condition": 30,
    "required_markers": ["stimulus/related", "stimulus/unrelated"],
}

counts = req.get("marker_counts", {})
missing = sorted(m for m in RECIPE["required_markers"] if m not in counts)
insufficient = sorted(
    m for m in RECIPE["required_markers"]
    if m in counts and counts[m] < RECIPE["min_trials_per_condition"]
)
channels_ok = req.get("channel_count", 0) >= RECIPE["min_channels"]
sfreq_ok = req.get("sfreq", 0) >= RECIPE["min_sfreq"]
eligible = channels_ok and sfreq_ok and not missing and not insufficient

result = {
    "eligible": eligible,
    "missing_markers": missing,
    "insufficient_present_markers": insufficient,
    "recipe_version": RECIPE["version"],
}
os.makedirs("/workspace", exist_ok=True)
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
