
import json
import numpy as np
from scipy.signal import get_window, welch

req = json.load(open("/input/request.json"))["input"]
x = np.asarray(req["data_uV"], dtype=float)
fs = float(req["sfreq"])
nperseg = int(req["n_per_seg"])
nfft = int(req["n_fft"])
noverlap = int(req["n_overlap"])

# periodic Hann, demeaned segments, mean over segments, one-sided, V^2/Hz scaling
win = get_window("hann", nperseg, fftbins=True)
f, pxx = welch(x, fs=fs, window=win, nperseg=nperseg, noverlap=noverlap,
               nfft=nfft, detrend="constant", return_onesided=True,
               scaling="density", average="mean")

band_b = (f >= 15) & (f <= 30)
band_t = (f >= 2) & (f <= 40)
beta_fraction = float(pxx[band_b].sum() / pxx[band_t].sum())

result = {"beta_fraction": beta_fraction}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
