import json, numpy as np
req = json.load(open("/input/request.json"))["input"]
chs = req["channels"]; X = np.array(req["signal"], dtype=float)
idx = {c:i for i,c in enumerate(chs)}
pairs = [("Fz","Cz"),("Fz","Pz"),("Cz","Pz")]
edges = []
for a,b in pairs:
    r = np.corrcoef(X[idx[a]], X[idx[b]])[0,1]
    edges.append({"pair": f"{a}-{b}", "r": float(r)})
json.dump({"edges": edges}, open("/workspace/result.json","w"), indent=2)
print(edges)
