Saved /workspace/analysis.py (executed) and /workspace/result.json.

result.json contains:
- channel_names: ["Pz", "Fz"] (requested order)
- samples_uV: 2 × 78 array, cropped to samples [45, 123) of the original recording, with no other processing.
