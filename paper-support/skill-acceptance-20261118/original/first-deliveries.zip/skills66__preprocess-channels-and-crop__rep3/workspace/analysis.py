
import json
import numpy as np

req = json.load(open('/input/request.json'))
inp = req['input']
raw = np.array(inp['raw_uV'], dtype=float)
names = inp['names']
pick = inp['pick']
start, stop = inp['samples']

idx = [names.index(ch) for ch in pick]
sub = raw[idx, start:stop]

result = {
    "samples_uV": sub.tolist(),
    "channel_names": list(pick),
}
with open('/workspace/result.json', 'w') as f:
    json.dump(result, f)
print("shape", sub.shape)
