
import json, os
import numpy as np
from scipy import stats

req = json.load(open('/input/request.json'))
inp = req['input']
a = np.asarray(inp['group_a'], float)
b = np.asarray(inp['group_b'], float)

# Two-sided independent Welch t-test (unequal variances), participant-level values
res = stats.ttest_ind(a, b, equal_var=False, alternative='two-sided')
out = {
    "statistic": float(res.statistic),
    "p_value": float(res.pvalue),
    "n_per_group": [int(len(a)), int(len(b))],
}
os.makedirs('/workspace', exist_ok=True)
json.dump(out, open('/workspace/result.json', 'w'), indent=2)
print(json.dumps(out, indent=2))
