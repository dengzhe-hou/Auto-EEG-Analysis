import json

def decide(req):
    deps = req["dependencies"]
    status = req["status"]
    reused, runnable, blocked = [], [], []
    passed = lambda s: status.get(s) == "passed"
    for stage in sorted(deps):
        st = status.get(stage, "pending")
        if st == "passed":
            reused.append(stage)
        elif st == "failed":
            blocked.append(stage)
        else:
            if all(passed(d) for d in deps[stage]):
                runnable.append(stage)
            else:
                blocked.append(stage)
    return {"reused": sorted(reused), "runnable": sorted(runnable), "blocked": sorted(blocked)}

if __name__ == "__main__":
    req = json.load(open("/input/request.json"))["input"]
    result = decide(req)
    json.dump(result, open("/workspace/result.json", "w"), indent=2)
    print(json.dumps(result))
