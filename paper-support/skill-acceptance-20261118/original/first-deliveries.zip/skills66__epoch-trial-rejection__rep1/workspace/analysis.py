
import json
import numpy as np
import mne

req = json.load(open("/input/request.json"))
inp = req["input"]

data_uV = np.array(inp["raw_uV"], dtype=float)
data_V = data_uV * 1e-6
ch_names = inp["channel_names"]
sfreq = float(inp["sfreq"])
info = mne.create_info(ch_names=ch_names, sfreq=sfreq, ch_types="eeg")
raw = mne.io.RawArray(data_V, info, verbose=False)

events = np.array(inp["events"], dtype=int)
event_id = inp["event_id"]
tmin = float(inp["tmin"])
tmax = float(inp["tmax"])
baseline = inp["baseline"]
if baseline is not None:
    baseline = tuple(baseline)
reject = None
if inp.get("reject_peak_to_peak_uV") is not None:
    reject = dict(eeg=float(inp["reject_peak_to_peak_uV"]) * 1e-6)

epochs = mne.Epochs(raw, events, event_id=event_id, tmin=tmin, tmax=tmax,
                    baseline=baseline, reject=reject, preload=True, verbose=False)

n_total = len(events)
n_retained = len(epochs)
n_dropped = n_total - n_retained
retained_event_samples = [int(s) for s in epochs.events[:, 0]]
times_s = [float(t) for t in epochs.times]

epochs.save("/workspace/check-epo.fif", overwrite=True, verbose=False)

result = {
    "retained_event_samples": retained_event_samples,
    "times_s": times_s,
    "n_dropped": n_dropped,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps({"n_retained": n_retained, "n_dropped": n_dropped,
                  "retained_event_samples": retained_event_samples,
                  "n_times": len(times_s)}))
