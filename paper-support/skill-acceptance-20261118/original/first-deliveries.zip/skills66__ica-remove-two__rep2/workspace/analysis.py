
import json, numpy as np

req = json.load(open("/input/request.json"))["input"]
X = np.array(req["channel_data_uV"], dtype=float)
W = np.array(req["unmixing"], dtype=float)
A = np.array(req["mixing"], dtype=float)
exclusions = [int(i) for i in req["approved_exclusions"]]

# Apply fixed decomposition: sources = W X, zero approved components, reconstruct = A S
S = W @ X
S_clean = S.copy()
S_clean[exclusions, :] = 0.0
cleaned = A @ S_clean

result = {
    "cleaned_uV": cleaned.tolist(),
    "applied_exclusions": exclusions,
}
json.dump(result, open("/workspace/result.json", "w"))
