
import json, numpy as np
from pathlib import Path
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

req = json.load(open("/input/request.json"))["input"]
X = np.array(req["features"], dtype=float)   # (trial, time, feature)
y = np.array(req["labels"])
g = np.array(req["groups"])
n, T, F = X.shape
preds = np.zeros((n, T), dtype=int)
acc = np.zeros(T)
for t in range(T):
    for grp in np.unique(g):
        te = g == grp
        tr = ~te
        clf = make_pipeline(StandardScaler(),
                            LogisticRegression(C=1, solver="liblinear",
                                               random_state=42, max_iter=1000))
        clf.fit(X[tr, t, :], y[tr])
        preds[te, t] = clf.predict(X[te, t, :])
    acc[t] = np.mean(preds[:, t] == y)
chance = float(max(np.bincount(y)) / len(y))
result = {"predictions": preds.tolist(),
          "accuracy": acc.tolist(),
          "chance_accuracy": chance}
Path("/workspace").mkdir(exist_ok=True)
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print("accuracy", acc.tolist(), "chance", chance)
