{"roi_mean_uV": 7.50097645985171, "n_window_samples": 21, "n_condition_trials": [2, 3]}
