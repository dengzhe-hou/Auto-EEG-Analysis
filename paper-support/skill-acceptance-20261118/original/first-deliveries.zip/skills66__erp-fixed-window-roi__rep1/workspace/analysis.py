
import json, numpy as np, mne
req = json.load(open("/input/request.json"))["input"]
X = np.array(req["epochs_uV"], dtype=float)
labels = np.array(req["labels"])
ch = req["channel_names"]; sfreq = req["sfreq"]; tmin = req["tmin"]
# MNE expects Volts
X_V = X * 1e-6
info = mne.create_info(ch, sfreq, ch_types="eeg")
epochs = mne.EpochsArray(X_V, info, tmin=tmin, verbose=False)
evA = epochs[labels == "A"].average()
evB = epochs[labels == "B"].average()
diff = mne.combine_evoked([evB, evA], weights=[1, -1])
diff.comment = "B-A"
mne.write_evokeds("/workspace/check-ave.fif", [diff], verbose=False)
data_uV = diff.data * 1e6
times = diff.times
mask = (times >= 0.1 - 1e-9) & (times <= 0.3 + 1e-9)
roi_idx = [ch.index("Cz"), ch.index("Pz")]
roi_mean = float(np.mean(data_uV[roi_idx][:, mask]))
n_win = int(mask.sum())
n_A = int(np.sum(labels == "A")); n_B = int(np.sum(labels == "B"))
result = {"roi_mean_uV": roi_mean, "n_window_samples": n_win, "n_condition_trials": [n_A, n_B]}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(result)
