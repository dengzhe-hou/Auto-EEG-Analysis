
import json, os, sys
sys.path.insert(0, '/input/bids-deps')
import numpy as np
import mne
from mne_bids import BIDSPath, write_raw_bids, read_raw_bids

req = json.load(open("/input/request.json"))
inp = req["input"]
ch_names = inp["channel_names"]
ch_types = inp["types"]
sfreq = float(inp["sfreq"])
data = np.array(inp["data_uV"], dtype=float) * 1e-6  # uV -> V
info = mne.create_info(ch_names, sfreq, ch_types)
raw = mne.io.RawArray(data, info, first_samp=int(inp["first_samp"]), verbose=False)
raw.info["bads"] = list(inp["bads"])
raw.set_meas_date(None)

ev = np.array(inp["events_original_samples"], dtype=int)
# annotations from events: onset in seconds relative to first_samp
onsets = (ev[:, 0] - raw.first_samp) / sfreq
id_to_desc = {v: k for k, v in inp["event_id"].items()}
descs = [id_to_desc[int(c)] for c in ev[:, 2]]
raw.set_annotations(mne.Annotations(onset=onsets, duration=np.zeros(len(onsets)), description=descs))

bids_root = "/workspace/bids"
os.makedirs(bids_root, exist_ok=True)
bids_path = BIDSPath(subject="01", task="check", root=bids_root, datatype="eeg")
write_raw_bids(raw, bids_path, allow_preload=True, format="BrainVision", overwrite=True, verbose=False)
import glob
for jf in glob.glob(os.path.join(bids_root, "sub-01", "eeg", "*_eeg.json")):
    meta = json.load(open(jf))
    meta["EEGReference"] = "synthetic common reference"
    meta["PowerLineFrequency"] = inp["line_freq"]
    json.dump(meta, open(jf, "w"), indent=2)

raw2 = read_raw_bids(bids_path, verbose=False)
ann = raw2.annotations
rel = []
for onset, desc in zip(ann.onset, ann.description):
    rel.append(int(round(onset * raw2.info["sfreq"])))
result = {
    "relative_event_samples": rel,
    "bad_channels": list(raw2.info["bads"]),
    "sfreq": float(raw2.info["sfreq"]),
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
