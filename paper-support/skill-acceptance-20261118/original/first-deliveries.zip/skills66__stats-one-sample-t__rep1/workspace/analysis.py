import json
from scipy import stats

with open("/input/request.json") as f:
    req = json.load(f)
x = req["input"]["contrasts"]

t, p = stats.ttest_1samp(x, popmean=0.0, alternative="two-sided")
df = len(x) - 1

result = {"t": float(t), "df": int(df), "p_two_sided": float(p)}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(result)
