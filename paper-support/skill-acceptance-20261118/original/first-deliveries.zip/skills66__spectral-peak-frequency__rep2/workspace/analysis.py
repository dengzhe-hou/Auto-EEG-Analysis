
import json
import numpy as np
from scipy.signal import get_window

req = json.load(open("/input/request.json"))
inp = req["input"]
x_uV = np.asarray(inp["data_uV"], dtype=float)
sfreq = float(inp["sfreq"])
n_per_seg = int(inp["n_per_seg"])
n_fft = int(inp["n_fft"])
n_overlap = int(inp["n_overlap"])

step = n_per_seg - n_overlap
win = get_window("hann", n_per_seg, fftbins=True)  # periodic Hann
scale = sfreq * np.sum(win ** 2)

segs = []
start = 0
while start + n_per_seg <= len(x_uV):
    seg = x_uV[start:start + n_per_seg]
    seg = seg - seg.mean()  # segment demeaning
    segs.append(seg)
    start += step

periodograms = []
for seg in segs:
    X = np.fft.rfft(seg * win, n=n_fft)
    P = (np.abs(X) ** 2) / scale
    P[1:-1] *= 2.0  # one-sided, excluding DC and Nyquist
    periodograms.append(P)
psd = np.mean(periodograms, axis=0)  # uV^2/Hz
freqs = np.fft.rfftfreq(n_fft, d=1.0 / sfreq)

mask = (freqs >= 8) & (freqs <= 12)
idx = np.where(mask)[0][np.argmax(psd[mask])]
result = {
    "alpha_peak_hz": float(freqs[idx]),
    "psd_uV2_per_hz": float(psd[idx]),
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
