
import json, numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

req = json.load(open("/input/request.json"))["input"]
X = np.array(req["features"], dtype=float)   # trials x channels x time
y = np.array(req["labels"])
groups = np.array(req["groups"])
n_trials, n_ch, n_t = X.shape

preds = np.zeros((n_trials, n_t), dtype=int)
acc = np.zeros(n_t)
for t in range(n_t):
    Xt = X[:, :, t]
    for gid in np.unique(groups):
        test = groups == gid
        train = ~test
        clf = make_pipeline(StandardScaler(),
                            LogisticRegression(C=1, solver="liblinear",
                                               random_state=42, max_iter=1000))
        clf.fit(Xt[train], y[train])
        preds[test, t] = clf.predict(Xt[test])
    acc[t] = np.mean(preds[:, t] == y)

chance = float(max(np.mean(y == c) for c in np.unique(y)))
result = {"predictions": preds.tolist(),
          "accuracy": acc.tolist(),
          "chance_accuracy": chance}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print("accuracy", acc.tolist())
print("chance", chance)
