
import json, os
import numpy as np
import mne
from mne_bids import BIDSPath, write_raw_bids, read_raw_bids

req = json.load(open("/input/request.json"))["input"]
data = np.array(req["data_uV"], dtype=float) * 1e-6  # uV -> V
info = mne.create_info(req["channel_names"], req["sfreq"], req["types"])
raw = mne.io.RawArray(data, info, first_samp=req["first_samp"], verbose=False)
raw.info["bads"] = list(req["bads"])
raw.set_annotations(None)

ev = np.array(req["events_original_samples"], dtype=int)
onsets = (ev[:, 0] - req["first_samp"]) / req["sfreq"]
desc_map = {v: k for k, v in req["event_id"].items()}
annot = mne.Annotations(onset=onsets, duration=np.zeros(len(ev)),
                        description=[desc_map[c] for c in ev[:, 2]])
raw.set_annotations(annot)
raw.set_eeg_reference("average", projection=False, verbose=False) if False else None

bids_root = "/workspace/bids"
os.makedirs(bids_root, exist_ok=True)
bids_path = BIDSPath(subject="01", task="check", root=bids_root, datatype="eeg")
write_raw_bids(raw, bids_path, allow_preload=True, format="BrainVision",
               overwrite=True, verbose=False,
               event_id=req["event_id"])

# EEG reference and line frequency metadata
eeg_json = [os.path.join(dp, f) for dp, _, fs in os.walk(bids_root) for f in fs
            if f.endswith("_eeg.json")][0]
meta = json.load(open(eeg_json))
meta["EEGReference"] = "synthetic common reference"
meta["PowerLineFrequency"] = req["line_freq"]
json.dump(meta, open(eeg_json, "w"), indent=2)

back = read_raw_bids(bids_path, verbose=False)
back_ev, back_id = mne.events_from_annotations(back, verbose=False)
first_saved = back.first_samp
rel = (back_ev[:, 0] - first_saved).tolist()
result = {
    "relative_event_samples": rel,
    "bad_channels": list(back.info["bads"]),
    "sfreq": float(back.info["sfreq"]),
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(result)
