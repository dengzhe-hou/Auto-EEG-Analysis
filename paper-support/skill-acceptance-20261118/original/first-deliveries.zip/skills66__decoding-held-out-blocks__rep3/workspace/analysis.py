
import json
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

req = json.load(open("/input/request.json"))["input"]
X = np.array(req["features"], dtype=float)   # trials x channels x times
y = np.array(req["labels"])
groups = np.array(req["groups"])
n_trials, n_ch, n_times = X.shape

predictions = np.zeros((n_trials, n_times), dtype=int)
accuracy = np.zeros(n_times)

for t in range(n_times):
    Xt = X[:, :, t]
    for gid in np.unique(groups):
        test = groups == gid
        train = ~test
        clf = make_pipeline(StandardScaler(),
                            LogisticRegression(C=1, solver="liblinear",
                                               random_state=42, max_iter=1000))
        clf.fit(Xt[train], y[train])
        predictions[test, t] = clf.predict(Xt[test])
    accuracy[t] = np.mean(predictions[:, t] == y)

chance_accuracy = float(max(np.mean(y == c) for c in np.unique(y)))
result = {
    "predictions": predictions.tolist(),
    "accuracy": accuracy.tolist(),
    "chance_accuracy": chance_accuracy,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print("done", predictions.shape, accuracy.round(3).tolist(), chance_accuracy)
