Saved /workspace/analysis.py and executed it (exit code 0). Results written to /workspace/result.json with fields:

- predictions: 24 trials × 5 time samples, in original row order (leave-one-group-out, 4 groups, StandardScaler + LogisticRegression(C=1, solver="liblinear", random_state=42, max_iter=1000) fit per time sample within each fold)
- accuracy per time sample: [0.417, 0.458, 1.0, 1.0, 1.0]
- chance_accuracy: 0.5 (majority-class rate, 12/24 per class)
