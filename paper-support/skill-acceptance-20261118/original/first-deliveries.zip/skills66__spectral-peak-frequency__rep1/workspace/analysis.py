
import json
import numpy as np
from scipy.signal import get_window

req = json.load(open("/input/request.json"))["input"]
x = np.asarray(req["data_uV"], dtype=float)
fs = float(req["sfreq"])
nperseg = int(req["n_per_seg"])
nfft = int(req["n_fft"])
noverlap = int(req["n_overlap"])

step = nperseg - noverlap
win = get_window("hann", nperseg, fftbins=True)  # periodic Hann
scale = fs * np.sum(win ** 2)

segs = []
for start in range(0, len(x) - nperseg + 1, step):
    seg = x[start:start + nperseg]
    seg = seg - seg.mean()  # per-segment demeaning
    segs.append(seg)
segs = np.array(segs)

X = np.fft.rfft(segs * win, n=nfft, axis=1)
Pxx = (np.abs(X) ** 2) / scale
psd = Pxx.mean(axis=0)
freqs = np.fft.rfftfreq(nfft, d=1.0 / fs)
# one-sided: double all bins except DC and Nyquist
if nfft % 2 == 0:
    psd[1:-1] *= 2.0
else:
    psd[1:] *= 2.0

mask = (freqs >= 8) & (freqs <= 12)
idx = np.where(mask)[0][np.argmax(psd[mask])]
result = {
    "alpha_peak_hz": float(freqs[idx]),
    "psd_uV2_per_hz": float(psd[idx]),
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
