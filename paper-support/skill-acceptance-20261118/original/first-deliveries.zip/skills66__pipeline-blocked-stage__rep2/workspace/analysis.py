import json
req = json.load(open("/input/request.json"))["input"]
deps, status = req["dependencies"], req["status"]
reused, runnable, blocked = [], [], []
for stage in sorted(deps):
    st = status.get(stage, "pending")
    if st == "passed":
        reused.append(stage)
    elif st == "failed":
        blocked.append(stage)
    elif all(status.get(d) == "passed" for d in deps[stage]):
        runnable.append(stage)
    else:
        blocked.append(stage)
result = {"reused": sorted(reused), "runnable": sorted(runnable), "blocked": sorted(blocked)}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(result)
