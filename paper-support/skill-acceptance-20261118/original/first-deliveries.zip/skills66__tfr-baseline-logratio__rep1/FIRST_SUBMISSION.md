{"values": "saved to /workspace/result.json (shape 2 channels x 5 indices, log10 power/baseline, Fz then Cz)", "times_s": [0.125, 0.21875, 0.40625, 0.71875, 1.109375]}
