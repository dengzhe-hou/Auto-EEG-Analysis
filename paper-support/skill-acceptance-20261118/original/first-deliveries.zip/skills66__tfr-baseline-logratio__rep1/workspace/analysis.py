
import json
import numpy as np
from mne.time_frequency import tfr_array_morlet

req = json.load(open("/input/request.json"))
inp = req["input"]
ep = np.array(inp["epochs_uV"], dtype=float)  # (n_epochs, n_ch, n_times)
sfreq = float(inp["sfreq"])
tmin = float(inp["tmin"])
idx = np.array(inp["sample_indices"], dtype=int)

freqs = np.array([10.0])
n_cycles = 5.0
# zero-mean Morlet, decim=1, no other preprocessing
power = tfr_array_morlet(ep, sfreq=sfreq, freqs=freqs, n_cycles=n_cycles,
                         output="power", zero_mean=True, decim=1, n_jobs=1)
# shape (n_epochs, n_ch, n_freqs, n_times)
power = power[:, :, 0, :]
mean_power = power.mean(axis=0)  # (n_ch, n_times): averaged over epochs

times = tmin + np.arange(ep.shape[-1]) / sfreq
b0 = int(round((-0.5 - tmin) * sfreq))
b1 = int(round((-0.125 - tmin) * sfreq))
baseline = mean_power[:, b0:b1 + 1].mean(axis=1, keepdims=True)  # (n_ch, 1)

ratio = mean_power[:, idx] / baseline
values = np.log10(ratio)  # (n_ch, n_samples)

result = {
    "values": values.tolist(),
    "times_s": times[idx].tolist(),
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print("values shape", values.shape)
print("times_s", result["times_s"])
