
import json
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
x = np.asarray(inp["data_uV"], dtype=float)
fs = float(inp["sfreq"])
nperseg = int(inp["n_per_seg"])
nfft = int(inp["n_fft"])
noverlap = int(inp["n_overlap"])

# periodic Hann window
win = np.hanning(nperseg + 1)[:-1]
step = nperseg - noverlap
segs = []
start = 0
while start + nperseg <= len(x):
    seg = x[start:start + nperseg]
    seg = seg - seg.mean()
    segs.append(seg)
    start += step
segs = np.array(segs)

scale = fs * np.sum(win**2)
specs = np.abs(np.fft.rfft(segs * win, n=nfft, axis=1))**2
psd_each = specs / scale
psd_each[:, 1:-1] *= 2  # one-sided, excluding DC and Nyquist
psd = psd_each.mean(axis=0)
freqs = np.fft.rfftfreq(nfft, d=1.0 / fs)
df = freqs[1] - freqs[0]

mask = (freqs >= 8) & (freqs <= 12)
alpha_power = float(np.sum(psd[mask]) * df)

result = {"alpha_power_uV2": alpha_power}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
print("n_segments", len(segs), "df", df, "bins", int(mask.sum()))
