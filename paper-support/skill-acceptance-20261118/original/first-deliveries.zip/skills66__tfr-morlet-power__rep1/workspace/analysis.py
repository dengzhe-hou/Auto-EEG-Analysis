
import json
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
epochs = np.array(inp["epochs_uV"], dtype=float)  # (n_epochs, n_channels, n_times)
sfreq = float(inp["sfreq"])
tmin = float(inp["tmin"])
sample_indices = [int(i) for i in inp["sample_indices"]]
channels = inp["channels"]

freq = 10.0
n_cycles = 5.0

def morlet_kernel(f, n_cycles, sfreq):
    sigma_t = n_cycles / (2 * np.pi * f)
    half = int(np.ceil(5 * sigma_t * sfreq))
    t = np.arange(-half, half + 1) / sfreq
    wavelet = np.exp(2j * np.pi * f * t) * np.exp(-t**2 / (2 * sigma_t**2))
    wavelet = wavelet - wavelet.mean()  # zero-mean
    wavelet = wavelet / np.sqrt(np.sum(np.abs(wavelet)**2))
    return wavelet

w = morlet_kernel(freq, n_cycles, sfreq)
n_epochs, n_ch, n_times = epochs.shape
power = np.zeros((n_epochs, n_ch, n_times))
for e in range(n_epochs):
    for c in range(n_ch):
        conv = np.convolve(epochs[e, c], w, mode="same")
        power[e, c] = np.abs(conv) ** 2
avg_power = power.mean(axis=0)  # (n_ch, n_times)

values = [[float(avg_power[c, s]) for s in sample_indices] for c in range(n_ch)]
times_s = [float(tmin + s / sfreq) for s in sample_indices]

out = {"values": values, "times_s": times_s, "channels": channels,
       "units": "uV^2", "freq_hz": freq, "n_cycles": n_cycles}
json.dump(out, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(out))
