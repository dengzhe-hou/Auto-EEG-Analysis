Deliverables saved:
- /workspace/analysis.py (reusable program, executed)
- /workspace/methods.md (Methods paragraph plus field = value lines)
- /workspace/result.json (same field values)

Results:
- sampling_hz = 250
- reference = FCz
- retained_trials = 17
- seed = 73
- epoch_start_s = -0.1
- epoch_end_s = 0.6

Methods paragraph:
EEG was acquired at 250 Hz with a FCz reference. Epochs spanned -0.1 s to 0.6 s relative to event onset, with a band-pass of 0.2-35 Hz applied. Of 20 trials, 3 were excluded, leaving 17 retained trials. The executed random seed was 73 (planned seed 14), a deviation recorded here for transparency.
