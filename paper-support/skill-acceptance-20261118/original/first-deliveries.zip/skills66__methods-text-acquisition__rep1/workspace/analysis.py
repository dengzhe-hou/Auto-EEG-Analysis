import json
req = json.load(open("/input/request.json"))["input"]
acq = req["acquisition"]; ex = req["execution"]
sampling_hz = acq["sampling_hz"]
reference = acq.get("reference", "not recorded")
retained_trials = ex["n_trials"] - ex["n_excluded"]
seed = ex["executed_seed"]
epoch_start_s = ex["epoch_start_sample"] / sampling_hz
epoch_end_s = ex["epoch_end_sample"] / sampling_hz
result = dict(sampling_hz=sampling_hz, reference=reference, retained_trials=retained_trials,
              seed=seed, epoch_start_s=epoch_start_s, epoch_end_s=epoch_end_s)
paragraph = (f"EEG was acquired at {sampling_hz} Hz with a {reference} reference. "
    f"Epochs spanned {epoch_start_s} s to {epoch_end_s} s relative to event onset, "
    f"with a band-pass of {ex['band_hz'][0]}-{ex['band_hz'][1]} Hz applied. "
    f"Of {ex['n_trials']} trials, {ex['n_excluded']} were excluded, leaving "
    f"{retained_trials} retained trials. The executed random seed was {seed} "
    f"(planned seed {ex['planned_seed']}), a deviation recorded here for transparency.")
md = "# Methods\n\n" + paragraph + "\n\n" + "\n".join(f"{k} = {v}" for k, v in result.items()) + "\n"
open("/workspace/methods.md", "w").write(md)
json.dump(result, open("/workspace/result.json", "w"), indent=2)
