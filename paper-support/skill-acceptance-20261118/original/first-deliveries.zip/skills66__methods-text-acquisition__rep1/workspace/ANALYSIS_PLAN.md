Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-methods-text. Input: /input/request.json. Use its input field.
Draft a concise, truthful Methods paragraph from the acquisition and executed-stage records. Save methods.md with the paragraph plus one machine-readable line of the form field = value for each requested result field. Use 'not recorded' for absent reference. Report actual retained trial count, executed seed, and epoch times in s. Save the same field values as result.json.
The required fields are sampling_hz, reference, retained_trials, seed, epoch_start_s, epoch_end_s. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
