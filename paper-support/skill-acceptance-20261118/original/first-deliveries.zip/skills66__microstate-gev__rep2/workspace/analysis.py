import json
import os
import numpy as np

req = json.load(open("/input/request.json"))["input"]
label = np.array(req["label"])
gfp = np.array(req["gfp"], dtype=float)
corr = np.array(req["corr"], dtype=float)

power = (gfp ** 2) * (corr ** 2)
total_power = power.sum()

gev_by_state = []
for k in [0, 1, 2]:
    mask = label == k
    gev_by_state.append(float(power[mask].sum() / total_power))
gev_total = float(sum(gev_by_state))

result = {"gev_by_state": gev_by_state, "gev_total": gev_total}
os.makedirs("/workspace", exist_ok=True)
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(result)
