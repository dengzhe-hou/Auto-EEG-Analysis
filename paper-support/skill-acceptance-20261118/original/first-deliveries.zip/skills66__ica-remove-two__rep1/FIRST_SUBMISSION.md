{"cleaned_uV": "saved at /workspace/result.json (3 channels x 40 samples)", "applied_exclusions": [1, 2]}
