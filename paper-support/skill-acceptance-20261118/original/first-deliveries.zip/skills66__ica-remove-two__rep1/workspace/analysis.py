import json
import numpy as np

req = json.load(open("/input/request.json"))["input"]
X = np.array(req["channel_data_uV"], dtype=float)
W = np.array(req["unmixing"], dtype=float)
A = np.array(req["mixing"], dtype=float)
ex = [int(i) for i in req["approved_exclusions"]]

S = W @ X
S_clean = S.copy()
S_clean[ex, :] = 0.0
cleaned = A @ S_clean

result = {
    "cleaned_uV": cleaned.tolist(),
    "applied_exclusions": ex,
}
json.dump(result, open("/workspace/result.json", "w"))
