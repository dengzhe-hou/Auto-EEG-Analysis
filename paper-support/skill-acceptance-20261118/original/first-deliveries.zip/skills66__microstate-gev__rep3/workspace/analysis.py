
import json
req = json.load(open("/input/request.json"))
inp = req["input"]
label = inp["label"]
gfp = inp["gfp"]
corr = inp["corr"]

denom = sum(g * g for g in gfp)
num = {0: 0.0, 1: 0.0, 2: 0.0}
for l, g, c in zip(label, gfp, corr):
    if l in num:
        num[l] += (g * c) ** 2

gev_by_state = [num[k] / denom for k in (0, 1, 2)]
gev_total = sum(gev_by_state)
result = {"gev_by_state": gev_by_state, "gev_total": gev_total}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
