
import json

with open("/input/request.json") as f:
    data = json.load(f)["input"]

stim_ms = data["stimulus_ms"]
stim_blk = data["stimulus_blocks"]
resp_ms = data["response_ms"]
resp_blk = data["response_blocks"]
resp_ids = data["response_ids"]

lo, hi = 100, 350
used = set()
rt_ms = []
for s, b in zip(stim_ms, stim_blk):
    found = None
    for r, rb, rid in zip(resp_ms, resp_blk, resp_ids):
        if rb != b or rid in used:
            continue
        rt = r - s
        if lo <= rt < hi:
            found = (rt, rid)
            break
    if found is None:
        rt_ms.append(None)
    else:
        rt_ms.append(found[0])
        used.add(found[1])

unused = sorted(rid for rid in resp_ids if rid not in used)
result = {"rt_ms": rt_ms, "unused_response_ids": unused}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
