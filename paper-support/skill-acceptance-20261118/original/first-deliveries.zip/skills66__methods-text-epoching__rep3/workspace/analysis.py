
import json

req = json.load(open("/input/request.json"))["input"]
acq = req["acquisition"]
ex = req["execution"]

sfreq = acq["sampling_hz"]
reference = acq["reference"] if acq["reference"] is not None else "not recorded"
retained = ex["n_trials"] - ex["n_excluded"]
seed = ex["executed_seed"]
epoch_start_s = ex["epoch_start_sample"] / sfreq
epoch_end_s = ex["epoch_end_sample"] / sfreq
band = ex["band_hz"]

result = {
    "sampling_hz": sfreq,
    "reference": reference,
    "retained_trials": retained,
    "seed": seed,
    "epoch_start_s": epoch_start_s,
    "epoch_end_s": epoch_end_s,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)

paragraph = (
    f"EEG was acquired at a sampling rate of {sfreq} Hz with a reference of {reference}. "
    f"A band-pass filter of {band[0]}-{band[1]} Hz was applied. "
    f"Epochs spanned {epoch_start_s} s to {epoch_end_s} s relative to event onset. "
    f"Of {ex['n_trials']} trials, {ex['n_excluded']} were excluded, leaving {retained} retained trials. "
    f"The analysis was executed with random seed {seed} (planned seed {ex['planned_seed']})."
)
lines = [
    "# Methods",
    "",
    paragraph,
    "",
    f"sampling_hz = {sfreq}",
    f"reference = {reference}",
    f"retained_trials = {retained}",
    f"seed = {seed}",
    f"epoch_start_s = {epoch_start_s}",
    f"epoch_end_s = {epoch_end_s}",
    "",
]
open("/workspace/methods.md", "w").write("\n".join(lines))
print(open("/workspace/result.json").read())
