# Methods

EEG was acquired at a sampling rate of 250 Hz with a reference of not recorded. A band-pass filter of 0.2-35 Hz was applied. Epochs spanned -0.12 s to 0.64 s relative to event onset. Of 21 trials, 5 were excluded, leaving 16 retained trials. The analysis was executed with random seed 74 (planned seed 14).

sampling_hz = 250
reference = not recorded
retained_trials = 16
seed = 74
epoch_start_s = -0.12
epoch_end_s = 0.64
