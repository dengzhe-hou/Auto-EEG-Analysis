import json
import numpy as np
from scipy import stats

req = json.load(open("/input/request.json"))
groups = req["input"]["groups"]
arrays = [np.asarray(g, dtype=float) for g in groups]
n_per_group = [int(len(a)) for a in arrays]
stat, p = stats.f_oneway(*arrays)
result = {
    "statistic": float(stat),
    "p_value": float(p),
    "n_per_group": n_per_group,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
