The figure was rendered and saved to /workspace/fig.svg, with line gid="aea-data" present in the SVG. The program is saved at /workspace/analysis.py and was executed. Results are saved to /workspace/result.json:

{"n_points": 5, "x_label": "Time (s)", "y_label": "Difference (uV)"}
