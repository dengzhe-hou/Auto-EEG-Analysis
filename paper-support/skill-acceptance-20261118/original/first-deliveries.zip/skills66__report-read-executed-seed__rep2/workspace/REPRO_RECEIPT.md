# REPRO_RECEIPT

- Source artifact: request.json
- Executed seed: 33
- Planned seed (not used for execution): 7
- Status: available
- roi_mean_uV: -1.465
- n_trials: 45
