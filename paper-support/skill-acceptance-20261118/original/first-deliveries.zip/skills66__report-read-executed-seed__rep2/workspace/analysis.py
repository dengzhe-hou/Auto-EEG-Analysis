import json, os, html

req = json.load(open("/input/request.json"))["input"]
ex = req["executed_stage"]
src = req["source_file"]
planned = req["planned_seed"]

facts = {
    "roi_mean_uV": ex["roi_mean_uV"],
    "n_trials": ex["n_trials"],
    "status": ex["status"],
    "seed": ex["seed"],
}

def fmt(v):
    if v is None:
        return "null"
    if isinstance(v, float):
        return f"{v:.3f}"
    return str(v)

rows = "\n".join(
    f'<tr><td>{k}</td><td id="{k}">{html.escape(fmt(v))}</td></tr>'
    for k, v in facts.items()
)
report_html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>EEG report</title></head>
<body>
<h1>EEG report</h1>
<table>
<tr><th>Key</th><th>Value</th></tr>
{rows}
</table>
<p>Source artifact: {html.escape(src)}</p>
<p>Executed seed: {ex['seed']}</p>
</body></html>
"""

receipt = f"""# REPRO_RECEIPT

- Source artifact: {src}
- Executed seed: {ex['seed']}
- Planned seed (not used for execution): {planned}
- Status: {ex['status']}
- roi_mean_uV: {ex['roi_mean_uV']}
- n_trials: {ex['n_trials']}
"""

os.makedirs("/workspace", exist_ok=True)
with open("/workspace/report.html", "w") as f:
    f.write(report_html)
with open("/workspace/REPRO_RECEIPT.md", "w") as f:
    f.write(receipt)
with open("/workspace/result.json", "w") as f:
    json.dump(facts, f, indent=2)
