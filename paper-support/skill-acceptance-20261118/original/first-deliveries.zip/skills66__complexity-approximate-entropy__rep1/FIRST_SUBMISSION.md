Approximate entropy was computed with m=2, Chebyshev strict distance < 0.65, self-matches included, and the mean log neighbor fraction over all fitting windows for each embedding length.

Results (saved to /workspace/result.json; program saved at /workspace/analysis.py and executed):

{
  "phi_m": -2.0907572880300145,
  "phi_m_plus_1": -2.7329804967013738,
  "approximate_entropy": 0.6422232086713593
}
