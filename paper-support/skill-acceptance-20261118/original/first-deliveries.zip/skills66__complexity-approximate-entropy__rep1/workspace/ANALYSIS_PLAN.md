Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-complexity. Input: /input/request.json. Use its input field.
Calculate approximate entropy at m=2 using Chebyshev strict distance < 0.65 and self-matches. For each embedding length use all fitting windows and take the mean log neighbor fraction. Report phi_m, phi_m_plus_1, and approximate_entropy.
The required fields are phi_m, phi_m_plus_1, approximate_entropy. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
