
import json, math
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
x = np.asarray(inp["series"], dtype=float)
m = int(inp["m"])
r_tol = float(inp["r"])
N = len(x)

def phi(mm):
    n_vec = N - mm + 1
    emb = np.array([x[i:i+mm] for i in range(n_vec)])
    logs = []
    for i in range(n_vec):
        d = np.max(np.abs(emb - emb[i]), axis=1)
        count = np.sum(d < r_tol)  # includes self-match
        logs.append(math.log(count / n_vec))
    return float(np.mean(logs))

phi_m = phi(m)
phi_m1 = phi(m + 1)
apen = phi_m - phi_m1

result = {"phi_m": phi_m, "phi_m_plus_1": phi_m1, "approximate_entropy": apen}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result, indent=2))
