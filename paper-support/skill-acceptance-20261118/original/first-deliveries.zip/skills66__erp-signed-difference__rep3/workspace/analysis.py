
import json
import numpy as np
import mne

req = json.load(open('/input/request.json'))
inp = req['input']
X = np.array(inp['epochs_uV'], dtype=float) * 1e-6  # uV -> V for MNE
labels = np.array(inp['labels'])
ch_names = inp['channel_names']
sfreq = float(inp['sfreq'])
tmin = float(inp['tmin'])

info = mne.create_info(ch_names, sfreq, ch_types='eeg')
epochs = mne.EpochsArray(X, info, tmin=tmin, events=None,
                         event_id=None, verbose=False)
epochs.events = np.column_stack([np.arange(len(X)), np.zeros(len(X), int),
                                 np.where(labels == 'A', 1, 2)])
epochs.event_id = {'A': 1, 'B': 2}

evA = epochs['A'].average()
evB = epochs['B'].average()
diff = mne.combine_evoked([evB, evA], weights=[1, -1])
diff.comment = 'B-A'
mne.write_evokeds('/workspace/check-ave.fif', diff, verbose=False)

times = diff.times
mask = (times >= 0.1 - 1e-9) & (times <= 0.3 + 1e-9)
n_window = int(mask.sum())
roi_idx = [ch_names.index('Cz'), ch_names.index('Pz')]
roi_vals = diff.data[roi_idx][:, mask] * 1e6  # back to uV
roi_mean_uV = float(roi_vals.mean())

n_A = int(np.sum(labels == 'A'))
n_B = int(np.sum(labels == 'B'))

result = {
    'roi_mean_uV': roi_mean_uV,
    'n_window_samples': n_window,
    'n_condition_trials': [n_A, n_B],
}
json.dump(result, open('/workspace/result.json', 'w'), indent=2)
print(json.dumps(result))
