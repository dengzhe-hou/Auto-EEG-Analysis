
import json, math
import numpy as np

def sample_entropy_counts(x, m, r):
    x = np.asarray(x, dtype=float)
    N = len(x)
    # same starting positions for both lengths: 0..N-m-1
    n_starts = N - m
    def count(length):
        templates = np.array([x[i:i+length] for i in range(n_starts)])
        c = 0
        for i in range(n_starts):
            for j in range(i+1, n_starts):
                d = np.max(np.abs(templates[i] - templates[j]))
                if d < r:
                    c += 1
        return c
    B = count(m)
    A = count(m+1)
    return B, A

def main():
    req = json.load(open("/input/request.json"))
    inp = req["input"]
    x = inp["series"]
    m = int(inp["m"])
    r = float(inp["r"])
    B, A = sample_entropy_counts(x, m, r)
    se = -math.log(A / B) if (A > 0 and B > 0) else float("nan")
    result = {"counts_m": B, "counts_m_plus_1": A, "sample_entropy": se}
    json.dump(result, open("/workspace/result.json", "w"), indent=2)
    print(result)

if __name__ == "__main__":
    main()
