
import json, numpy as np
req = json.load(open("/input/request.json"))
im = np.asarray(req["input"]["imaginary_cross_spectrum"], dtype=float)
num = np.sum(im)
den = np.sum(np.abs(im))
wpli = float(np.abs(num) / den)
# debiased wPLI^2: remove self-products (sum of im_k^2) from numerator and denominator
S = np.sum(im)
sq = np.sum(im**2)
wpli2 = float((S**2 - sq) / (np.sum(np.abs(im))**2 - sq))
result = {"wpli": wpli, "wpli2": wpli2}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(result)
