
import json
import numpy as np

with open("/input/request.json") as f:
    req = json.load(f)
inp = req["input"]

G = np.array(inp["gain"], dtype=float)          # sensors x sources
C = np.array(inp["noise_cov"], dtype=float)     # sensors x sensors
Y = np.array(inp["sensor_data"], dtype=float)   # sensors x times
lam2 = float(inp["lambda2"])
normalize = bool(inp["normalize_noise"])

# Identity source prior minimum-norm inverse: K = G^T (G G^T + lambda2 C)^-1
K = G.T @ np.linalg.inv(G @ G.T + lam2 * C)

if normalize:
    # Normalize each source row by sqrt(diag(K C K^T))
    d = np.sqrt(np.diag(K @ C @ K.T))
    K = K / d[:, None]

source_estimates = K @ Y

result = {
    "source_estimates": source_estimates.tolist(),
    "normalized": normalize,
}

with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)

print(json.dumps(result))
