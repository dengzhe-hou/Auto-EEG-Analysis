Saved /workspace/analysis.py and /workspace/result.json. The program used the supplied gain (3×2), noise_cov (3×3), sensor_data (3×4), lambda2=1.3, and normalize_noise=False, computing K = G^T (G G^T + lambda2·C)^-1 and source_estimates = K @ sensor_data. No row normalization was applied because normalize_noise is false.

{"source_estimates": [[1.957896263353796, 1.0289070430705265, 3.3362691545414984, 2.4272634988156807], [2.881229757818921, 1.8875138976168615, 0.5784308986319918, -0.2365253540871076]], "normalized": false}
