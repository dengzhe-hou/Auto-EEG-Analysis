
import json, math, itertools
import numpy as np

req = json.load(open("/input/request.json"))
x = np.asarray(req["input"]["series"], dtype=float)
order, delay = 3, 1

n = len(x) - (order - 1) * delay
perms = list(itertools.permutations(range(order)))  # lexicographic order
counts = {p: 0 for p in perms}
for i in range(n):
    window = x[i:i + order * delay:delay]
    pattern = tuple(int(k) for k in np.argsort(window, kind="stable"))
    counts[pattern] += 1

pattern_counts = [counts[p] for p in perms]
total = sum(pattern_counts)
probs = np.array([c / total for c in pattern_counts if c > 0])
H = float(-np.sum(probs * np.log(probs)))
normalized_perm_entropy = H / math.log(math.factorial(order))

result = {
    "pattern_counts": pattern_counts,
    "normalized_perm_entropy": normalized_perm_entropy,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
