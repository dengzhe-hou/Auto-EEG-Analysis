{"roi_mean_uV": -0.003061816653981308, "n_window_samples": 21, "n_condition_trials": [2, 3]}
