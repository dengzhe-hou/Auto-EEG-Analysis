
import json, numpy as np
import mne

req = json.load(open("/input/request.json"))["input"]
data = np.array(req["epochs_uV"], dtype=float)  # (n_epochs, n_ch, n_times) in uV
labels = np.array(req["labels"])
ch_names = req["channel_names"]
sfreq = float(req["sfreq"])
tmin = float(req["tmin"])

# convert uV -> V for MNE
info = mne.create_info(ch_names, sfreq, ch_types="eeg")
epochs = mne.EpochsArray(data * 1e-6, info, tmin=tmin, verbose=False)
epochs.metadata = None
event_ids = {"A": 1, "B": 2}
events = np.column_stack([np.arange(len(labels)), np.zeros(len(labels), int),
                          np.array([event_ids[l] for l in labels])])
epochs = mne.EpochsArray(data * 1e-6, info, events=events, event_id=event_ids,
                         tmin=tmin, verbose=False)

evoked_A = epochs["A"].average()
evoked_A.save("/workspace/check-ave.fif", overwrite=True, verbose=False)

times = evoked_A.times
mask = (times >= 0.1 - 1e-9) & (times <= 0.3 + 1e-9)
n_window_samples = int(mask.sum())
roi_idx = [ch_names.index("Cz"), ch_names.index("Pz")]
roi_wave = evoked_A.data[roi_idx].mean(axis=0)  # equal weight over Cz, Pz (in V)
roi_mean_uV = float(roi_wave[mask].mean() * 1e6)

n_A = int(np.sum(labels == "A"))
n_B = int(np.sum(labels == "B"))

result = {
    "roi_mean_uV": roi_mean_uV,
    "n_window_samples": n_window_samples,
    "n_condition_trials": [n_A, n_B],
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
print("times range:", times[0], times[-1], "window times:", times[mask])
