
import json

req = json.load(open("/input/request.json"))["input"]
stim = req["stimulus_ms"]; sb = req["stimulus_blocks"]
resp = req["response_ms"]; rb = req["response_blocks"]; rid = req["response_ids"]

used = set()
rt_ms = []
for s, b in zip(stim, sb):
    chosen = None
    for r, rblk, i in zip(resp, rb, rid):
        if rblk != b or i in used:
            continue
        rt = r - s
        if 100 <= rt < 350:
            chosen = (i, rt)
            break
    if chosen is None:
        rt_ms.append(None)
    else:
        used.add(chosen[0])
        rt_ms.append(chosen[1])

unused = sorted(i for i in rid if i not in used)
result = {"rt_ms": rt_ms, "unused_response_ids": unused}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
