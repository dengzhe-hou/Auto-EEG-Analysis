Saved /workspace/analysis.py (program) and /workspace/result.json:

{
  "observed_abs_mean": 2.2,
  "n_patterns": 32,
  "p_exact": 0.1875
}
