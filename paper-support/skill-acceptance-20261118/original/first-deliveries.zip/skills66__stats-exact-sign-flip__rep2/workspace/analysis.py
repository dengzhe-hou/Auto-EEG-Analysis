
import json, itertools
import numpy as np

with open("/input/request.json") as f:
    req = json.load(f)
x = np.asarray(req["input"]["contrasts"], dtype=float)
n = len(x)

observed = abs(x.mean())
stats = []
for signs in itertools.product([-1.0, 1.0], repeat=n):
    s = np.asarray(signs)
    stats.append(abs((s * x).mean()))
stats = np.asarray(stats)

n_patterns = int(len(stats))
count_extreme = int(np.sum(stats >= observed - 1e-12))
p_exact = count_extreme / n_patterns

result = {
    "observed_abs_mean": float(observed),
    "n_patterns": n_patterns,
    "p_exact": float(p_exact),
}
import os
os.makedirs("/workspace", exist_ok=True)
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
