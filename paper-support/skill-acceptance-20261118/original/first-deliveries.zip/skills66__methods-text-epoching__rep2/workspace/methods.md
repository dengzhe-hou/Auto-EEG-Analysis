# Methods

EEG was recorded at a sampling rate of 250 Hz with reference: not recorded. Data were epoched from -0.12 s to 0.64 s relative to event onset. Of 21 trials, 16 were retained after excluding 5. The executed random seed was 74 (planned seed 14). Band-pass filter: 0.2-35 Hz.

sampling_hz = 250
reference = not recorded
retained_trials = 16
seed = 74
epoch_start_s = -0.12
epoch_end_s = 0.64
