
import json, os
req = json.load(open("/input/request.json"))["input"]
acq = req["acquisition"]; ex = req["execution"]
sr = acq["sampling_hz"]
reference = acq["reference"] if acq["reference"] is not None else "not recorded"
retained = ex["n_trials"] - ex["n_excluded"]
seed = ex["executed_seed"]
epoch_start_s = ex["epoch_start_sample"] / sr
epoch_end_s = ex["epoch_end_sample"] / sr
result = {
    "sampling_hz": sr,
    "reference": reference,
    "retained_trials": retained,
    "seed": seed,
    "epoch_start_s": epoch_start_s,
    "epoch_end_s": epoch_end_s,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
para = (
    f"EEG was recorded at a sampling rate of {sr} Hz with reference: {reference}. "
    f"Data were epoched from {epoch_start_s:.2f} s to {epoch_end_s:.2f} s relative to event onset. "
    f"Of {ex['n_trials']} trials, {retained} were retained after excluding {ex['n_excluded']}. "
    f"The executed random seed was {seed} (planned seed {ex['planned_seed']}). "
    f"Band-pass filter: {ex['band_hz'][0]}-{ex['band_hz'][1]} Hz."
)
lines = [
    "# Methods", "", para, "",
    "sampling_hz = " + str(sr),
    "reference = " + str(reference),
    "retained_trials = " + str(retained),
    "seed = " + str(seed),
    "epoch_start_s = " + str(epoch_start_s),
    "epoch_end_s = " + str(epoch_end_s),
]
open("/workspace/methods.md", "w").write("\n".join(lines) + "\n")
