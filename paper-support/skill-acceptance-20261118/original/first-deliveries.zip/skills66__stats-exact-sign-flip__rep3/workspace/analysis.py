import json, itertools
import numpy as np

with open("/input/request.json") as f:
    req = json.load(f)
x = np.array(req["input"]["contrasts"], dtype=float)
n = len(x)

observed = abs(x.mean())
stats = []
for signs in itertools.product([-1, 1], repeat=n):
    s = np.array(signs, dtype=float)
    stats.append(abs((s * x).mean()))
stats = np.array(stats)
n_patterns = len(stats)
p_exact = float(np.sum(stats >= observed - 1e-12) / n_patterns)

result = {
    "observed_abs_mean": float(observed),
    "n_patterns": int(n_patterns),
    "p_exact": p_exact,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(result)
