Epoching completed. All three events were retained (no peak-to-peak rejection was requested, and every epoch fit within the recording).

Results (also saved to /workspace/result.json):
- retained_event_samples: [35, 75, 114]
- times_s: -0.1 to 0.2 s inclusive, step 0.01 s (31 samples)
- n_dropped: 0

Artifacts:
- /workspace/analysis.py (reusable program, executed successfully)
- /workspace/check-epo.fif (epochs; EEG converted from µV to V, baseline -0.1 to 0 s applied)
- /workspace/result.json
