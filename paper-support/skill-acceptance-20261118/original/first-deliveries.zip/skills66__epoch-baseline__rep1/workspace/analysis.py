
import json, ast
import numpy as np
import mne

req = json.load(open("/input/request.json"))
inp = req["input"]
if isinstance(inp, str):
    inp = ast.literal_eval(inp)

data_uV = np.array(inp["raw_uV"], dtype=float)
data_V = data_uV * 1e-6
ch_names = inp["channel_names"]
sfreq = float(inp["sfreq"])
ch_types = ["eeg"] * len(ch_names)
info = mne.create_info(ch_names, sfreq, ch_types)
raw = mne.io.RawArray(data_V, info, verbose=False)

events = np.array(inp["events"], dtype=int)
event_id = inp["event_id"]
tmin, tmax = float(inp["tmin"]), float(inp["tmax"])
baseline = tuple(inp["baseline"]) if inp.get("baseline") is not None else None
reject_uV = inp.get("reject_peak_to_peak_uV")
reject = None
if reject_uV is not None:
    reject = dict(eeg=float(reject_uV) * 1e-6)

epochs = mne.Epochs(raw, events, event_id=event_id, tmin=tmin, tmax=tmax,
                    baseline=baseline, reject=reject, preload=True,
                    reject_by_annotation=False, verbose=False)

n_total = len(events)
retained = epochs.events[:, 0].tolist()
times = epochs.times.tolist()
n_dropped = int(n_total - len(epochs))

import os
os.makedirs("/workspace", exist_ok=True)
epochs.save("/workspace/check-epo.fif", overwrite=True, verbose=False)

result = {
    "retained_event_samples": retained,
    "times_s": times,
    "n_dropped": n_dropped,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
