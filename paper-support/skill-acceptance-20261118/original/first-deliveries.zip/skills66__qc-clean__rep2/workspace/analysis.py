
import json
import numpy as np
import mne
from qc_amplitude import amplitude_qc

req = json.load(open("/input/request.json"))["input"]
names = req["channel_names"]
data_v = np.asarray(req["signal_uV"], dtype=float) * 1e-6
sfreq = float(req["sfreq"])
info = mne.create_info(names, sfreq, ch_types="eeg")
raw = mne.io.RawArray(data_v, info, verbose=False)

findings = amplitude_qc(
    raw,
    constant_min_duration=0.020,
    low_amplitude_window=0.100,
    low_amplitude_ptp=0.5e-6,
    jump_threshold=150e-6,
    jump_min_duration=0.005,
    bad_percent=5.0,
)

constant_channels = sorted({s["channel"] for s in findings["constant_segments"]})
rapid_change_channels = sorted({s["channel"] for s in findings["jump_segments"]})
bad_channel_candidates = sorted(findings["bad_channel_candidates"])

result = {
    "constant_channels": constant_channels,
    "rapid_change_channels": rapid_change_channels,
    "bad_channel_candidates": bad_channel_candidates,
    "details": findings,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps({k: result[k] for k in ["constant_channels", "rapid_change_channels", "bad_channel_candidates"]}))
