
import json

REQUEST = "/input/request.json"
RECIPE = "/workspace/aea/recipes/n400-semantic/RECIPE.md"
RESULT = "/workspace/result.json"

def read_header(path):
    lines = open(path, encoding="utf-8").read().splitlines()
    fields = {}
    in_header = False
    for line in lines:
        if line.strip() == "---":
            if in_header:
                break
            in_header = True
            continue
        if in_header and ":" in line and not line.startswith(" "):
            k, v = line.split(":", 1)
            fields[k.strip()] = v.strip().strip('"')
        if in_header and line.startswith("required_markers:"):
            inner = line.split("[", 1)[1].split("]", 1)[0]
            fields["required_markers"] = [x.strip() for x in inner.split(",") if x.strip()]
    return fields

req = json.load(open(REQUEST))["input"]
hdr = read_header(RECIPE)

required = hdr["required_markers"]
min_trials = int(hdr["min_trials_per_condition"])
min_ch = int(hdr["min_channels"])
min_sfreq = int(hdr["min_sfreq"])
counts = req.get("marker_counts", {})

missing = sorted(m for m in required if m not in counts)
insufficient = sorted(m for m in required if m in counts and counts[m] < min_trials)

eligible = (not missing and not insufficient
            and req["channel_count"] >= min_ch
            and req["sfreq"] >= min_sfreq)

result = {
    "eligible": eligible,
    "missing_markers": missing,
    "insufficient_present_markers": insufficient,
    "recipe_version": hdr["version"],
}
json.dump(result, open(RESULT, "w"), indent=2)
print(json.dumps(result, indent=2))
