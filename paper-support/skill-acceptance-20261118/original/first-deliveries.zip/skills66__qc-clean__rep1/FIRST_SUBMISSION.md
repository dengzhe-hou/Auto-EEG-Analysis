{"constant_channels": [], "rapid_change_channels": [], "bad_channel_candidates": []}
