Deliverables saved:
- /workspace/analysis.py (reusable program, executed)
- /workspace/methods.md
- /workspace/result.json

Results:
- sampling_hz = 250
- reference = not recorded
- retained_trials = 15
- seed = 75
- epoch_start_s = -0.14
- epoch_end_s = 0.68

Methods paragraph (in methods.md): EEG was acquired at 250 Hz with a reference of not recorded. Data were band-pass filtered between 0.2 and 35 Hz and epoched from -0.14 s to 0.68 s relative to event onset. Of 22 trials, 15 were retained after exclusion of 7. The analysis was executed with random seed 75 (planned seed 14).

Notes: the reference is absent in the acquisition record, so it is reported as "not recorded" rather than inferred. The executed seed (75) differs from the planned seed (14); the executed value is reported and the discrepancy is stated in the paragraph.
