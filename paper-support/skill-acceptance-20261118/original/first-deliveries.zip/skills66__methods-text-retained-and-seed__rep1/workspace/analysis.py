import json
req = json.load(open("/input/request.json"))["input"]
acq = req["acquisition"]; ex = req["execution"]
sf = acq["sampling_hz"]
ref = acq["reference"] if acq["reference"] is not None else "not recorded"
retained = ex["n_trials"] - ex["n_excluded"]
seed = ex["executed_seed"]
ep_start = ex["epoch_start_sample"] / sf
ep_end = ex["epoch_end_sample"] / sf
result = {"sampling_hz": sf, "reference": ref, "retained_trials": retained,
          "seed": seed, "epoch_start_s": ep_start, "epoch_end_s": ep_end}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
paragraph = (
    f"EEG was acquired at {sf} Hz with a reference of {ref}. "
    f"Data were band-pass filtered between {ex['band_hz'][0]} and {ex['band_hz'][1]} Hz and epoched "
    f"from {ep_start} s to {ep_end} s relative to event onset. "
    f"Of {ex['n_trials']} trials, {retained} were retained after exclusion of {ex['n_excluded']}. "
    f"The analysis was executed with random seed {seed} (planned seed {ex['planned_seed']})."
)
lines = ["# Methods", "", paragraph, ""]
for k, v in result.items():
    lines.append(f"{k} = {v}")
open("/workspace/methods.md", "w").write("\n".join(lines) + "\n")
