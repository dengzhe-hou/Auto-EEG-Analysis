# Methods

EEG was acquired at 250 Hz with a reference of not recorded. Data were band-pass filtered between 0.2 and 35 Hz and epoched from -0.14 s to 0.68 s relative to event onset. Of 22 trials, 15 were retained after exclusion of 7. The analysis was executed with random seed 75 (planned seed 14).

sampling_hz = 250
reference = not recorded
retained_trials = 15
seed = 75
epoch_start_s = -0.14
epoch_end_s = 0.68
