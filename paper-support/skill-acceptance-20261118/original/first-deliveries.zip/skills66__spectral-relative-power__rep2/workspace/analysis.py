
import json
import numpy as np

req = json.load(open("/input/request.json"))["input"]
x = np.asarray(req["data_uV"], dtype=float)
fs = float(req["sfreq"])
nperseg = int(req["n_per_seg"])
nfft = int(req["n_fft"])
noverlap = int(req["n_overlap"])

win = np.hanning(nperseg + 1)[:-1]  # periodic Hann
step = nperseg - noverlap
starts = np.arange(0, len(x) - nperseg + 1, step)
scale = fs * np.sum(win ** 2)

psds = []
for s in starts:
    seg = x[s:s + nperseg]
    seg = seg - seg.mean()
    X = np.fft.rfft(seg * win, n=nfft)
    p = (np.abs(X) ** 2) / scale
    # one-sided: double all bins except DC and Nyquist
    p[1:-1] *= 2.0
    psds.append(p)
psd = np.mean(psds, axis=0)
freqs = np.fft.rfftfreq(nfft, d=1.0 / fs)

def band_sum(lo, hi):
    m = (freqs >= lo) & (freqs <= hi)
    return float(psd[m].sum())

beta_fraction = band_sum(15, 30) / band_sum(2, 40)
result = {"beta_fraction": beta_fraction}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(result)
