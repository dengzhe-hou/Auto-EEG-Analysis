{"n_points": 5, "x_label": "Frequency (Hz)", "y_label": "Power (uV^2/Hz)"}
