
import json
import numpy as np
import mne

req = json.load(open("/input/request.json"))
inp = req["input"]
names = inp["names"]
types = inp["types"]
sfreq = float(inp["sfreq"])
new_sfreq = float(inp["new_sfreq"])
data = np.array(inp["raw_uV"], dtype=float)
events = np.array(inp["events"], dtype=int)

# Convert uV to V for MNE, then back to uV for output
info = mne.create_info(ch_names=names, sfreq=sfreq, ch_types=types)
raw = mne.io.RawArray(data * 1e-6, info, verbose=False)
raw.resample(new_sfreq, method="fft", npad=0, window="boxcar",
             events=events.copy(), verbose=False)

# MNE resample with events returns resampled events in raw.resample's events argument
# Use mne.filter-style approach: resample events manually on the same grid for reporting
ratio = new_sfreq / sfreq
new_events = events.copy()
new_events[:, 0] = np.round(events[:, 0] * ratio).astype(int)
out = raw.get_data() * 1e6

result = {
    "new_sfreq": float(raw.info["sfreq"]),
    "relative_event_samples": new_events[:, 0].tolist(),
    "samples_uV": out.tolist(),
}
json.dump(result, open("/workspace/result.json", "w"))
print("new_sfreq", result["new_sfreq"], "n_samples", out.shape)
