Saved /workspace/analysis.py and /workspace/result.json.

Result summary:
- new_sfreq: 50.0
- relative_event_samples: [20, 94, 106]
- samples_uV: 3 channels (Fz, Cz, Pz) × 200 samples at 50 Hz

Method: MNE resample from 100 Hz to 50 Hz with method="fft", npad=0, window="boxcar", with events supplied jointly. Event sample indices were mapped to the new grid by the 0.5 ratio. No further preprocessing was applied.
