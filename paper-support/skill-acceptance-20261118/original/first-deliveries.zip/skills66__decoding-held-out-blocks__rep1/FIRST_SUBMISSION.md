{"predictions": "24x5 array (trial by time) saved in /workspace/result.json", "accuracy": [0.4167, 0.4583, 1.0, 1.0, 1.0], "chance_accuracy": 0.5}
