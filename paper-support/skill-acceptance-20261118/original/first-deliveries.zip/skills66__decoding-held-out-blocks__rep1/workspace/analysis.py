
import json
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import LeaveOneGroupOut

req = json.load(open("/input/request.json"))["input"]
X = np.array(req["features"], dtype=float)   # trial x channel x time
y = np.array(req["labels"])
g = np.array(req["groups"])
n_trials, n_ch, n_t = X.shape

logo = LeaveOneGroupOut()
predictions = np.zeros((n_trials, n_t), dtype=int)
for t in range(n_t):
    Xt = X[:, :, t]
    for tr, te in logo.split(Xt, y, groups=g):
        clf = make_pipeline(StandardScaler(),
                            LogisticRegression(C=1, solver="liblinear",
                                               random_state=42, max_iter=1000))
        clf.fit(Xt[tr], y[tr])
        predictions[te, t] = clf.predict(Xt[te])

accuracy = [float(np.mean(predictions[:, t] == y)) for t in range(n_t)]
chance = float(max(np.mean(y == c) for c in np.unique(y)))
# chance level for balanced binary labels = 1/number of classes
chance_accuracy = 1.0 / len(np.unique(y))

result = {
    "predictions": predictions.tolist(),
    "accuracy": accuracy,
    "chance_accuracy": chance_accuracy,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print("done", n_trials, n_t)
