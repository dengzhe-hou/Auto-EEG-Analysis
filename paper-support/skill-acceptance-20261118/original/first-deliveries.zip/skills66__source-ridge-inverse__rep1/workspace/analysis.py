
import json
import numpy as np

req = json.load(open("/input/request.json"))["input"]
G = np.array(req["gain"], dtype=float)
C = np.array(req["noise_cov"], dtype=float)
Y = np.array(req["sensor_data"], dtype=float)
lam2 = float(req["lambda2"])
normalize = bool(req["normalize_noise"])

K = G.T @ np.linalg.inv(G @ G.T + lam2 * C)
S = K @ Y
if normalize:
    d = np.sqrt(np.diag(K @ C @ K.T))
    S = S / d[:, None]

result = {"source_estimates": S.tolist(), "normalized": normalize}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
