Saved /workspace/result.json and /workspace/analysis.py. The program computed the identity-prior minimum-norm inverse K = G.T @ inv(G G.T + 0.25 C) and applied it to sensor_data. normalize_noise is false, so no normalization was applied.

{"source_estimates": [[1.9928866346049747, 1.0087370683656256, 3.8431657568775455, 2.8639336910634516], [2.97564445544094, 1.9755671362518683, 0.29344797191766264, -0.5115313838588501]], "normalized": false}
