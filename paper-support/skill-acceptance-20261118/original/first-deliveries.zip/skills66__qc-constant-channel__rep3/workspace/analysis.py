
import json, sys
sys.path.insert(0, "/workspace")
import numpy as np
import mne
from qc_amplitude import amplitude_qc

req = json.load(open("/input/request.json"))["input"]
sfreq = float(req["sfreq"])
names = list(req["channel_names"])
signal_uV = np.asarray(req["signal_uV"], dtype=float)
data_V = signal_uV * 1e-6  # uV -> V for the amplitude helper

info = mne.create_info(names, sfreq, ch_types="eeg")
raw = mne.io.RawArray(data_V, info, verbose=False)

findings = amplitude_qc(raw)

constant_channels = sorted({s["channel"] for s in findings["constant_segments"]})
rapid_change_channels = sorted({s["channel"] for s in findings["jump_segments"]})
bad_channel_candidates = sorted(findings["bad_channel_candidates"])

result = {
    "constant_channels": constant_channels,
    "rapid_change_channels": rapid_change_channels,
    "bad_channel_candidates": bad_channel_candidates,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
print(json.dumps(findings, default=float)[:3000])
