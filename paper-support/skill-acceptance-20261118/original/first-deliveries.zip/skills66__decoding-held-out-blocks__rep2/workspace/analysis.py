
import json, numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

req = json.load(open("/input/request.json"))["input"]
X = np.array(req["features"], dtype=float)   # trials x time x channels
y = np.array(req["labels"]); g = np.array(req["groups"])
n_trials, n_times, _ = X.shape
groups = np.unique(g)

preds = np.zeros((n_trials, n_times), dtype=int)
acc = np.zeros(n_times)
for t in range(n_times):
    for grp in groups:
        test = g == grp; train = ~test
        clf = make_pipeline(StandardScaler(),
                            LogisticRegression(C=1, solver="liblinear", random_state=42, max_iter=1000))
        clf.fit(X[train, t, :], y[train])
        preds[test, t] = clf.predict(X[test, t, :])
    acc[t] = np.mean(preds[:, t] == y)

chance = max(np.mean(y == c) for c in np.unique(y))
result = {"predictions": preds.tolist(), "accuracy": acc.tolist(), "chance_accuracy": float(chance)}
json.dump(result, open("/workspace/result.json", "w"))
print(acc, chance)
