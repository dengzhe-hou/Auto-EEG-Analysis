Analysis complete. Program saved at /workspace/analysis.py and executed; results saved to /workspace/result.json.

Method: time-resolved decoding, one whole group held out at a time (4 groups of 6 trials). At each of the 3 time samples, StandardScaler and LogisticRegression(C=1, solver="liblinear", random_state=42, max_iter=1000) were fit inside each fold on training groups only.

Outputs:
- predictions: 24 trials × 3 time samples, in original row order
- accuracy per time: [1.0, 0.9583, 1.0]
- chance_accuracy: 0.5 (balanced 12/12 classes)

Note: these are engineering fixtures; no inferential significance testing was performed, per the assignment.
