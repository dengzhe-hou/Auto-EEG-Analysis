{"alpha_peak_hz": 11.0, "psd_uV2_per_hz": 0.8533333333333335}
