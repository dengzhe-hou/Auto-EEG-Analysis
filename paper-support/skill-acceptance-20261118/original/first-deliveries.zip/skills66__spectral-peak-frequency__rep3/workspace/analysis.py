
import json
import numpy as np
from scipy.signal import welch

req = json.load(open('/input/request.json'))['input']
x = np.asarray(req['data_uV'], dtype=float)
fs = float(req['sfreq'])
nperseg = int(req['n_per_seg'])
nfft = int(req['n_fft'])
noverlap = int(req['n_overlap'])

f, psd = welch(
    x, fs=fs, window='hann', nperseg=nperseg, noverlap=noverlap,
    nfft=nfft, detrend='constant', return_onesided=True,
    scaling='density', average='mean'
)
mask = (f >= 8) & (f <= 12)
idx = np.where(mask)[0][np.argmax(psd[mask])]
result = {
    'alpha_peak_hz': float(f[idx]),
    'psd_uV2_per_hz': float(psd[idx]),
}
json.dump(result, open('/workspace/result.json', 'w'), indent=2)
print(result)
