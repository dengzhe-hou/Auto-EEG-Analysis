
import json
import numpy as np
import mne

req = json.load(open("/input/request.json"))["input"]
data_uV = np.array(req["raw_uV"], dtype=float)
data_V = data_uV * 1e-6
sfreq = float(req["sfreq"])
ch_names = req["channel_names"]
ch_types = ["eeg"] * len(ch_names)
info = mne.create_info(ch_names, sfreq, ch_types)
raw = mne.io.RawArray(data_V, info, verbose=False)

events = np.array(req["events"], dtype=int)
event_id = req["event_id"]
tmin, tmax = float(req["tmin"]), float(req["tmax"])
baseline = tuple(req["baseline"]) if req["baseline"] is not None else None
reject = None
if req.get("reject_peak_to_peak_uV") is not None:
    reject = {"eeg": float(req["reject_peak_to_peak_uV"]) * 1e-6}

epochs = mne.Epochs(raw, events, event_id=event_id, tmin=tmin, tmax=tmax,
                    baseline=baseline, reject=reject, preload=True,
                    reject_by_annotation=False, verbose=False)
n_total = len(events)
retained_idx = epochs.selection
retained_event_samples = [int(events[i, 0]) for i in range(n_total) if i in set(retained_idx)]
n_dropped = n_total - len(epochs)
times_s = [float(t) for t in epochs.times]

os.makedirs("/workspace", exist_ok=True) if False else None
epochs.save("/workspace/check-epo.fif", overwrite=True, verbose=False)
result = {
    "retained_event_samples": retained_event_samples,
    "times_s": times_s,
    "n_dropped": int(n_dropped),
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result)[:500])
