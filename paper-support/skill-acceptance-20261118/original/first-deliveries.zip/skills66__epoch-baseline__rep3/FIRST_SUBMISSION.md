{"retained_event_samples": [35, 75, 114], "times_s": [-0.1, -0.09, -0.08, -0.07, -0.06, -0.05, -0.04, -0.03, -0.02, -0.01, 0.0, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.1, 0.11, 0.12, 0.13, 0.14, 0.15, 0.16, 0.17, 0.18, 0.19, 0.2], "n_dropped": 0}

Artifacts saved: /workspace/analysis.py (reusable program), /workspace/check-epo.fif (epochs), /workspace/result.json (results). The epochs used the 2 EEG channels (Fz, Cz) converted from µV to V, sfreq 100 Hz, window −0.1 to 0.2 s, baseline [−0.1, 0], and no peak-to-peak rejection because reject_peak_to_peak_uV was not supplied.
