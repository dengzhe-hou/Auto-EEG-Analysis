
import json, os

REQUIRED = ["roi_mean_uV", "n_trials", "status", "seed"]
SRC = "/input/request.json"
WS = "/workspace"

with open(SRC) as f:
    req = json.load(f)
inp = req["input"]
stage = inp["executed_stage"]

facts = {k: stage.get(k) for k in REQUIRED}
source_file = inp.get("source_file", os.path.basename(SRC))
seed = facts["seed"]

def fmt(v):
    if v is None:
        return "null"
    if isinstance(v, float):
        return f"{round(v, 3):.3f}"
    return str(v)

rows = "\n".join(
    f'    <tr><td>{k}</td><td id="{k}">{fmt(facts[k])}</td></tr>' for k in REQUIRED
)
html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>eeg-report</title></head>
<body>
<h1>EEG executed-stage report</h1>
<table>
{rows}
</table>
</body></html>
"""
with open(os.path.join(WS, "report.html"), "w") as f:
    f.write(html)

receipt = f"""# REPRO_RECEIPT

- Source artifact: {source_file}
- Executed seed: {seed}
- Planned seed (for reference only): {inp.get("planned_seed")}
- Required fields: {", ".join(REQUIRED)}
"""
with open(os.path.join(WS, "REPRO_RECEIPT.md"), "w") as f:
    f.write(receipt)

with open(os.path.join(WS, "result.json"), "w") as f:
    json.dump(facts, f, indent=2)

print(json.dumps(facts))
