# REPRO_RECEIPT

- Source artifact: request.json
- Executed seed: 31
- Planned seed (for reference only): 7
- Required fields: roi_mean_uV, n_trials, status, seed
