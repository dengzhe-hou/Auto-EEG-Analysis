Deliverables written:
- /workspace/analysis.py (saved program, executed successfully)
- /workspace/result.json
- /workspace/methods.md

Methods paragraph: "EEG was acquired at 250 Hz with reference: not recorded. Epochs spanned -0.14 s to 0.68 s relative to event onset, with 15 trials retained after excluding 7 of 22. The executed random seed was 75; the planned seed was 14. A band-pass filter of 0.2-35 Hz was applied."

Machine-readable fields:
sampling_hz = 250
reference = not recorded
retained_trials = 15
seed = 75
epoch_start_s = -0.14
epoch_end_s = 0.68
