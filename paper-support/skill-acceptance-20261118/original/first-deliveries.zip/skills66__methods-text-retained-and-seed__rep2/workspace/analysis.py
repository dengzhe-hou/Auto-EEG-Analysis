import json
req = json.load(open("/input/request.json"))["input"]
acq = req["acquisition"]
ex = req["execution"]
sfreq = acq["sampling_hz"]
reference = acq["reference"] if acq["reference"] is not None else "not recorded"
retained_trials = ex["n_trials"] - ex["n_excluded"]
seed = ex["executed_seed"]
epoch_start_s = ex["epoch_start_sample"] / sfreq
epoch_end_s = ex["epoch_end_sample"] / sfreq
result = {
    "sampling_hz": sfreq,
    "reference": reference,
    "retained_trials": retained_trials,
    "seed": seed,
    "epoch_start_s": epoch_start_s,
    "epoch_end_s": epoch_end_s,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
paragraph = (
    f"EEG was acquired at {sfreq} Hz with reference: {reference}. "
    f"Epochs spanned {epoch_start_s} s to {epoch_end_s} s relative to event onset, "
    f"with {retained_trials} trials retained after excluding {ex['n_excluded']} of {ex['n_trials']}. "
    f"The executed random seed was {seed}; the planned seed was {ex['planned_seed']}. "
    f"A band-pass filter of {ex['band_hz'][0]}-{ex['band_hz'][1]} Hz was applied."
)
lines = [
    "# Methods",
    "",
    paragraph,
    "",
    f"sampling_hz = {sfreq}",
    f"reference = {reference}",
    f"retained_trials = {retained_trials}",
    f"seed = {seed}",
    f"epoch_start_s = {epoch_start_s}",
    f"epoch_end_s = {epoch_end_s}",
    "",
]
open("/workspace/methods.md", "w").write("\n".join(lines))
