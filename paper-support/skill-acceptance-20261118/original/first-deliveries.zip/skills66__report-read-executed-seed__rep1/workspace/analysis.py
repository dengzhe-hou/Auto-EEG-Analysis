
import json, html, os

REQ = "/input/request.json"
WS = "/workspace"
req = json.load(open(REQ))
inp = req["input"]
es = inp["executed_stage"]
source_file = inp["source_file"]
planned_seed = inp["planned_seed"]

fields = ["roi_mean_uV", "n_trials", "status", "seed"]

def fmt_html(v):
    if v is None:
        return "null"
    if isinstance(v, float):
        return f"{round(v, 3):.3f}"
    return str(v)

rows = "\n".join(
    f'<tr><td>{k}</td><td id="{k}">{fmt_html(es.get(k))}</td></tr>' for k in fields
)
report = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>eeg-report</title></head>
<body>
<h1>EEG Report</h1>
<table>
<tr><th>Key</th><th>Value</th></tr>
{rows}
</table>
<p>Source artifact: {html.escape(source_file)}</p>
</body></html>
"""
open(os.path.join(WS, "report.html"), "w").write(report)

receipt = f"""# REPRO_RECEIPT

- Source artifact: {source_file}
- Input path: {REQ}
- Executed seed: {es.get("seed")}
- Planned seed (informational): {planned_seed}
- Status: {es.get("status")}
- roi_mean_uV: {es.get("roi_mean_uV")}
- n_trials: {es.get("n_trials")}
"""
open(os.path.join(WS, "REPRO_RECEIPT.md"), "w").write(receipt)

result = {k: es.get(k) for k in fields}
json.dump(result, open(os.path.join(WS, "result.json"), "w"), indent=2)
print(json.dumps(result))
