# REPRO_RECEIPT

- Source artifact: request.json
- Input path: /input/request.json
- Executed seed: 33
- Planned seed (informational): 7
- Status: available
- roi_mean_uV: -1.465
- n_trials: 45
