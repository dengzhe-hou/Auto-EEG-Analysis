Resampled the three EEG channels (Fz, Cz, Pz) from 100 Hz to 50 Hz using MNE `resample` (method fft, npad=0, boxcar window) with events resampled jointly.

Saved artifacts:
- /workspace/analysis.py (reusable program, executed successfully)
- /workspace/result.json

Result fields:
- new_sfreq: 50.0
- relative_event_samples: [20, 94, 106]
- samples_uV: 3 channels × 200 samples (in µV, no further preprocessing applied)

The output JSON contains exactly the required keys: new_sfreq, relative_event_samples, samples_uV.
