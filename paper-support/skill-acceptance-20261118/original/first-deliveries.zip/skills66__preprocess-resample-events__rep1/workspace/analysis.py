
import json
import numpy as np
import mne

req = json.load(open("/input/request.json"))["input"]
raw_uV = np.array(req["raw_uV"], dtype=float)
names = req["names"]
types = req["types"]
sfreq = float(req["sfreq"])
new_sfreq = float(req["new_sfreq"])
events = np.array(req["events"], dtype=int)

info = mne.create_info(ch_names=names, sfreq=sfreq, ch_types=types)
raw = mne.io.RawArray(raw_uV * 1e-6, info, verbose=False)

# events array carried alongside; resample jointly with events
raw_rs, events_rs = raw.copy().resample(new_sfreq, npad=0, window="boxcar",
                                        method="fft", events=events.copy(),
                                        verbose=False)

new_sf = float(raw_rs.info["sfreq"])
rel_events = events_rs[:, 0].astype(int).tolist()
samples_uV = raw_rs.get_data() * 1e6

result = {
    "new_sfreq": new_sf,
    "relative_event_samples": rel_events,
    "samples_uV": samples_uV.tolist(),
}
json.dump(result, open("/workspace/result.json", "w"))
print("new_sfreq", new_sf)
print("events", rel_events)
print("shape", samples_uV.shape)
