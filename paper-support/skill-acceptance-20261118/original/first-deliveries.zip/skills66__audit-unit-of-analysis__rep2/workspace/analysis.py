import json
req = json.load(open("/input/request.json"))
plan = req["input"]["analysis_plan"]
receipt = req["input"]["execution_receipt"]
fields = ["roi", "window_ms", "contrast", "observation_unit", "unit", "correction"]
issues = sorted([f for f in fields if plan.get(f) != receipt.get(f)])
verdict = "pass" if not issues else "fail"
result = {"verdict": verdict, "issues": issues}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
