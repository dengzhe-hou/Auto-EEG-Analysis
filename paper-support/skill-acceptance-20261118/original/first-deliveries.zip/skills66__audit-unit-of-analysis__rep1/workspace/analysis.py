
import json, os

with open("/input/request.json") as f:
    req = json.load(f)
inp = req["input"]
plan = inp["analysis_plan"]
receipt = inp["execution_receipt"]

fields = ["roi", "window_ms", "contrast", "observation_unit", "unit", "correction"]
issues = sorted([f for f in fields if plan.get(f) != receipt.get(f)])
verdict = "pass" if not issues else "fail"

result = {"verdict": verdict, "issues": issues}
os.makedirs("/workspace", exist_ok=True)
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
