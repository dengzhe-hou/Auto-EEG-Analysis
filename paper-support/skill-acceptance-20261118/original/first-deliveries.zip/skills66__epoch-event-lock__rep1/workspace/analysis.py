
import json, os
import numpy as np
import mne

req = json.load(open("/input/request.json"))["input"]
raw_uV = np.array(req["raw_uV"], dtype=float)
ch_names = req["channel_names"]
sfreq = float(req["sfreq"])
events = np.array(req["events"], dtype=int)
event_id = req["event_id"]
tmin = float(req["tmin"]); tmax = float(req["tmax"])
baseline = req["baseline"]
rej = req["reject_peak_to_peak_uV"]

info = mne.create_info(ch_names, sfreq, ch_types="eeg")
raw = mne.io.RawArray(raw_uV * 1e-6, info, verbose=False)

reject = None
if rej is not None:
    reject = dict(eeg=float(rej) * 1e-6)

epochs = mne.Epochs(raw, events, event_id=event_id, tmin=tmin, tmax=tmax,
                    baseline=tuple(baseline) if baseline is not None else None,
                    reject=reject, preload=True, verbose=False)
epochs.save("/workspace/check-epo.fif", overwrite=True, verbose=False)

retained = epochs.events[:, 0].astype(int).tolist()
times = epochs.times.tolist()
n_total = len(events)
n_dropped = n_total - len(epochs)
result = {"retained_event_samples": retained, "times_s": times, "n_dropped": int(n_dropped)}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
