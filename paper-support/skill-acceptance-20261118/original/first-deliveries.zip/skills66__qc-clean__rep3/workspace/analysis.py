
import json, sys
sys.path.insert(0, "/workspace/analysis")
import numpy as np
import mne
from qc_amplitude import amplitude_qc

req = json.load(open("/input/request.json"))
inp = req["input"]
sig_uv = np.array(inp["signal_uV"], dtype=float)
names = list(inp["channel_names"])
sfreq = float(inp["sfreq"])

# uV -> V for the amplitude helper
data_v = sig_uv * 1e-6
info = mne.create_info(names, sfreq, ch_types="eeg")
raw = mne.io.RawArray(data_v, info, verbose=False)

findings = amplitude_qc(raw, bad_percent=5.0)

constant_channels = sorted({s["channel"] for s in findings["constant_segments"]})
rapid_change_channels = sorted({s["channel"] for s in findings["jump_segments"]})
bad_channel_candidates = sorted(findings["bad_channel_candidates"])

result = {
    "constant_channels": constant_channels,
    "rapid_change_channels": rapid_change_channels,
    "bad_channel_candidates": bad_channel_candidates,
    "details": {
        "constant_segments": findings["constant_segments"],
        "jump_segments": findings["jump_segments"],
        "per_channel": findings["per_channel"],
        "settings": findings["settings"],
    },
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps({k: result[k] for k in ["constant_channels","rapid_change_channels","bad_channel_candidates"]}))
print(json.dumps(findings["per_channel"]))
