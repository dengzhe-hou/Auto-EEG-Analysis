import json
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
eeg_ids = inp["eeg_trial_ids"]
eeg_uv = inp["eeg_uV"]
beh_ids = inp["behavior_trial_ids"]
rt = inp["rt_ms"]

beh_map = dict(zip(beh_ids, rt))
eeg_set = set(eeg_ids)

matched_ids, x, y = [], [], []
for tid, u in zip(eeg_ids, eeg_uv):
    if tid in beh_map:
        matched_ids.append(tid)
        x.append(u)
        y.append(beh_map[tid])

missing_on_eeg = [b for b in beh_ids if b not in eeg_set]

x = np.asarray(x, dtype=float)
y = np.asarray(y, dtype=float)
X = np.column_stack([np.ones_like(x), x])
coef, *_ = np.linalg.lstsq(X, y, rcond=None)
slope = float(coef[1])

result = {
    "trial_ids": [int(t) for t in matched_ids],
    "missing_on_eeg": [int(t) for t in missing_on_eeg],
    "slope_ms_per_uV": slope,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(result)
