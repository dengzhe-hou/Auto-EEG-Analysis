import json
import numpy as np

with open("/input/request.json") as f:
    req = json.load(f)["input"]

eeg_ids = req["eeg_trial_ids"]
eeg_uV = req["eeg_uV"]
beh_ids = req["behavior_trial_ids"]
rt_ms = req["rt_ms"]

rt_by_id = dict(zip(beh_ids, rt_ms))
eeg_set = set(eeg_ids)

trial_ids = []
x = []
y = []
for tid, uv in zip(eeg_ids, eeg_uV):
    if tid in rt_by_id:
        trial_ids.append(tid)
        x.append(uv)
        y.append(rt_by_id[tid])

missing_on_eeg = [tid for tid in beh_ids if tid not in eeg_set]

x = np.asarray(x, dtype=float)
y = np.asarray(y, dtype=float)
X = np.column_stack([np.ones_like(x), x])
coef, *_ = np.linalg.lstsq(X, y, rcond=None)
slope = float(coef[1])

result = {
    "trial_ids": trial_ids,
    "missing_on_eeg": missing_on_eeg,
    "slope_ms_per_uV": slope,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
