Analysis complete. Saved the reusable program to /workspace/analysis.py and the result to /workspace/result.json.

Method: zero-mean Morlet wavelet at 10 Hz, 5 cycles, decim=1, power output, from the supplied epochs (tmin=-1 s, 128 Hz). Values are log10(power / mean baseline power) per channel, with the baseline being the inclusive window [-0.5, -0.125] s, averaged over epochs. Values are reported at the requested sample indices. Checks: wavelet half-support is ~0.40 s, which fits inside the epoch, and the baseline window contains 49 samples.

Result (channels Fz, Cz; times_s = [0.125, 0.21875, 0.40625, 0.71875, 1.109375]):
{
  "values": [
    [0.001719, -0.008786, -0.040888, -0.003997, -0.016104],
    [0.011485, -0.023550, -0.017086, 0.062971, 0.019662]
  ],
  "times_s": [0.125, 0.21875, 0.40625, 0.71875, 1.109375]
}
