
import json, numpy as np
from mne.time_frequency import tfr_array_morlet

req = json.load(open("/input/request.json"))
inp = req["input"]
X = np.array(inp["epochs_uV"], dtype=float)
sfreq = float(inp["sfreq"]); tmin = float(inp["tmin"])
sidx = list(inp["sample_indices"])
freqs = np.array([10.0])
n_cycles = np.array([5.0])
times = tmin + np.arange(X.shape[-1]) / sfreq

# zero-mean Morlet, decim=1, complex output -> power
tfr = tfr_array_morlet(X, sfreq=sfreq, freqs=freqs, n_cycles=n_cycles,
                       zero_mean=True, output="power", decim=1, n_jobs=1)
# shape: epochs x channels x freqs x times
power = tfr[:, :, 0, :]
mean_pow = power.mean(axis=0)  # channels x times

bmask = (times >= -0.5 - 1e-9) & (times <= -0.125 + 1e-9)
base = mean_pow[:, bmask].mean(axis=1)  # per channel
ratio = mean_pow / base[:, None]
logr = np.log10(ratio)

values = [[float(logr[c, i]) for i in sidx] for c in range(X.shape[1])]
times_s = [float(times[i]) for i in sidx]
result = {"values": values, "times_s": times_s}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
