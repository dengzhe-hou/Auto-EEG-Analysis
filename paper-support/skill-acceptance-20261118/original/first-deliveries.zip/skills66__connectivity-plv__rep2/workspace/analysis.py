
import json
import numpy as np

with open("/input/request.json") as f:
    req = json.load(f)["input"]

pa = np.asarray(req["phase_a"], dtype=float)
pb = np.asarray(req["phase_b"], dtype=float)
assert pa.shape == pb.shape
n_samples = int(pa.size)
plv = float(np.abs(np.mean(np.exp(1j * (pa - pb)))))

result = {"plv": plv, "n_samples": n_samples}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
