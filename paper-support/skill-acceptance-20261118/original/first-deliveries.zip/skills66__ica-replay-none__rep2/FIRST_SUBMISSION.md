{"cleaned_uV": "saved at /workspace/result.json (shape 3 channels x 40 samples; equals A @ W @ centered data since no components were excluded)", "applied_exclusions": []}
