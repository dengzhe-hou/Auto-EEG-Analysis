
import json, os
import numpy as np
import mne
from mne_bids import BIDSPath, write_raw_bids, read_raw_bids

with open("/input/request.json") as f:
    inp = json.load(f)["input"]

sfreq = float(inp["sfreq"])
data = np.array(inp["data_uV"], dtype=float) * 1e-6  # uV -> V
info = mne.create_info(inp["channel_names"], sfreq, ch_types=inp["types"])
raw = mne.io.RawArray(data, info, first_samp=int(inp["first_samp"]), verbose=False)
raw.info["bads"] = list(inp["bads"])
raw.info["line_freq"] = inp["line_freq"]

ev = np.array(inp["events_original_samples"], dtype=int)
events = ev.copy()
events[:, 0] = ev[:, 0] + int(inp["first_samp"])
events_arr = events

bids_root = "/workspace/bids"
os.makedirs(bids_root, exist_ok=True)
bids_path = BIDSPath(subject="01", task="check", root=bids_root, datatype="eeg")
write_raw_bids(
    raw,
    bids_path,
    events=events_arr,
    event_id=inp["event_id"],
    overwrite=True,
    allow_preload=True,
    format="BrainVision",
    verbose=False,
)

raw_back = read_raw_bids(bids_path, verbose=False)
ev_back = mne.find_events(raw_back, verbose=False) if False else None
from mne_bids import read_raw_bids as _r
import glob
evfile = glob.glob(os.path.join(bids_root, "sub-01", "eeg", "*_events.tsv"))
import pandas as pd
ev_df = pd.read_csv(evfile[0], sep="\t") if evfile else None
samples_back = (ev_df["onset"].values * sfreq).round().astype(int) if ev_df is not None else None
rel = [int(s - raw_back.first_samp) for s in samples_back] if samples_back is not None else []

result = {
    "relative_event_samples": rel,
    "bad_channels": list(raw_back.info["bads"]),
    "sfreq": float(raw_back.info["sfreq"]),
}
os.makedirs("/workspace", exist_ok=True)
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
