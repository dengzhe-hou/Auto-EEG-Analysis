
import json
import numpy as np

with open("/input/request.json") as f:
    req = json.load(f)
labels = req["input"]["labels"]

K = 3
counts = np.zeros((K, K), dtype=int)
for a, b in zip(labels[:-1], labels[1:]):
    # skip adjacent repeats, pairs touching -1; no bridging across gaps
    if a == b or a == -1 or b == -1:
        continue
    if a in range(K) and b in range(K):
        counts[a, b] += 1

probs = np.zeros((K, K), dtype=float)
for i in range(K):
    rs = counts[i].sum()
    if rs > 0:
        probs[i] = counts[i] / rs

result = {
    "counts": counts.tolist(),
    "probabilities": [[round(float(x), 6) for x in row] for row in probs],
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
