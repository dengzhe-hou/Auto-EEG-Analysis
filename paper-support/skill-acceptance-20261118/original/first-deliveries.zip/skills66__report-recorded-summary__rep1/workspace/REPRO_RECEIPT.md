# REPRO_RECEIPT

- Source artifact: request.json
- Executed seed: 31
- Planned seed (not used for results): 7
- Stage status: available
- Trials: 43
- ROI mean (uV): -1.725
