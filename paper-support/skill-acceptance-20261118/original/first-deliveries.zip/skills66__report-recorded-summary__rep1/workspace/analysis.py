
import json, os, html

req = json.load(open("/input/request.json"))["input"]
stage = req["executed_stage"]
source_file = req["source_file"]
planned_seed = req["planned_seed"]

def fmt(v):
    if v is None:
        return "null"
    if isinstance(v, float):
        return f"{round(v, 3):.3f}"
    return str(v)

fields = ["roi_mean_uV", "n_trials", "status", "seed"]
values = {k: stage.get(k) for k in fields}

# result.json: full precision, executed seed
result = {k: values[k] for k in fields}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)

# report.html: rounded continuous values in HTML only
rows = "\n".join(
    f'<tr><td>{k}</td><td id="{k}">{html.escape(fmt(values[k]))}</td></tr>'
    for k in fields
)
report = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>eeg-report</title></head>
<body>
<h1>EEG report</h1>
<table>
{rows}
</table>
<p>Source artifact: {html.escape(source_file)}</p>
</body></html>
"""
with open("/workspace/report.html", "w") as f:
    f.write(report)

receipt = f"""# REPRO_RECEIPT

- Source artifact: {source_file}
- Executed seed: {values['seed']}
- Planned seed (not used for results): {planned_seed}
- Stage status: {values['status']}
- Trials: {values['n_trials']}
- ROI mean (uV): {values['roi_mean_uV']}
"""
with open("/workspace/REPRO_RECEIPT.md", "w") as f:
    f.write(receipt)

print(open("/workspace/result.json").read())
