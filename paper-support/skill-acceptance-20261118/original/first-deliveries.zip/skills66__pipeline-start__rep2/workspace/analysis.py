import json

with open("/input/request.json") as f:
    request = json.load(f)["input"]

dependencies = request["dependencies"]
status = request.get("status", {})

passed = {s for s, v in status.items() if v == "passed"}
failed = {s for s, v in status.items() if v == "failed"}

reused, runnable, blocked = [], [], []

# Resolve in topological order so downstream blocking propagates.
order = []
visited = set()
def visit(s):
    if s in visited:
        return
    for d in dependencies.get(s, []):
        visit(d)
    visited.add(s)
    order.append(s)
for s in dependencies:
    visit(s)

resolved_ok = set()
for s in order:
    deps = dependencies.get(s, [])
    if s in passed:
        reused.append(s)
        resolved_ok.add(s)
    elif s in failed:
        blocked.append(s)
    elif all(d in resolved_ok for d in deps):
        runnable.append(s)
    else:
        blocked.append(s)

result = {
    "reused": sorted(reused),
    "runnable": sorted(runnable),
    "blocked": sorted(blocked),
}
with open("/workspace/analysis.py", "w") as f:
    f.write(program)
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
