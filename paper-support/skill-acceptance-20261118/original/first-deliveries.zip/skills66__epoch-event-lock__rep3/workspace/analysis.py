
import json, os
import numpy as np
import mne

mne.set_log_level("WARNING")
os.makedirs("/workspace", exist_ok=True)

req = json.load(open("/input/request.json"))
inp = req["input"]

data_uV = np.array(inp["raw_uV"], dtype=float)      # shape (n_ch, n_samp)
ch_names = inp["channel_names"]
sfreq = float(inp["sfreq"])
events = np.array(inp["events"], dtype=int)
event_id = inp["event_id"]
tmin, tmax = float(inp["tmin"]), float(inp["tmax"])
baseline = inp["baseline"]
rej_uV = inp["reject_peak_to_peak_uV"]

# Convert uV -> V for MNE
data_V = data_uV * 1e-6
info = mne.create_info(ch_names, sfreq, ch_types="eeg")
raw = mne.io.RawArray(data_V, info, verbose=False)

reject = None
if rej_uV is not None:
    reject = dict(eeg=float(rej_uV) * 1e-6)

epochs = mne.Epochs(
    raw, events, event_id=event_id, tmin=tmin, tmax=tmax,
    baseline=tuple(baseline) if baseline is not None else None,
    reject=reject, preload=True, verbose=False,
)

n_before = len(events)
retained_event_samples = [int(s) for s in epochs.events[:, 0]]
n_dropped = int(n_before - len(epochs))
times_s = [float(t) for t in epochs.times]

epochs.save("/workspace/check-epo.fif", overwrite=True, verbose=False)

result = {
    "retained_event_samples": retained_event_samples,
    "times_s": times_s,
    "n_dropped": n_dropped,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps({"retained_event_samples": retained_event_samples,
                  "n_times": len(times_s), "times_first_last": [times_s[0], times_s[-1]],
                  "n_dropped": n_dropped}))
