import json, html, os
req = json.load(open("/input/request.json"))["input"]
rec = req["executed_stage"]
src = req["source_file"]
facts = {k: rec[k] for k in ["roi_mean_uV","n_trials","status","seed"]}
def fmt(v):
    if v is None: return "null"
    if isinstance(v, float): return f"{v:.3f}"
    return str(v)
rows = "\n".join(f'<p>{k}: <span id="{k}">{html.escape(fmt(v))}</span></p>' for k, v in facts.items())
report = "<!DOCTYPE html>\n<html><head><meta charset=\"utf-8\"><title>EEG report</title></head>\n<body>\n<h1>EEG executed-stage report</h1>\n" + rows + "\n</body></html>\n"
receipt = f"""# REPRO_RECEIPT

- Source artifact: {src}
- Executed seed: {rec["seed"]}
- Planned seed (not used for execution): {req["planned_seed"]}
- Status: {rec["status"]}
- roi_mean_uV: {fmt(rec["roi_mean_uV"])}
- n_trials: {rec["n_trials"]}
"""
os.makedirs("/workspace", exist_ok=True)
open("/workspace/report.html","w").write(report)
open("/workspace/REPRO_RECEIPT.md","w").write(receipt)
json.dump(facts, open("/workspace/result.json","w"), indent=2)
