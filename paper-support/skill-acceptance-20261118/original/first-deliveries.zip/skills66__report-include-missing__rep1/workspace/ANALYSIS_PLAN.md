Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-report. Input: /input/request.json. Use its input field.
Write report.html and REPRO_RECEIPT.md from the supplied executed-stage record. Use an HTML element with id matching each required key and its value as plain text (use "null" for missing value); round continuous values to 3 decimals in HTML only. Include the literal source artifact filename and executed seed in the reproducibility receipt. Return result.json with the same four facts at full precision.
The required fields are roi_mean_uV, n_trials, status, seed. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
