Deliverables written under /workspace:

- report.html: an HTML element for each required key, with plain-text values:
  - roi_mean_uV: null
  - n_trials: 44
  - status: unavailable
  - seed: 32
- REPRO_RECEIPT.md: names the source artifact (request.json) and the executed seed (32). It also records planned seed 7 as not used for execution.
- result.json:
```json
{
  "roi_mean_uV": null,
  "n_trials": 44,
  "status": "unavailable",
  "seed": 32
}
```
- analysis.py: the reusable program that produces all three outputs. I executed it, and its outputs match the values above.

roi_mean_uV is null because the supplied executed-stage record has no value for it, and status is "unavailable", so no ROI mean was computed.
