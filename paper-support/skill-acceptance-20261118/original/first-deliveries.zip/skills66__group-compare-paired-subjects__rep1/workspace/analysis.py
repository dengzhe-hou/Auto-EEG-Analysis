import json
import numpy as np
from scipy import stats

req = json.load(open("/input/request.json"))
A = np.asarray(req["input"]["A"], dtype=float)
B = np.asarray(req["input"]["B"], dtype=float)
t, p = stats.ttest_rel(A, B, alternative="two-sided")
result = {
    "statistic": float(t),
    "p_value": float(p),
    "n_per_group": [int(A.size), int(B.size)],
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
