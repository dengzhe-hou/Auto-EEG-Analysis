
import json
import math
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
x = np.asarray(inp["series"], dtype=float)
m = int(inp["m"])
r = float(inp["r"])
N = len(x)

def phi(mm):
    n_windows = N - mm + 1
    emb = np.array([x[i:i+mm] for i in range(n_windows)])
    logs = []
    for i in range(n_windows):
        d = np.max(np.abs(emb - emb[i]), axis=1)
        c = np.sum(d < r)  # strict, includes self-match
        logs.append(math.log(c / n_windows))
    return float(np.mean(logs))

phi_m = phi(m)
phi_m1 = phi(m + 1)
apen = phi_m - phi_m1

result = {
    "phi_m": phi_m,
    "phi_m_plus_1": phi_m1,
    "approximate_entropy": apen,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result, indent=2))
