
import json, os, numpy as np
req = json.load(open("/input/request.json"))["input"]
X = np.array(req["channel_data_uV"], dtype=float)
W = np.array(req["unmixing"], dtype=float)
A = np.array(req["mixing"], dtype=float)
excl = [int(i) for i in req.get("approved_exclusions", [])]
S = W @ X
S_clean = S.copy()
for i in excl:
    S_clean[i, :] = 0.0
Xc = A @ S_clean
result = {"cleaned_uV": Xc.tolist(), "applied_exclusions": excl}
os.makedirs("/workspace", exist_ok=True)
json.dump(result, open("/workspace/result.json", "w"))
print("max_abs_diff_vs_input", float(np.max(np.abs(Xc - X))))
print("exclusions", excl)
