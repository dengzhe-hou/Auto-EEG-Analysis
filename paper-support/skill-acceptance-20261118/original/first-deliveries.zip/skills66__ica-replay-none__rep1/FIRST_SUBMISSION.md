{"cleaned_uV": "3x40 array saved in /workspace/result.json", "applied_exclusions": []}
