import json
import numpy as np
from scipy.signal import fftconvolve

req = json.load(open("/input/request.json"))["input"]
E = np.array(req["epochs_uV"], dtype=float)
sfreq = float(req["sfreq"]); tmin = float(req["tmin"])
idx = req["sample_indices"]; channels = req["channels"]
freq = 10.0; n_cycles = 5.0

sigma_t = n_cycles / (2*np.pi*freq)
half = int(np.ceil(5*sigma_t*sfreq))
t = np.arange(-half, half+1)/sfreq
wav = np.exp(2j*np.pi*freq*t) * np.exp(-t**2/(2*sigma_t**2))
wav = wav - wav.mean()
wav /= np.sqrt(np.sum(np.abs(wav)**2))

n_trials, n_ch, n_t = E.shape
coef = np.zeros((n_trials, n_ch, n_t), dtype=complex)
for tr in range(n_trials):
    for c in range(n_ch):
        coef[tr, c] = fftconvolve(E[tr, c], wav, mode="same")

phase = coef / np.abs(coef)
itc = np.abs(phase.mean(axis=0))

values = [[float(itc[c, s]) for c in range(n_ch)] for s in idx]
times_s = [float(tmin + s/sfreq) for s in idx]
result = {"values": values, "times_s": times_s}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
