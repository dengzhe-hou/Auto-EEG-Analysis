Completed the eeg-tfr ITC computation. Morlet wavelet at 10 Hz, 5 cycles, decim=1, tmin=-1 s, no other preprocessing. ITC computed from single-trial complex coefficients per channel (Fz, Cz) at sample_indices [144, 156, 180, 220, 270].

Deliverables:
- /workspace/analysis.py (reusable program, executed)
- /workspace/result.json, containing fields `values` (5 sample indices × 2 channels) and `times_s`.

Result check: `values` has 5 rows × 2 columns; `times_s` has 5 entries.

Output:
{"values": [[0.99289, 0.99959], [0.99578, 0.99908], [0.99885, 0.99922], [0.98924, 0.99807], [0.99236, 0.99588]], "times_s": [0.125, 0.21875, 0.40625, 0.71875, 1.109375]}
