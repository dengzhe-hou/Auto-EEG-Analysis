
import json
import numpy as np

with open("/input/request.json") as f:
    req = json.load(f)
inp = req["input"]

cond = np.array(inp["condition"])
correct = np.array(inp["correct"], dtype=bool)
rt = np.array(inp["rt_ms"], dtype=float)

accuracy = []
mean_rt = []
retained = []
for c in ["A", "B"]:
    m = cond == c
    accuracy.append(float(np.mean(correct[m])))
    keep = m & correct
    retained.append(int(np.sum(keep)))
    mean_rt.append(float(np.mean(rt[keep])) if np.sum(keep) > 0 else None)

result = {
    "accuracy": accuracy,
    "mean_rt_ms": mean_rt,
    "retained_rt_trials": retained,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
