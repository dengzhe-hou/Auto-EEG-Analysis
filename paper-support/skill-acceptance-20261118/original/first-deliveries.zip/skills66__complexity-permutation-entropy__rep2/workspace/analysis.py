
import json, math
from collections import Counter
from itertools import permutations

with open("/input/request.json") as f:
    req = json.load(f)
series = req["input"]["series"]
order, delay = 3, 1

patterns = [tuple(p) for p in permutations(range(order))]
pattern_counts_map = Counter()
n_windows = len(series) - (order - 1) * delay
for i in range(n_windows):
    window = series[i:i + order * delay:delay]
    # ordinal pattern: argsort of window values (ties broken by position)
    pat = tuple(sorted(range(order), key=lambda k: (window[k], k)))
    pattern_counts_map[pat] += 1

pattern_counts = [pattern_counts_map.get(p, 0) for p in patterns]
total = sum(pattern_counts)
probs = [c / total for c in pattern_counts if c > 0]
H = -sum(p * math.log(p) for p in probs)
normalized_perm_entropy = H / math.log(math.factorial(order))

result = {
    "pattern_counts": pattern_counts,
    "normalized_perm_entropy": normalized_perm_entropy,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
