
import json
import numpy as np
import mne

req = json.load(open("/input/request.json"))["input"]
data = np.array(req["raw_uV"], dtype=float)
names = req["names"]; types = req["types"]
sfreq = float(req["sfreq"]); new_sfreq = float(req["new_sfreq"])
events = np.array(req["events"], dtype=int)

info = mne.create_info(ch_names=names, sfreq=sfreq, ch_types=types)
raw = mne.io.RawArray(data * 1e-6, info, verbose=False)
_, new_events = raw.resample(new_sfreq, npad=0, window="boxcar", method="fft",
                             events=events.copy(), verbose=False)

result = {
    "new_sfreq": float(raw.info["sfreq"]),
    "relative_event_samples": [int(e) for e in new_events[:, 0]],
    "samples_uV": (raw.get_data() * 1e6).tolist(),
}
json.dump(result, open("/workspace/result.json", "w"))
print(result["new_sfreq"], result["relative_event_samples"])
