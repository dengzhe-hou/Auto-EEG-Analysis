{"new_sfreq": 50.0, "relative_event_samples": [20, 94, 106], "samples_uV": "saved in /workspace/result.json (3 channels x 200 samples)"}
