import json
import numpy as np
from scipy import stats

req = json.load(open("/input/request.json"))
a = np.asarray(req["input"]["group_a"], dtype=float)
b = np.asarray(req["input"]["group_b"], dtype=float)

t, p = stats.ttest_ind(a, b, equal_var=False)

result = {
    "statistic": float(t),
    "p_value": float(p),
    "n_per_group": [int(a.size), int(b.size)],
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(result)
