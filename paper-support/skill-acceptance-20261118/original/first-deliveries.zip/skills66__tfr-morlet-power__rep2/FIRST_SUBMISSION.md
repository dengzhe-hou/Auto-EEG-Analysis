The analysis ran and the result is saved.

- Program: /workspace/analysis.py (executed successfully)
- Output: /workspace/result.json, containing `values` (average Morlet power in uV² per channel at the requested samples) and `times_s` (times relative to tmin = -1 s), plus channels, units, and sample_indices for traceability.

Result values (uV², channels Fz, Cz, sample indices 144, 156, 180, 220, 270):
- Fz: [8.350, 8.151, 7.570, 8.241, 8.014]
- Cz: [30.776, 28.390, 28.816, 34.649, 31.360]

times_s: [0.125, 0.21875, 0.40625, 0.71875, 1.109375]

Method: zero-mean complex Morlet, 10 Hz, 5 cycles, decim=1, no other preprocessing. Power was computed as |TFR|² and averaged across epochs. Epoch data were flattened to (epochs×channels, samples) to satisfy the MNE cwt interface, then reshaped back before averaging. No baseline correction was applied, as specified.

Edge check: the 10 Hz, 5-cycle wavelet has a half-support of about 0.399 s. The requested samples at 0.125 s and 0.219 s lie within the first 0.4 s of the epoch, so edge effects may influence those early values. The task specified no additional cropping, so I reported them as requested and note this caveat.
