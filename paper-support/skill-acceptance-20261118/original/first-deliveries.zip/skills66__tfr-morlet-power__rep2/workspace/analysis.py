
import json
import numpy as np
from mne.time_frequency import morlet
from mne.time_frequency.tfr import cwt

req = json.load(open("/input/request.json"))["input"]
ep = np.array(req["epochs_uV"], dtype=float)  # (epochs, channels, samples)
sfreq = float(req["sfreq"]); tmin = float(req["tmin"])
idx = [int(i) for i in req["sample_indices"]]
chans = req["channels"]
n_ep, n_ch, n_t = ep.shape

freqs = np.array([10.0]); n_cycles = np.array([5.0])
W = morlet(sfreq, freqs, n_cycles=n_cycles, zero_mean=True)
flat = ep.reshape(n_ep * n_ch, n_t)
out = cwt(flat, W, use_fft=True, mode="same", decim=1)  # (signals, freqs, times)
out = out.reshape(n_ep, n_ch, out.shape[-2], out.shape[-1])
power = np.abs(out) ** 2
avg = power.mean(axis=0)[:, 0, :]  # (channels, times)

values = [[float(avg[c, i]) for i in idx] for c in range(avg.shape[0])]
times_s = [float(tmin + i / sfreq) for i in idx]
result = {"values": values, "times_s": times_s, "channels": chans,
          "units": "uV^2", "sample_indices": idx}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
