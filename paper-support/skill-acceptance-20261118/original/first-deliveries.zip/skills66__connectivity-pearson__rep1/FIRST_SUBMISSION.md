{"edges": [{"pair": "Fz-Cz", "value": -0.971270995623145}, {"pair": "Fz-Pz", "value": 0.7417381199564247}, {"pair": "Cz-Pz", "value": -0.6282808624375432}]}
