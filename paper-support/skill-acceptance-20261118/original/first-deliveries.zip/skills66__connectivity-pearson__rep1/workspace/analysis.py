
import json
import numpy as np

req = json.load(open("/input/request.json"))["input"]
chans = req["channels"]
sig = np.array(req["signal"], dtype=float)
idx = {c: i for i, c in enumerate(chans)}

def pearson(a, b):
    return float(np.corrcoef(a, b)[0, 1])

pairs = [("Fz", "Cz"), ("Fz", "Pz"), ("Cz", "Pz")]
edges = []
for a, b in pairs:
    r = pearson(sig[idx[a]], sig[idx[b]])
    edges.append({"pair": f"{a}-{b}", "value": r})

result = {"edges": edges}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result, indent=2))
