
import json, re

REQ = json.load(open("/input/request.json"))["input"]
recipe_md = open("/workspace/aea/recipes/n400-semantic/RECIPE.md").read()
fm = recipe_md.split("---")[1]

def fm_val(key):
    m = re.search(r"^" + key + r":\s*(.+)$", fm, re.M)
    return m.group(1).strip().strip('"') if m else None

version = fm_val("version")
min_channels = int(fm_val("min_channels"))
min_sfreq = int(fm_val("min_sfreq"))
min_trials = int(fm_val("min_trials_per_condition"))
req_line = fm_val("required_markers")
required = [x.strip() for x in req_line.strip("[]").split(",")]

counts = REQ["marker_counts"]
missing = sorted([m for m in required if m not in counts])
insufficient = sorted([m for m in required if m in counts and counts[m] < min_trials])

eligible = (len(missing) == 0 and len(insufficient) == 0
            and REQ["channel_count"] >= min_channels
            and REQ["sfreq"] >= min_sfreq)

result = {
    "eligible": eligible,
    "missing_markers": missing,
    "insufficient_present_markers": insufficient,
    "recipe_version": version,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result, indent=2))
