Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-bids. Input: /input/request.json. Use its input field.
Build an MNE Raw from the input, converting uV to V and preserving channel types, bad status and first_samp. Write EEG-BIDS in BrainVision format with mne-bids under bids/, subject 01, task check, no session or run. Preserve the supplied event semantics and sample identities. Set synthetic EEG reference to "synthetic common reference" and line_freq as supplied. Read back and report relative_event_samples (relative to first saved sample), bad_channels, and sfreq.
The required fields are relative_event_samples, bad_channels, sfreq. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
