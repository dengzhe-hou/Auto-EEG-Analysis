
import json, os, numpy as np, mne
from mne_bids import BIDSPath, write_raw_bids, read_raw_bids

inp = json.load(open("/input/request.json"))["input"]
data = np.array(inp["data_uV"], dtype=float) * 1e-6  # uV -> V
info = mne.create_info(inp["channel_names"], inp["sfreq"], ch_types=inp["types"])
raw = mne.io.RawArray(data, info, first_samp=inp["first_samp"], verbose=False)
raw.info["bads"] = list(inp["bads"])

ev = np.array(inp["events_original_samples"], dtype=int)
onsets = (ev[:, 0] - inp["first_samp"]) / inp["sfreq"]
durations = np.zeros(len(ev))
inv = {v: k for k, v in inp["event_id"].items()}
descs = [inv[c] for c in ev[:, 2]]
raw.set_annotations(mne.Annotations(onsets, durations, descs))

bids_root = "/workspace/bids"
bp = BIDSPath(subject="01", task="check", root=bids_root, datatype="eeg")
write_raw_bids(raw, bp, format="BrainVision", allow_preload=True, overwrite=True,
               verbose=False)

# set reference and line frequency in the EEG sidecar
import glob
side = glob.glob(os.path.join(bids_root, "sub-01", "eeg", "*_eeg.json"))[0]
meta = json.load(open(side))
meta["EEGReference"] = "synthetic common reference"
meta["PowerLineFrequency"] = inp["line_freq"]
json.dump(meta, open(side, "w"), indent=4)

raw2 = read_raw_bids(bp, verbose=False)
sf = float(raw2.info["sfreq"])
rel_samples = sorted(int(round(o * sf)) for o in raw2.annotations.onset)
res = {
    "relative_event_samples": rel_samples,
    "bad_channels": list(raw2.info["bads"]),
    "sfreq": sf,
}
os.makedirs("/workspace", exist_ok=True)
json.dump(res, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(res))
