import json, numpy as np, mne
req = json.load(open("/input/request.json")); inp = req["input"]
data = np.array(inp["data_uV"], dtype=float) * 1e-6
info = mne.create_info(inp["channel_names"], inp["sfreq"], inp["types"])
raw = mne.io.RawArray(data, info, first_samp=inp["first_samp"], verbose=False)
raw.info["bads"] = list(inp["bads"]); raw.info["line_freq"] = inp["line_freq"]
ev = np.array(inp["events_original_samples"], dtype=int)
rel = ev[:, 0] - raw.first_samp
res = {"relative_event_samples": [int(x) for x in rel], "bad_channels": list(raw.info["bads"]), "sfreq": float(raw.info["sfreq"])}
json.dump(res, open("/workspace/result.json", "w"), indent=2)
print(res)
