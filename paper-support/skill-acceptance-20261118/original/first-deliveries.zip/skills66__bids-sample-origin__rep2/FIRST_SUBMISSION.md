{
  "relative_event_samples": [117, 270, 439],
  "bad_channels": [],
  "sfreq": 128.0,
  "status": "partial",
  "notes": "mne-bids not installed and no network to install it; BrainVision EEG-BIDS export under bids/ (sub-01, task-check) was NOT produced. Values computed from the MNE Raw object (uV->V, first_samp preserved) and events relative to first_samp. Saved /workspace/analysis.py and /workspace/result.json."
}
