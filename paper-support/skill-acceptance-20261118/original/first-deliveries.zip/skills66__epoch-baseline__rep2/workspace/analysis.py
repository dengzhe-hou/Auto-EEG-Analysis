
import json, numpy as np, mne
req = json.load(open("/input/request.json"))
inp = req["input"]
data = np.array(inp["raw_uV"], dtype=float) * 1e-6
info = mne.create_info(inp["channel_names"], inp["sfreq"], ch_types="eeg")
raw = mne.io.RawArray(data, info, verbose=False)
events = np.array(inp["events"], dtype=int)
event_id = inp["event_id"]
reject = None
if inp.get("reject_peak_to_peak_uV") is not None:
    reject = {"eeg": inp["reject_peak_to_peak_uV"] * 1e-6}
epochs = mne.Epochs(raw, events, event_id=event_id, tmin=inp["tmin"], tmax=inp["tmax"],
                    baseline=tuple(inp["baseline"]), reject=reject, preload=True,
                    verbose=False)
epochs.save("/workspace/check-epo.fif", overwrite=True, verbose=False)
n_total = len(events)
retained = epochs.events[:, 0].tolist()
result = {
    "retained_event_samples": retained,
    "times_s": [float(t) for t in epochs.times],
    "n_dropped": int(n_total - len(epochs)),
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
