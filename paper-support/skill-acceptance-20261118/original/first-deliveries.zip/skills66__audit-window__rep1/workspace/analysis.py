import os
import json
req = json.load(open("/input/request.json"))["input"]
plan = req["analysis_plan"]
receipt = req["execution_receipt"]
fields = ["roi", "window_ms", "contrast", "observation_unit", "unit", "correction"]
issues = sorted([f for f in fields if plan.get(f) != receipt.get(f)])
verdict = "pass" if not issues else "fail"
result = {"verdict": verdict, "issues": issues}
os.makedirs("/workspace", exist_ok=True)
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
