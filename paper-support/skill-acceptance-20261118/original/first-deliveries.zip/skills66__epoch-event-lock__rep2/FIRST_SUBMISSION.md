Saved /workspace/analysis.py, /workspace/result.json, and /workspace/check-epo.fif.

Result (retained_event_samples, times_s, n_dropped):
- retained_event_samples: [35, 75, 114]
- times_s: 31 samples from -0.1 to 0.2 s at 0.01 s step (100 Hz)
- n_dropped: 0

Epochs were built from the source EEG converted from uV to V, using the supplied events, tmin=-0.1, tmax=0.2, and baseline=None. No peak-to-peak rejection was applied because reject_peak_to_peak_uV was not supplied. All 3 events were retained.
