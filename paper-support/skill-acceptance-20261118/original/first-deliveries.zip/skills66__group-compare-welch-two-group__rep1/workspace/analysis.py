
import json
import numpy as np
from scipy import stats

with open("/input/request.json") as f:
    req = json.load(f)

inp = req["input"]
a = np.asarray(inp["group_a"], dtype=float)
b = np.asarray(inp["group_b"], dtype=float)

res = stats.ttest_ind(a, b, equal_var=False, alternative="two-sided")
result = {
    "statistic": float(res.statistic),
    "p_value": float(res.pvalue),
    "n_per_group": [int(a.size), int(b.size)],
}

with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
