
import json

req = json.load(open("/input/request.json"))["input"]
header = {
    "recipe_version": "v0.1.0",
    "min_channels": 16,
    "min_sfreq": 200,
    "min_trials_per_condition": 30,
    "required_markers": ["stimulus/related", "stimulus/unrelated"],
}
counts = req["marker_counts"]
missing = sorted(m for m in header["required_markers"] if m not in counts)
insufficient = sorted(
    m for m in header["required_markers"]
    if m in counts and counts[m] < header["min_trials_per_condition"]
)
eligible = (
    req["channel_count"] >= header["min_channels"]
    and req["sfreq"] >= header["min_sfreq"]
    and not missing
    and not insufficient
)
result = {
    "eligible": eligible,
    "missing_markers": missing,
    "insufficient_present_markers": insufficient,
    "recipe_version": header["recipe_version"],
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
