The EEG ERP test ran successfully.

- Program: /workspace/analysis.py (executed; exit code 0)
- Evoked output: /workspace/check-ave.fif (condition A mean evoked, 3 channels)
- Result: /workspace/result.json

Results:
- roi_mean_uV: -0.0030618166539813107 (equal-weight mean over Cz and Pz, inclusive 0.1–0.3 s)
- n_window_samples: 21
- n_condition_trials: [2, 3] (count A, count B)

Notes: The input epochs were used as supplied, in microvolts converted to volts for MNE and back for the reported value. No additional filtering, rejection, or equalization was applied. Trial counts are unequal (2 vs 3), which was reported but not equalized, per the task settings.
