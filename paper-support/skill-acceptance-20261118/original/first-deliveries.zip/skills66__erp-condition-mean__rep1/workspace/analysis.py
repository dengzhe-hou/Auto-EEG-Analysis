
import json, numpy as np, mne
mne.set_log_level("ERROR")
inp = json.load(open("/input/request.json"))["input"]
data = np.array(inp["epochs_uV"], dtype=float) * 1e-6  # uV -> V for MNE
labels = inp["labels"]
ch_names = inp["channel_names"]
sfreq = float(inp["sfreq"])
tmin = float(inp["tmin"])
info = mne.create_info(ch_names, sfreq, ch_types="eeg")
codes = np.array([1 if l == "A" else 2 for l in labels])
events = np.column_stack([np.arange(len(labels)), np.zeros(len(labels), int), codes])
epochs = mne.EpochsArray(data, info, events=events, tmin=tmin, event_id={"A": 1, "B": 2}, verbose=False)
evoked_A = epochs["A"].average()
evoked_A.save("/workspace/check-ave.fif", overwrite=True)
times = evoked_A.times
mask = (times >= 0.1 - 1e-9) & (times <= 0.3 + 1e-9)
idx = [ch_names.index("Cz"), ch_names.index("Pz")]
roi_uV = float(np.mean(evoked_A.data[idx][:, mask]) * 1e6)
n_window = int(mask.sum())
n_A = int(np.sum(np.array(labels) == "A"))
n_B = int(np.sum(np.array(labels) == "B"))
result = {"roi_mean_uV": roi_uV, "n_window_samples": n_window, "n_condition_trials": [n_A, n_B]}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
