Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-erp. Input: /input/request.json. Use its input field.
Build MNE epochs using the supplied clean epoch arrays, with no additional processing. Calculate the condition A mean evoked waveform for all three channels. Save a single evoked to check-ave.fif. Return roi_mean_uV (equal weight over Cz/Pz and inclusive 0.1–0.3 s), n_window_samples, and n_condition_trials as [count A, count B].
The required fields are roi_mean_uV, n_window_samples, n_condition_trials. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
