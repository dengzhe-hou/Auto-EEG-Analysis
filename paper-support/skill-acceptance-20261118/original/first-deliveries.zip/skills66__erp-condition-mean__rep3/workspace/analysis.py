
import json
import numpy as np
import mne

req = json.load(open("/input/request.json"))
inp = req["input"]

data = np.array(inp["epochs_uV"], dtype=float) * 1e-6  # uV -> V for MNE
labels = np.array(inp["labels"])
ch_names = inp["channel_names"]
sfreq = float(inp["sfreq"])
tmin = float(inp["tmin"])

info = mne.create_info(ch_names, sfreq, ch_types="eeg")
events = np.column_stack([np.arange(len(labels)), np.zeros(len(labels), int), np.arange(len(labels)) + 1])
event_id = {"A": 1, "B": 2}
ev_codes = np.array([event_id[l] for l in labels])
events[:, 2] = ev_codes
epochs = mne.EpochsArray(data, info, events=events, tmin=tmin, event_id=event_id, verbose=False)

evoked_A = epochs["A"].average()
evoked_A.save("/workspace/check-ave.fif", overwrite=True, verbose=False)

# ROI: Cz and Pz, window 0.1-0.3 s inclusive, equal weight
ch_idx = [evoked_A.ch_names.index(c) for c in ["Cz", "Pz"]]
times = evoked_A.times
win = (times >= 0.1 - 1e-12) & (times <= 0.3 + 1e-12)
n_window_samples = int(win.sum())
roi_data = evoked_A.data[ch_idx][:, win] * 1e6  # back to uV
roi_mean_uV = float(roi_data.mean())

n_A = int(np.sum(labels == "A"))
n_B = int(np.sum(labels == "B"))

result = {
    "roi_mean_uV": roi_mean_uV,
    "n_window_samples": n_window_samples,
    "n_condition_trials": [n_A, n_B],
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
