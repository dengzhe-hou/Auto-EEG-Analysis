{
  "eligible": false,
  "missing_markers": [],
  "insufficient_present_markers": ["stimulus/unrelated"],
  "recipe_version": "v0.1.0"
}
