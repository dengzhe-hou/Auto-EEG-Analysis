import json
req = json.load(open('/input/request.json'))['input']
counts = req['marker_counts']
required = ['stimulus/related', 'stimulus/unrelated']
min_trials, min_channels, min_sfreq = 30, 16, 200
missing = sorted([m for m in required if m not in counts])
insufficient = sorted([m for m in required if m in counts and counts[m] < min_trials])
eligible = (not missing) and (not insufficient) and req['channel_count'] >= min_channels and req['sfreq'] >= min_sfreq
result = {'eligible': bool(eligible), 'missing_markers': missing,
          'insufficient_present_markers': insufficient, 'recipe_version': 'v0.1.0'}
json.dump(result, open('/workspace/result.json', 'w'), indent=2)
print(result)
