Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-recipe. Input: /input/request.json. Use its input field.
Check applicability of the AEA n400-semantic recipe from its frozen RECIPE.md header. Verify the supplied post-rejection counts, required markers, sampling rate, and channel count. Return eligible, missing_markers (sorted), insufficient_present_markers (sorted), and recipe_version. This is the recipe preflight operation.
The required fields are eligible, missing_markers, insufficient_present_markers, recipe_version. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
