import json
req = json.load(open("/input/request.json"))
labels = req["input"]["labels"]
labeled = [x for x in labels if x in (0, 1, 2)]
n = len(labeled)
coverage = {}
for s in (0, 1, 2):
    c = sum(1 for x in labeled if x == s)
    coverage[str(s)] = round(100.0 * c / n, 4) if n else 0.0
result = {"coverage_pct": coverage, "n_labeled": n}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
