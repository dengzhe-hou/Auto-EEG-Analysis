
import json, math
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
x = np.asarray(inp["series"], dtype=float)
m = int(inp["m"])
r_in = float(inp["r"])

N = len(x)
sd = x.std(ddof=0)
r = r_in  # absolute threshold in series units

def count_matches(dim):
    starts = range(0, N - m)  # same starting positions for m and m+1
    T = [x[i:i+dim] for i in starts]
    c = 0
    n = len(T)
    for i in range(n):
        for j in range(i+1, n):
            if np.max(np.abs(T[i]-T[j])) < r:
                c += 1
    return c

counts_m = count_matches(m)
counts_m_plus_1 = count_matches(m+1)
sampen = -math.log(counts_m_plus_1/counts_m) if counts_m and counts_m_plus_1 else None
result = {"counts_m": counts_m, "counts_m_plus_1": counts_m_plus_1,
          "sample_entropy": sampen}
json.dump(result, open("/workspace/result.json","w"), indent=2)
print(json.dumps(result))
