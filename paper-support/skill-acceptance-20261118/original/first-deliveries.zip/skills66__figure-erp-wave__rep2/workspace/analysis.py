
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

req = json.load(open("/input/request.json"))
inp = req["input"]
x = np.asarray(inp["x"], dtype=float)
y = np.asarray(inp["y"], dtype=float)
x_label = inp["x_label"]
y_label = inp["y_label"]

fig = plt.figure(figsize=(4, 3))
ax = fig.add_axes([.2, .2, .6, .6])
line, = ax.plot(x, y)
line.set_gid("aea-data")
ax.set_xlim(-1, 5)
ax.set_ylim(-3, 3)
ax.set_xlabel(x_label)
ax.set_ylabel(y_label)
fig.savefig("/workspace/fig.svg")
plt.close(fig)

result = {"n_points": int(len(x)), "x_label": x_label, "y_label": y_label}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
