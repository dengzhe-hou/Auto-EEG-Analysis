{"n_points": 5, "x_label": "Time (s)", "y_label": "Amplitude (uV)"}

Deliverables:
- /workspace/analysis.py (reusable program; executed successfully)
- /workspace/fig.svg (line with gid="aea-data", figsize=(4,3), axes at [.2,.2,.6,.6], xlim=(-1,5), ylim=(-3,3); verified present in the SVG)
- /workspace/result.json (n_points=5, x_label, y_label)
