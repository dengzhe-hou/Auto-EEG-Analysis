# Methods

EEG was acquired at a sampling rate of 250 Hz with an online reference of FCz. Epochs spanned -0.1 s to 0.6 s relative to event onset. Of 20 trials, 3 were excluded, leaving 17 retained trials. The executed random seed was 73 (planned seed 14). A bandpass of 0.2–35 Hz was applied.

## Machine-readable fields
sampling_hz = 250
reference = FCz
retained_trials = 17
seed = 73
epoch_start_s = -0.1
epoch_end_s = 0.6
