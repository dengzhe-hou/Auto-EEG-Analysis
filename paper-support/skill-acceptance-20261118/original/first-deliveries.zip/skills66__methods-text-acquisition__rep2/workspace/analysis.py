import json
req = json.load(open("/input/request.json"))["input"]
acq = req["acquisition"]; exe = req["execution"]
sampling_hz = acq["sampling_hz"]
reference = acq.get("reference", "not recorded")
retained_trials = exe["n_trials"] - exe["n_excluded"]
seed = exe["executed_seed"]
epoch_start_s = exe["epoch_start_sample"] / sampling_hz
epoch_end_s = exe["epoch_end_sample"] / sampling_hz
result = {"sampling_hz": sampling_hz, "reference": reference, "retained_trials": retained_trials,
          "seed": seed, "epoch_start_s": epoch_start_s, "epoch_end_s": epoch_end_s}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
