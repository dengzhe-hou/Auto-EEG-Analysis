Deliverables saved:
- /workspace/analysis.py (reusable program, executed successfully)
- /workspace/result.json
- /workspace/methods.md

Result values (from executed program):
{"sampling_hz": 250, "reference": "FCz", "retained_trials": 17, "seed": 73, "epoch_start_s": -0.1, "epoch_end_s": 0.6}

Methods paragraph (in methods.md):
EEG was acquired at a sampling rate of 250 Hz with an online reference of FCz. Epochs spanned -0.1 s to 0.6 s relative to event onset. Of 20 trials, 3 were excluded, leaving 17 retained trials. The executed random seed was 73 (planned seed 14). A bandpass of 0.2–35 Hz was applied.

Machine-readable lines in methods.md:
sampling_hz = 250
reference = FCz
retained_trials = 17
seed = 73
epoch_start_s = -0.1
epoch_end_s = 0.6

Notes: epoch times were converted from samples to seconds using 250 Hz. The paragraph is limited to the fields in the request; I did not add demographics, ICA, or statistics details because the input does not provide them. I did not read the full AEA procedure sections beyond the constants and phases, since the bounded task only needed the acquisition and execution fields.
