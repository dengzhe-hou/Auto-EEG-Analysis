
import json, os, sys, numpy as np, mne
sys.path.insert(0, "/workspace/aea/tools")
from qc_amplitude import amplitude_qc

req = json.load(open("/input/request.json"))
inp = req["input"]
data = np.array(inp["signal_uV"], dtype=float) * 1e-6
sfreq = float(inp["sfreq"])
info = mne.create_info(inp["channel_names"], sfreq, ch_types="eeg")
raw = mne.io.RawArray(data, info, verbose=False)
findings = amplitude_qc(raw)
result = {
    "constant_channels": sorted({s["channel"] for s in findings["constant_segments"]}),
    "rapid_change_channels": sorted({s["channel"] for s in findings["jump_segments"]}),
    "bad_channel_candidates": sorted(findings["bad_channel_candidates"]),
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
