The saved program /workspace/analysis.py was executed and wrote /workspace/result.json:

{
  "constant_channels": [],
  "rapid_change_channels": ["Fz"],
  "bad_channel_candidates": []
}

Details:
- Input: channels Fz and Cz, sfreq 1000 Hz, 1000 samples each; uV converted to V before the AEA amplitude helper, on original samples with no cleaning or annotation changes.
- Fz: no constant segments; rapid-change (jump) fraction 0.6%, below the 5% duration criterion, so it is reported as a rapid-change channel but not a bad-channel candidate.
- Cz: no constant or rapid-change segments.
- bad_channel_candidates is empty under the declared 5% criterion.
