The analysis program is saved at /workspace/analysis.py and was executed. Results are saved to /workspace/result.json.

{"accuracy": [0.6666666666666666, 0.6666666666666666], "mean_rt_ms": [345.0, 430.0], "retained_rt_trials": [2, 2]}

Accuracy is over all trials per condition (A, B). Mean RT is over correct trials only. Per condition, 2 correct trials were retained for RT. No trials were excluded by any RT filtering step, since none was specified in the approved settings.
