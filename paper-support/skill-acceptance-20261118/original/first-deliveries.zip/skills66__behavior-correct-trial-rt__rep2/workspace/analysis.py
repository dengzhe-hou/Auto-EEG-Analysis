import json

req = json.load(open("/input/request.json"))
inp = req["input"]
conds = inp["condition"]
corr = inp["correct"]
rts = inp["rt_ms"]
n = len(conds)

order = ["A", "B"]
accuracy = []
mean_rt_ms = []
retained_rt_trials = []
for c in order:
    idx = [i for i in range(n) if conds[i] == c]
    acc = sum(1 for i in idx if corr[i]) / len(idx) if idx else float("nan")
    accuracy.append(acc)
    kept = [i for i in idx if corr[i]]
    retained_rt_trials.append(len(kept))
    mean_rt_ms.append(sum(rts[i] for i in kept) / len(kept) if kept else float("nan"))

result = {
    "accuracy": accuracy,
    "mean_rt_ms": mean_rt_ms,
    "retained_rt_trials": retained_rt_trials,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
