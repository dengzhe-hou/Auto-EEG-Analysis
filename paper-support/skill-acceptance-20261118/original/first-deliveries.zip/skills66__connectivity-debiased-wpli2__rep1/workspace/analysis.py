
import json, os
import numpy as np

with open("/input/request.json") as f:
    req = json.load(f)
x = np.asarray(req["input"]["imaginary_cross_spectrum"], dtype=float)

denom = np.mean(np.abs(x))
if denom == 0:
    raise ValueError("wPLI undefined: zero denominator")
wpli = float(np.abs(np.mean(x)) / denom)

s1 = np.sum(x)
s2 = np.sum(x**2)
sa = np.sum(np.abs(x))
num = s1**2 - s2
den = sa**2 - s2
if den == 0:
    raise ValueError("debiased wPLI2 undefined: zero denominator")
wpli2 = float(num / den)

result = {"wpli": wpli, "wpli2": wpli2}
os.makedirs("/workspace", exist_ok=True)
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(result)
