{"cleaned_uV": "saved in /workspace/result.json (3 channels x 40 samples)", "applied_exclusions": [0]}
