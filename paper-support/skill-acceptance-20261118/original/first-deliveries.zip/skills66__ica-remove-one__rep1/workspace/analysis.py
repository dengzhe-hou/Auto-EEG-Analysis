
import json
import numpy as np

REQ = "/input/request.json"
OUT = "/workspace/result.json"

def main():
    req = json.load(open(REQ))
    inp = req["input"]
    X = np.asarray(inp["channel_data_uV"], dtype=float)   # channels x samples, centered
    W = np.asarray(inp["unmixing"], dtype=float)
    A = np.asarray(inp["mixing"], dtype=float)
    excl = [int(i) for i in inp["approved_exclusions"]]

    # Fixed decomposition: components S = W @ X; zero approved components; reconstruct.
    S = W @ X
    S_clean = S.copy()
    S_clean[excl, :] = 0.0
    cleaned = A @ S_clean

    result = {
        "cleaned_uV": cleaned.tolist(),
        "applied_exclusions": excl,
    }
    with open(OUT, "w") as f:
        json.dump(result, f)
    return result

if __name__ == "__main__":
    main()
