
import json
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
data = np.array(inp["raw_uV"], dtype=float)
names = inp["names"]
types = inp["types"]
sfreq = inp["sfreq"]

eeg_idx = [i for i, t in enumerate(types) if str(t).lower() == "eeg"]
out = data.copy()
if eeg_idx:
    mean_ref = data[eeg_idx].mean(axis=0)
    out[eeg_idx] = data[eeg_idx] - mean_ref

result = {
    "channel_names": names,
    "samples_uV": out.tolist(),
}
json.dump(result, open("/workspace/result.json", "w"))
print(json.dumps({"n_channels": len(names), "n_samples": out.shape[1], "eeg_idx": eeg_idx}))
