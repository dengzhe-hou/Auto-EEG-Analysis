
import json
import numpy as np

req = json.load(open("/input/request.json"))["input"]
data = np.array(req["raw_uV"], dtype=float)   # shape: channels x samples, in uV
names = req["names"]
types = req["types"]

eeg_idx = [i for i, t in enumerate(types) if t == "eeg"]
out = data.copy()

# Average reference over EEG channels only (no projection, no filtering)
avg = data[eeg_idx].mean(axis=0)
for i in eeg_idx:
    out[i] = data[i] - avg
# EOG channels left unchanged (out already holds original values)

result = {
    "samples_uV": out.tolist(),
    "channel_names": names,
}
json.dump(result, open("/workspace/result.json", "w"))
print("eeg_idx", eeg_idx, "shape", out.shape)
