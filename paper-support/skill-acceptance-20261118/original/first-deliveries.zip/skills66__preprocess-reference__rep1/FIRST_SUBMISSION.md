Result saved to /workspace/result.json (program: /workspace/analysis.py).

- Operation: average reference applied to EEG channels only (Fz, Cz, Pz); no projection, no filtering; VEOG kept unchanged.
- samples_uV: shape 4 × 400, full samples in original row order.
- channel_names: ["Fz", "Cz", "Pz", "VEOG"]
- Check: mean across EEG channels ≈ 6e-16 (≈0); VEOG identical to input.
