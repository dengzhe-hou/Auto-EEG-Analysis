
import json, sys
sys.path.insert(0, "/workspace/analysis")
import numpy as np, mne
from qc_amplitude import amplitude_qc

req = json.load(open("/input/request.json"))["input"]
sfreq = float(req["sfreq"])
names = list(req["channel_names"])
data = np.array(req["signal_uV"], dtype=float) * 1e-6  # uV -> V
info = mne.create_info(names, sfreq, ch_types="eeg")
raw = mne.io.RawArray(data, info, verbose=False)

amp = amplitude_qc(raw, constant_min_duration=0.020, low_amplitude_window=0.100,
                   low_amplitude_ptp=0.5e-6, jump_threshold=150e-6,
                   jump_min_duration=0.005, bad_percent=5.0)
with open("/workspace/analysis/amplitude_findings.json", "w") as f:
    json.dump(amp, f, indent=2)

const = sorted({s["channel"] for s in amp["constant_segments"]})
rapid = sorted({s["channel"] for s in amp["jump_segments"]})
bad = sorted(amp["bad_channel_candidates"])
result = {
    "constant_channels": const,
    "rapid_change_channels": rapid,
    "bad_channel_candidates": bad,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
