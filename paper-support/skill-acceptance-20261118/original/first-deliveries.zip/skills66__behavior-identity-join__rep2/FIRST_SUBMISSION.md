{
  "trial_ids": [11, 13, 16, 15],
  "missing_on_eeg": [14, 12],
  "slope_ms_per_uV": 40.0
}
