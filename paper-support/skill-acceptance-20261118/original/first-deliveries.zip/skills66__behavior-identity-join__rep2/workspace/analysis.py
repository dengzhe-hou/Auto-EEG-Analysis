import json, numpy as np
req = json.load(open("/input/request.json"))["input"]
eeg_ids = req["eeg_trial_ids"]; eeg_uV = req["eeg_uV"]
beh_ids = req["behavior_trial_ids"]; rt = req["rt_ms"]
beh_map = dict(zip(beh_ids, rt))
eeg_set = set(eeg_ids)
matched_ids = [t for t in eeg_ids if t in beh_map]
missing_on_eeg = [t for t in beh_ids if t not in eeg_set]
x = np.array([eeg_uV[eeg_ids.index(t)] for t in matched_ids], float)
y = np.array([beh_map[t] for t in matched_ids], float)
X = np.column_stack([np.ones_like(x), x])
beta = np.linalg.lstsq(X, y, rcond=None)[0]
result = {"trial_ids": matched_ids, "missing_on_eeg": missing_on_eeg,
          "slope_ms_per_uV": float(beta[1])}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(result)
