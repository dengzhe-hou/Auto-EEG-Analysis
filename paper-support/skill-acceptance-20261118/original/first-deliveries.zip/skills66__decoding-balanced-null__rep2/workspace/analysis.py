
import json
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import LeaveOneGroupOut

req = json.load(open("/input/request.json"))["input"]
X = np.array(req["features"], dtype=float)   # trials x time x features
y = np.array(req["labels"])
groups = np.array(req["groups"])

n_trials, n_times, _ = X.shape
preds = np.zeros((n_trials, n_times), dtype=int)
logo = LeaveOneGroupOut()
for t in range(n_times):
    Xt = X[:, t, :]
    for tr, te in logo.split(Xt, y, groups):
        clf = make_pipeline(StandardScaler(),
                            LogisticRegression(C=1, solver="liblinear",
                                               random_state=42, max_iter=1000))
        clf.fit(Xt[tr], y[tr])
        preds[te, t] = clf.predict(Xt[te])

accuracy = [float(np.mean(preds[:, t] == y)) for t in range(n_times)]
chance_accuracy = float(np.mean(np.unique(y, return_counts=True)[1]) / len(y))
chance_accuracy = 1.0 / len(np.unique(y))

result = {
    "predictions": preds.tolist(),
    "accuracy": accuracy,
    "chance_accuracy": chance_accuracy,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print("saved", n_trials, n_times)
