{
  "predictions": "stored in /workspace/result.json (24 trials x 3 time samples, original row order)",
  "accuracy": [0.875, 0.3333333333333333, 0.4166666666666667],
  "chance_accuracy": 0.5,
  "artifacts": {
    "program": "/workspace/analysis.py",
    "result": "/workspace/result.json"
  }
}
