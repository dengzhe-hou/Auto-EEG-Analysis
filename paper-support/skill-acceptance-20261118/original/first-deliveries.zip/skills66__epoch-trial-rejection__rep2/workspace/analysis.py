
import json, numpy as np, mne
mne.set_log_level("ERROR")
req = json.load(open("/input/request.json"))
inp = req["input"]
data_uV = np.array(inp["raw_uV"], dtype=float)
data_V = data_uV * 1e-6
ch_names = inp["channel_names"]
sfreq = float(inp["sfreq"])
info = mne.create_info(ch_names, sfreq, ch_types="eeg")
raw = mne.io.RawArray(data_V, info, verbose=False)
events = np.array(inp["events"], dtype=int)
event_id = inp["event_id"]
baseline = tuple(inp["baseline"]) if inp.get("baseline") is not None else None
reject = None
if inp.get("reject_peak_to_peak_uV") is not None:
    reject = dict(eeg=float(inp["reject_peak_to_peak_uV"]) * 1e-6)
epochs = mne.Epochs(raw, events, event_id=event_id, tmin=float(inp["tmin"]),
                    tmax=float(inp["tmax"]), baseline=baseline, reject=reject,
                    preload=True, verbose=False)
epochs.save("/workspace/check-epo.fif", overwrite=True, verbose=False)
retained = epochs.events[:, 0].astype(int).tolist()
times = [float(t) for t in epochs.times]
n_dropped = int(len(events) - len(epochs))
result = {"retained_event_samples": retained, "times_s": times, "n_dropped": n_dropped}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps({"retained_event_samples": retained, "n_dropped": n_dropped, "n_times": len(times)}))
