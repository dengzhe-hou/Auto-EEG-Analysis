
import json, numpy as np, mne

req = json.load(open("/input/request.json"))["input"]
data = np.array(req["epochs_uV"], dtype=float) * 1e-6  # uV -> V for MNE
labels = np.array(req["labels"])
ch_names = req["channel_names"]
sfreq = float(req["sfreq"])
tmin = float(req["tmin"])

info = mne.create_info(ch_names, sfreq, ch_types="eeg")
epochs = mne.EpochsArray(data, info, tmin=tmin, verbose=False)
epochs.events = np.column_stack([np.arange(len(labels)), np.zeros(len(labels), int), np.arange(len(labels)) + 1])
epochs.event_id = {"A": 1, "B": 2}
# keep labels as metadata-equivalent ordering
evA = epochs[labels == "A"].average()
evB = epochs[labels == "B"].average()
diff = mne.combine_evoked([evB, evA], weights=[1, -1])  # B - A
diff.comment = "B-A"
mne.write_evokeds("/workspace/check-ave.fif", diff)

times = diff.times
win = (times >= 0.1 - 1e-9) & (times <= 0.3 + 1e-9)
roi_idx = [ch_names.index("Cz"), ch_names.index("Pz")]
roi_wave = diff.data[roi_idx][:, win] * 1e6  # back to uV
roi_mean_uV = float(roi_wave.mean())  # equal weight over 2 channels and samples
n_window_samples = int(win.sum())
n_condition_trials = [int((labels == "A").sum()), int((labels == "B").sum())]

result = {
    "roi_mean_uV": roi_mean_uV,
    "n_window_samples": n_window_samples,
    "n_condition_trials": n_condition_trials,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
