import json, numpy as np
from scipy.signal import fftconvolve

req = json.load(open("/input/request.json"))["input"]
sfreq = float(req["sfreq"]); tmin = float(req["tmin"])
ep = np.asarray(req["epochs_uV"], dtype=float)
idx = np.asarray(req["sample_indices"], dtype=int)
freq = 10.0; n_cycles = 5.0
sigma_t = n_cycles/(2*np.pi*freq)
half = 5*sigma_t
tw = np.arange(-half, half + 1/sfreq, 1/sfreq)
wav = np.exp(2j*np.pi*freq*tw) * np.exp(-tw**2/(2*sigma_t**2))
wav = wav - wav.mean()
wav /= np.sum(np.abs(wav))

def tfr_complex(x):
    out = np.empty(x.shape, dtype=complex)
    for i in range(x.shape[0]):
        out[i] = fftconvolve(x[i]-x[i].mean(), wav, mode="same")
    return out

n_trials, n_ch, n_t = ep.shape
itc = np.zeros((n_ch, n_t))
for c in range(n_ch):
    coef = tfr_complex(ep[:, c, :])
    itc[c] = np.abs((coef/np.abs(coef)).mean(axis=0))
times = tmin + idx / sfreq
values = [[float(itc[c, s]) for s in idx] for c in range(n_ch)]
result = {"values": values, "times_s": [float(x) for x in times]}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
