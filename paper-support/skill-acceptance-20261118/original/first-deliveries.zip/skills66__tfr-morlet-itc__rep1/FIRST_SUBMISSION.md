Saved /workspace/analysis.py and /workspace/result.json.

Method: zero-mean complex Morlet, 10 Hz, 5 cycles, decim=1, applied to the supplied epoched signals (tmin=-1 s, sfreq=128 Hz, 4 trials, channels Fz and Cz). ITC is computed from the single-trial complex coefficients as the magnitude of the mean unit phasor across trials, per channel, at the requested zero-based sample_indices.

Result fields:
- values: ITC for Fz and Cz at samples [144, 156, 180, 220, 270]
- times_s: [0.125, 0.21875, 0.40625, 0.71875, 1.109375]

Caveat: the trial count is 4, so ITC is biased upward and should be interpreted with that in mind.
