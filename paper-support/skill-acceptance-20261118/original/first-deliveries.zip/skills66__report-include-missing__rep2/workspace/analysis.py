
import json, html

with open("/input/request.json") as f:
    req = json.load(f)

inp = req["input"]
stage = inp["executed_stage"]
source_file = inp["source_file"]
planned_seed = inp.get("planned_seed")

required = ["roi_mean_uV", "n_trials", "status", "seed"]
facts = {
    "roi_mean_uV": stage.get("roi_mean_uV"),
    "n_trials": stage.get("n_trials"),
    "status": stage.get("status"),
    "seed": stage.get("seed"),
}

def fmt_html(v):
    if v is None:
        return "null"
    if isinstance(v, float):
        return f"{v:.3f}"
    return str(v)

rows = "\n".join(
    f'<tr><th>{k}</th><td id="{k}">{html.escape(fmt_html(facts[k]))}</td></tr>'
    for k in required
)
report = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>EEG report</title></head>
<body>
<h1>EEG executed-stage report</h1>
<p>Source artifact: {html.escape(source_file)}</p>
<table>
{rows}
</table>
</body></html>
"""
with open("/workspace/report.html", "w") as f:
    f.write(report)

receipt = f"""# REPRO_RECEIPT

- Source artifact: {source_file}
- Input file: /input/request.json (field: input)
- Executed seed: {facts['seed']}
- Planned seed (not used as executed seed): {planned_seed}
- Program: /workspace/analysis.py
- Status: {facts['status']}
"""
with open("/workspace/REPRO_RECEIPT.md", "w") as f:
    f.write(receipt)

result = {k: facts[k] for k in required}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
