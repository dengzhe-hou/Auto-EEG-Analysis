
import json, numpy as np
from scipy import stats

with open("/input/request.json") as f:
    req = json.load(f)
x = np.asarray(req["input"]["contrasts"], dtype=float)
n = x.size
mean = x.mean()
sd = x.std(ddof=1)
dz = mean / sd
se = sd / np.sqrt(n)
tcrit = stats.t.ppf(0.975, df=n - 1)
ci = [float(mean - tcrit * se), float(mean + tcrit * se)]
result = {"dz": float(dz), "mean_difference": float(mean), "ci95": ci}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
