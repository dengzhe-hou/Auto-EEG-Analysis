Analysis complete. The reusable program is saved at /workspace/analysis.py and was executed; results are saved at /workspace/result.json.

{"dz": 1.3917848787223193, "mean_difference": 1.1666666666666665, "ci95": [0.2869749854331318, 2.046358347900201]}

Notes: the input contrasts are six paired-difference values [0.7, 1.2, -0.1, 1.1, 2.3, 1.8]. dz uses ddof=1 standard deviation, and ci95 is the two-sided 95% t interval on the mean with df=5. The skill's broader procedures (ANALYSIS_PLAN, permutation tests, cluster stats) were not applicable to this bounded calculation and were not run.
