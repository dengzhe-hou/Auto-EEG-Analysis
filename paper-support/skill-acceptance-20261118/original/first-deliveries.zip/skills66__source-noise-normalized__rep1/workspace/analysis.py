
import json
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
G = np.array(inp["gain"], dtype=float)          # (n_sensors, n_sources)
C = np.array(inp["noise_cov"], dtype=float)     # (n_sensors, n_sensors)
Y = np.array(inp["sensor_data"], dtype=float)   # (n_sensors, n_times)
lam2 = float(inp["lambda2"])
normalize = bool(inp["normalize_noise"])

# K = G.T @ inv(G G.T + lambda2 * C)
K = G.T @ np.linalg.inv(G @ G.T + lam2 * C)
X = K @ Y   # source_estimates (n_sources, n_times)

if normalize:
    d = np.diag(K @ C @ K.T)
    X = X / np.sqrt(d)[:, None]

result = {
    "source_estimates": X.tolist(),
    "normalized": normalize,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
