Wrote /workspace/result.json with the required fields:
- source_estimates: 2 sources × 4 time points, computed as K @ sensor_data with K = G.T @ inv(G @ G.T + 0.2·C), then each source row divided by sqrt(diag(K @ C @ K.T)).
- normalized: true

The reusable program is saved at /workspace/analysis.py and was executed to produce the result.
