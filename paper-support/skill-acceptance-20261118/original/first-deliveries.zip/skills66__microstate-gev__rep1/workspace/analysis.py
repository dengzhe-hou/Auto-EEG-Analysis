
import json

req = json.load(open("/input/request.json"))
inp = req["input"]
labels = inp["label"]
gfp = inp["gfp"]
corr = inp["corr"]

def gev_fraction(state_labels, gfp, corr, state=None):
    total = sum((g ** 2) * (c ** 2) for g, c in zip(gfp, corr))
    if state is None:
        num = sum((g ** 2) * (c ** 2) for l, g, c in zip(state_labels, gfp, corr) if l >= 0)
    else:
        num = sum((g ** 2) * (c ** 2) for l, g, c in zip(state_labels, gfp, corr) if l == state)
    return num / total if total > 0 else 0.0

gev_by_state = [gev_fraction(labels, gfp, corr, s) for s in (0, 1, 2)]
gev_total = gev_fraction(labels, gfp, corr, None)

result = {"gev_by_state": gev_by_state, "gev_total": gev_total}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
