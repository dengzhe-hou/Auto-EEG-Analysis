Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-microstate. Input: /input/request.json. Use its input field.
Calculate the per-state GEV and total GEV from the supplied spatial correlation to each sample assigned state and GFP, using GFP-squared weighting. Denominator includes all sample powers, with no numerator contribution from unlabeled samples. Return gev_by_state in order 0,1,2 and gev_total as fractions.
The required fields are gev_by_state, gev_total. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
