
import json
import numpy as np
import mne

req = json.load(open("/input/request.json"))
inp = req["input"]
sfreq = float(inp["sfreq"])
tmin = float(inp["tmin"])
ch_names = list(inp["channel_names"])
labels = list(inp["labels"])
data = np.array(inp["epochs_uV"], dtype=float)  # (n_epochs, n_ch, n_times)

# Build MNE epochs (volts, MNE convention) from supplied clean arrays, no further processing
info = mne.create_info(ch_names, sfreq, ch_types="eeg")
events = np.column_stack([np.arange(data.shape[0]) * 1000,
                          np.zeros(data.shape[0], dtype=int),
                          np.arange(data.shape[0]) + 1])
epochs = mne.EpochsArray(data * 1e-6, info, events=events, tmin=tmin, verbose=False)
event_id = {"A": 1, "B": 2}
ids = {}
for lbl in set(labels):
    ids[lbl] = [i + 1 for i, l in enumerate(labels) if l == lbl]

evk_A = epochs[[i for i, l in enumerate(labels) if l == "A"]].average()
evk_B = epochs[[i for i, l in enumerate(labels) if l == "B"]].average()
n_A = sum(1 for l in labels if l == "A")
n_B = sum(1 for l in labels if l == "B")

# Difference wave: condition B minus condition A
diff = mne.combine_evoked([evk_B, evk_A], weights=[1, -1])
diff.comment = "B-A"
mne.write_evokeds("/workspace/check-ave.fif", [diff], verbose=False)

# ROI: Cz/Pz, equal weight, inclusive 0.1-0.3 s
roi_chs = ["Cz", "Pz"]
picks = [ch_names.index(c) for c in roi_chs]
times = diff.times
mask = (times >= 0.1 - 1e-9) & (times <= 0.3 + 1e-9)
n_window = int(mask.sum())
roi_mean_V = diff.data[picks][:, mask].mean()  # equal weight over channels and samples
roi_mean_uV = float(roi_mean_V * 1e6)

result = {
    "roi_mean_uV": roi_mean_uV,
    "n_window_samples": n_window,
    "n_condition_trials": [n_A, n_B],
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
