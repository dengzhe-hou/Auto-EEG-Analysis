
import json

def assign(inp):
    stim = inp["stimulus_ms"]; sb = inp["stimulus_blocks"]
    resp = inp["response_ms"]; rb = inp["response_blocks"]; rid = inp["response_ids"]
    used = set()
    rt_ms, unused_pool = [], set(rid)
    for s, b in zip(stim, sb):
        chosen = None
        for t, rblk, i in zip(resp, rb, rid):
            if rblk != b or i in used:
                continue
            d = t - s
            if 100 <= d < 350:
                chosen = (i, d)
                break
        if chosen is None:
            rt_ms.append(None)
        else:
            used.add(chosen[0]); rt_ms.append(float(chosen[1]))
    unused = sorted(i for i in rid if i not in used)
    return {"rt_ms": rt_ms, "unused_response_ids": unused}

if __name__ == "__main__":
    with open("/input/request.json") as f:
        req = json.load(f)
    result = assign(req["input"])
    with open("/workspace/result.json", "w") as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result))
