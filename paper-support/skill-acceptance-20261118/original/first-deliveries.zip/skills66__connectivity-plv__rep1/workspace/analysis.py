
import json
import numpy as np

req = json.load(open("/input/request.json"))
a = np.asarray(req["input"]["phase_a"], dtype=float)
b = np.asarray(req["input"]["phase_b"], dtype=float)

# Temporal phase locking value: |mean(exp(i*(phi_a - phi_b)))|
dphi = a - b
plv = float(np.abs(np.mean(np.exp(1j * dphi))))
n_samples = int(a.shape[0])

result = {"plv": plv, "n_samples": n_samples}
import os
os.makedirs("/workspace", exist_ok=True)
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
