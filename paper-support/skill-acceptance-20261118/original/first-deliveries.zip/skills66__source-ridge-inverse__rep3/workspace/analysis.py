
import json
import numpy as np

with open("/input/request.json") as f:
    req = json.load(f)

inp = req["input"]
G = np.asarray(inp["gain"], dtype=float)
C = np.asarray(inp["noise_cov"], dtype=float)
Y = np.asarray(inp["sensor_data"], dtype=float)
lambda2 = float(inp["lambda2"])
normalize_noise = bool(inp["normalize_noise"])

# Identity-source-prior minimum-norm inverse
K = G.T @ np.linalg.inv(G @ G.T + lambda2 * C)

source_estimates = K @ Y

if normalize_noise:
    denom = np.sqrt(np.diag(K @ C @ K.T))
    source_estimates = source_estimates / denom[:, None]

result = {
    "source_estimates": source_estimates.tolist(),
    "normalized": normalize_noise,
}

with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)

print(json.dumps(result, indent=2))
