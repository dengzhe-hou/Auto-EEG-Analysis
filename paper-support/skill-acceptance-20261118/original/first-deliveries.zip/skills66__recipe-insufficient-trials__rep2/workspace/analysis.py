
import json, re

REQ = {"min_channels": 16, "min_sfreq": 200, "min_trials_per_condition": 30}
REQUIRED_MARKERS = ["stimulus/related", "stimulus/unrelated"]

text = open("/workspace/aea/recipes/n400-semantic/RECIPE.md").read()
header = text.split("---")[1]
version = re.search(r'version:\s*"([^"]+)"', header).group(1)
min_channels = int(re.search(r"min_channels:\s*(\d+)", header).group(1))
min_sfreq = int(re.search(r"min_sfreq:\s*(\d+)", header).group(1))
min_trials = int(re.search(r"min_trials_per_condition:\s*(\d+)", header).group(1))
req_markers = re.search(r"required_markers:\s*\[([^\]]*)\]", header).group(1)
req_markers = [m.strip() for m in req_markers.split(",")]

req = json.load(open("/input/request.json"))["input"]
counts = req["marker_counts"]

missing = sorted([m for m in req_markers if m not in counts])
insufficient = sorted([m for m in req_markers if m in counts and counts[m] < min_trials])
eligible = (not missing and not insufficient
            and req["channel_count"] >= min_channels
            and req["sfreq"] >= min_sfreq)

result = {
    "eligible": bool(eligible),
    "missing_markers": missing,
    "insufficient_present_markers": insufficient,
    "recipe_version": version,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
