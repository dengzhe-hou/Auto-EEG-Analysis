
import json, numpy as np, mne

req = json.load(open("/input/request.json"))["input"]
data = np.array(req["epochs_uV"], dtype=float)          # (n_epochs, n_ch, n_times), uV
labels = np.array(req["labels"])
ch_names = req["channel_names"]
sfreq = float(req["sfreq"])
tmin = float(req["tmin"])

# uV -> V for MNE
data_V = data * 1e-6
info = mne.create_info(ch_names, sfreq, ch_types="eeg")
epochs = mne.EpochsArray(data_V, info, tmin=tmin, events=None, verbose=False)
epochs.event_id = {"A": 1, "B": 2}
events = np.column_stack([np.arange(len(labels)), np.zeros(len(labels), int),
                          np.where(labels == "A", 1, 2)])
epochs = mne.EpochsArray(data_V, info, tmin=tmin, events=events,
                         event_id={"A": 1, "B": 2}, verbose=False)

evk_A = epochs["A"].average()
evk_B = epochs["B"].average()
diff = mne.combine_evoked([evk_B, evk_A], weights=[1, -1])   # B - A
mne.write_evokeds("/workspace/check-ave.fif", diff)

# ROI: Cz/Pz, inclusive 0.1-0.3 s, equal weight over channels
roi_chs = ["Cz", "Pz"]
idx = [ch_names.index(c) for c in roi_chs]
times = diff.times
tmask = (times >= 0.1 - 1e-9) & (times <= 0.3 + 1e-9)
vals = diff.data[idx][:, tmask] * 1e6   # back to uV
roi_mean_uV = float(np.mean(vals))      # equal weight per channel & sample
n_window_samples = int(tmask.sum())
n_condition_trials = [int(np.sum(labels == "A")), int(np.sum(labels == "B"))]

result = {
    "roi_mean_uV": roi_mean_uV,
    "n_window_samples": n_window_samples,
    "n_condition_trials": n_condition_trials,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
