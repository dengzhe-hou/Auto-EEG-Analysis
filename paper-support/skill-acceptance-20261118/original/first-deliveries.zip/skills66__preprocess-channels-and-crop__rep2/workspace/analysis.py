
import json, os
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
names = inp["names"]
data = np.asarray(inp["raw_uV"], dtype=float)
start, stop = inp["samples"]
picks = [names.index(p) for p in inp["pick"]]
cropped = data[picks, start:stop]
result = {
    "samples_uV": cropped.tolist(),
    "channel_names": [names[i] for i in picks],
}
os.makedirs("/workspace", exist_ok=True)
with open("/workspace/result.json", "w") as f:
    json.dump(result, f)
