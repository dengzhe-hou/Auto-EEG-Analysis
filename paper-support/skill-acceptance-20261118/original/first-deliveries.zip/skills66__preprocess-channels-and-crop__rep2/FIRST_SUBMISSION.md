{"samples_uV": "saved in /workspace/result.json", "channel_names": ["Pz", "Fz"]}
