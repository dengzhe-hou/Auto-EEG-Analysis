import json
req = json.load(open("/input/request.json"))["input"]
acq = req["acquisition"]; exe = req["execution"]
sampling_hz = acq["sampling_hz"]
reference = acq.get("reference", "not recorded") or "not recorded"
retained_trials = exe["n_trials"] - exe["n_excluded"]
seed = exe["executed_seed"]
epoch_start_s = exe["epoch_start_sample"] / sampling_hz
epoch_end_s = exe["epoch_end_sample"] / sampling_hz
fields = {"sampling_hz": sampling_hz, "reference": reference, "retained_trials": retained_trials,
          "seed": seed, "epoch_start_s": epoch_start_s, "epoch_end_s": epoch_end_s}
paragraph = (f"EEG was acquired at a sampling rate of {sampling_hz} Hz with an online reference of {reference}. "
             f"Of {exe['n_trials']} trials, {exe['n_excluded']} were excluded, leaving {retained_trials} retained trials. "
             f"Epochs spanned {epoch_start_s} s to {epoch_end_s} s relative to event onset. "
             f"The executed random seed was {seed} (planned seed {exe['planned_seed']}). "
             f"Band-pass limits were {exe['band_hz'][0]} to {exe['band_hz'][1]} Hz.")
md = "# Methods\n\n" + paragraph + "\n\n"
for k, v in fields.items():
    md += f"{k} = {v}\n"
open("/workspace/methods.md", "w").write(md)
json.dump(fields, open("/workspace/result.json", "w"), indent=2)
