# Methods

EEG was acquired at a sampling rate of 250 Hz with an online reference of FCz. Of 20 trials, 3 were excluded, leaving 17 retained trials. Epochs spanned -0.1 s to 0.6 s relative to event onset. The executed random seed was 73 (planned seed 14). Band-pass limits were 0.2 to 35 Hz.

sampling_hz = 250
reference = FCz
retained_trials = 17
seed = 73
epoch_start_s = -0.1
epoch_end_s = 0.6
