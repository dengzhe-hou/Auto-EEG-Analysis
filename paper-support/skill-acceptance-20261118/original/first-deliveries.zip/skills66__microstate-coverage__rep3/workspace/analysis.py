import json
with open("/input/request.json") as f:
    labels = json.load(f)["input"]["labels"]
labeled = [x for x in labels if x >= 0]
n = len(labeled)
coverage = [round(100.0 * sum(1 for x in labeled if x == s) / n, 4) for s in (0, 1, 2)]
result = {"coverage_pct": coverage, "n_labeled": n}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
