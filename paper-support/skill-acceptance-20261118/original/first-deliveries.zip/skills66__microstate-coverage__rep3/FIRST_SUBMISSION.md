{"coverage_pct": [40.0, 26.6667, 33.3333], "n_labeled": 15}
