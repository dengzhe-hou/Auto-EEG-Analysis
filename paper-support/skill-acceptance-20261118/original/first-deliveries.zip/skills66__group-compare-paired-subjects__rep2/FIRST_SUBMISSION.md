{"statistic": 2.353835283221946, "p_value": 0.06524854507932806, "n_per_group": 6}
