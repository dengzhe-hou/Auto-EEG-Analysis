import json
import numpy as np
from scipy import stats

req = json.load(open("/input/request.json"))
inp = req["input"]
a = np.asarray(inp["A"], dtype=float)
b = np.asarray(inp["B"], dtype=float)
assert a.shape == b.shape, "paired test requires equal lengths"

res = stats.ttest_rel(a, b, alternative="two-sided")
out = {
    "statistic": float(res.statistic),
    "p_value": float(res.pvalue),
    "n_per_group": int(len(a)),
}
json.dump(out, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(out))
