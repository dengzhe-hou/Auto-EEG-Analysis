
import json

def transition_stats(labels, states=(0, 1, 2)):
    counts = {s: {d: 0 for d in states} for s in states}
    for a, b in zip(labels[:-1], labels[1:]):
        if a == b:
            continue
        if a == -1 or b == -1:
            continue
        if a in states and b in states:
            counts[a][b] += 1
    probs = {}
    for s in states:
        total = sum(counts[s].values())
        probs[s] = {d: (counts[s][d] / total if total > 0 else 0.0) for d in states}
    return counts, probs

if __name__ == "__main__":
    with open("/input/request.json") as f:
        req = json.load(f)
    labels = req["input"]["labels"]
    counts, probs = transition_stats(labels)
    result = {
        "counts": {str(s): {str(d): counts[s][d] for d in counts[s]} for s in counts},
        "probabilities": {str(s): {str(d): probs[s][d] for d in probs[s]} for s in probs},
    }
    with open("/workspace/result.json", "w") as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result, indent=2))
