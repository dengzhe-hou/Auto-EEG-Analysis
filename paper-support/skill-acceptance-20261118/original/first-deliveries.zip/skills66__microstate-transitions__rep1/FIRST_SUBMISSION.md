Analysis complete. Transitions were counted between labels 0–2 for consecutive samples, skipping adjacent repeats and any pair touching -1, with no bridging across gaps.

Observed transition counts (source row, destination column):
- 0 → 0: 0, 0 → 1: 2, 0 → 2: 1
- 1 → 0: 1, 1 → 1: 0, 1 → 2: 2
- 2 → 0: 1, 2 → 1: 0, 2 → 2: 0

Row-normalized probabilities (source row, destination column):
- 0 → 0: 0.0, 0 → 1: 0.6667, 0 → 2: 0.3333
- 1 → 0: 0.3333, 1 → 1: 0.0, 1 → 2: 0.6667
- 2 → 0: 1.0, 2 → 1: 0.0, 2 → 2: 0.0

Saved artifacts:
- /workspace/analysis.py (reusable program, executed)
- /workspace/result.json (fields: counts, probabilities)
