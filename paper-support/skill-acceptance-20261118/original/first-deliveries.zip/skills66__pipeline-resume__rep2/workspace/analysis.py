
import json, os
req = json.load(open("/input/request.json"))["input"]
deps = req["dependencies"]
status = req.get("status", {})
reused, runnable, blocked = [], [], []
memo = {}
def passed(s):
    return status.get(s) == "passed"
for stage in sorted(deps):
    st = status.get(stage, "pending")
    if st == "passed":
        reused.append(stage)
    elif st == "failed":
        blocked.append(stage)
    else:
        if all(passed(d) for d in deps[stage]):
            runnable.append(stage)
        else:
            blocked.append(stage)
result = {"reused": sorted(reused), "runnable": sorted(runnable), "blocked": sorted(blocked)}
os.makedirs("/workspace", exist_ok=True)
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
