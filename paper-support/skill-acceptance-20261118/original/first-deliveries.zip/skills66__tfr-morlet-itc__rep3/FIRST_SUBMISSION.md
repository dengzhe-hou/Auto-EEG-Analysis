Completed the bounded eeg-tfr engineering test.

Method: zero-mean Morlet wavelet at 10 Hz, 5 cycles, decim=1, applied to the supplied epoched signals (tmin=-1 s, sfreq=128 Hz). Inter-trial coherence was computed from single-trial complex coefficients as |mean of unit phasors| across trials, per channel, at the requested zero-based sample indices. No other preprocessing was applied.

Saved artifacts:
- /workspace/analysis.py (reusable program, executed)
- /workspace/result.json

Result (channels Fz, Cz; sample indices [144, 156, 180, 220, 270]):
{
  "values": [
    [0.99289, 0.99578, 0.99885, 0.98924, 0.99236],
    [0.99959, 0.99908, 0.99922, 0.99807, 0.99588]
  ],
  "times_s": [0.125, 0.21875, 0.40625, 0.71875, 1.109375]
}

Note: the inputs are synthetic and the request was a bounded engineering test, so ITC values near 1 reflect the synthetic data's strong phase consistency across trials; no scientific interpretation or inferential testing was performed.
