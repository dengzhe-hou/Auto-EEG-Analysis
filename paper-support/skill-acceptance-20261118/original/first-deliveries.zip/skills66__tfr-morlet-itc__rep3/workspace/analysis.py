
import json
import numpy as np
from mne.time_frequency import morlet

inp = json.load(open('/input/request.json'))['input']
epochs = np.asarray(inp['epochs_uV'], dtype=float)  # (trials, channels, samples)
sfreq = float(inp['sfreq'])
tmin = float(inp['tmin'])
idx = [int(i) for i in inp['sample_indices']]

freq = 10.0
n_cycles = 5.0
W = morlet(sfreq, [freq], n_cycles=n_cycles, zero_mean=True)

n_trials, n_ch, n_t = epochs.shape
coef = np.zeros((n_trials, n_ch, n_t), dtype=complex)
for tr in range(n_trials):
    for ch in range(n_ch):
        x = epochs[tr, ch]
        coef[tr, ch] = np.convolve(x, W[0], mode='same')

phasors = coef / np.abs(coef)
itc = np.abs(phasors.mean(axis=0))  # (channels, samples)

values = [[float(itc[c, i]) for i in idx] for c in range(n_ch)]
times_s = [float(tmin + i / sfreq) for i in idx]
result = {"values": values, "times_s": times_s}
json.dump(result, open('/workspace/result.json', 'w'), indent=2)
print(json.dumps(result))
