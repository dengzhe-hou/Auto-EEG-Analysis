
import json, sys
sys.path.insert(0, "/workspace")
import numpy as np, mne
from qc_amplitude import amplitude_qc

req = json.load(open("/input/request.json"))["input"]
names = req["channel_names"]
sfreq = float(req["sfreq"])
data_v = np.asarray(req["signal_uV"], dtype=float) * 1e-6  # uV -> V

info = mne.create_info(names, sfreq, ch_types="eeg")
raw = mne.io.RawArray(data_v, info, verbose=False)

findings = amplitude_qc(raw)

constant_channels = sorted({s["channel"] for s in findings["constant_segments"]})
rapid_change_channels = sorted({s["channel"] for s in findings["jump_segments"]})
bad_channel_candidates = sorted(findings["bad_channel_candidates"])

result = {
    "constant_channels": constant_channels,
    "rapid_change_channels": rapid_change_channels,
    "bad_channel_candidates": bad_channel_candidates,
    "details": findings,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps({k: result[k] for k in ["constant_channels","rapid_change_channels","bad_channel_candidates"]}))
