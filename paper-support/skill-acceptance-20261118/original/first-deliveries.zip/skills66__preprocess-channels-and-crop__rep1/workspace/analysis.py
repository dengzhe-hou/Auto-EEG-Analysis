import os
import json
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
names = inp["names"]
raw = np.asarray(inp["raw_uV"], dtype=float)
pick = inp["pick"]
start, stop = inp["samples"]

idx = [names.index(p) for p in pick]
cropped = raw[idx, start:stop]

result = {
    "samples_uV": cropped.tolist(),
    "channel_names": list(pick),
}
os.makedirs("/workspace", exist_ok=True) if False else None
with open("/workspace/result.json", "w") as f:
    json.dump(result, f)
print(np.asarray(result["samples_uV"]).shape, result["channel_names"])
