{"samples_uV": "saved in /workspace/result.json (2 channels x 78 samples, cropped [45,123), channels Pz then Fz)", "channel_names": ["Pz", "Fz"]}
