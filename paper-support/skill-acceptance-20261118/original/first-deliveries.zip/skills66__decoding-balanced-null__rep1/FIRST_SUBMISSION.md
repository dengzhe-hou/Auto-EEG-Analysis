Result saved to /workspace/result.json (program: /workspace/analysis.py, executed).

- predictions: 24 trials × 3 time samples, in original row order (leave-one-group-out, 4 groups of 6 trials; StandardScaler + LogisticRegression(C=1, solver="liblinear", random_state=42, max_iter=1000) fit within each fold, separately per time sample).
- accuracy per time sample: [0.875, 0.3333, 0.4167]
- chance_accuracy: 0.5

Caveats: these are engineering fixtures with only 24 trials, so the per-time accuracies are not statistically reliable, and no significance testing was performed (out of scope). Chance is the majority-class proportion for balanced labels (12/12).
