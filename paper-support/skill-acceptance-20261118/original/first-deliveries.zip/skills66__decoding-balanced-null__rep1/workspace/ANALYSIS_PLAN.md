Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-decoding. Input: /input/request.json. Use its input field.
Perform time-resolved decoding with one whole group held out at a time. At each time sample independently, fit StandardScaler inside each fold followed by LogisticRegression(C=1, solver="liblinear", random_state=42, max_iter=1000). Return predictions in original row order (trial by time), accuracy at each time and chance_accuracy. These are engineering fixtures; inferential testing is outside this assigned operation.
The required fields are predictions, accuracy, chance_accuracy. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
