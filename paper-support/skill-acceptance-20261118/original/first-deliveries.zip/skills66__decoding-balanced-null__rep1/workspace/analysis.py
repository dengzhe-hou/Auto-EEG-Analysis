
import json, numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

req = json.load(open("/input/request.json"))["input"]
X = np.array(req["features"], dtype=float)   # trials x time x features
y = np.array(req["labels"])
g = np.array(req["groups"])
n_trials, n_times, _ = X.shape

predictions = np.zeros((n_trials, n_times), dtype=int)
accuracy = np.zeros(n_times)
for t in range(n_times):
    for grp in np.unique(g):
        test = g == grp
        train = ~test
        clf = make_pipeline(StandardScaler(),
                            LogisticRegression(C=1, solver="liblinear",
                                               random_state=42, max_iter=1000))
        clf.fit(X[train, t, :], y[train])
        predictions[test, t] = clf.predict(X[test, t, :])
    accuracy[t] = np.mean(predictions[:, t] == y)

# chance: majority-class proportion for balanced binary labels
chance_accuracy = float(np.max(np.bincount(y)) / len(y))

result = {
    "predictions": predictions.tolist(),
    "accuracy": accuracy.tolist(),
    "chance_accuracy": chance_accuracy,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print("accuracy", accuracy.tolist())
print("chance", chance_accuracy)
