Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-complexity. Input: /input/request.json. Use its input field.
For order 3, delay 1, calculate the normalized permutation entropy of this single channel. Report pattern_counts as counts in lexicographic order of the six permutations of [0,1,2], and normalized_perm_entropy with normalization log(3!).
The required fields are pattern_counts, normalized_perm_entropy. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
