
import json, math, os
import numpy as np

with open('/input/request.json') as f:
    req = json.load(f)
x = np.asarray(req['input']['series'], dtype=float)
order, delay = 3, 1
n = len(x) - (order - 1) * delay
perms = [tuple(p) for p in __import__('itertools').permutations(range(order))]
counts = {p: 0 for p in perms}
for i in range(n):
    window = x[i:i + order * delay:delay]
    pattern = tuple(int(k) for k in np.argsort(window, kind='mergesort'))
    counts[pattern] += 1
pattern_counts = [counts[p] for p in perms]
total = sum(pattern_counts)
probs = [c / total for c in pattern_counts if c > 0]
H = -sum(p * math.log(p) for p in probs)
normalized = H / math.log(math.factorial(order))
result = {
    'pattern_counts': pattern_counts,
    'normalized_perm_entropy': normalized,
}
os.makedirs('/workspace', exist_ok=True)
with open('/workspace/result.json', 'w') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
