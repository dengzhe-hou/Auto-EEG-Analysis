
import json
import numpy as np
from scipy import stats

req = json.load(open("/input/request.json"))
groups = [np.asarray(g, dtype=float) for g in req["input"]["groups"]]
f_stat, p_val = stats.f_oneway(*groups)
result = {
    "statistic": float(f_stat),
    "p_value": float(p_val),
    "n_per_group": [int(len(g)) for g in groups],
}
import os
os.makedirs("/workspace", exist_ok=True)
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
