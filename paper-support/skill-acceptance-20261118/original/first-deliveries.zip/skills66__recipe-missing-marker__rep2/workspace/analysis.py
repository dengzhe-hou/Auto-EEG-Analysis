
import json

req = json.load(open("/input/request.json"))["input"]
recipe = {
    "version": "v0.1.0",
    "min_channels": 16,
    "min_sfreq": 200,
    "min_trials_per_condition": 30,
    "required_markers": ["stimulus/related", "stimulus/unrelated"],
}

counts = req.get("marker_counts", {})
missing = sorted(m for m in recipe["required_markers"] if m not in counts)
insufficient = sorted(
    m for m in recipe["required_markers"]
    if m in counts and counts[m] < recipe["min_trials_per_condition"]
)
channels_ok = req["channel_count"] >= recipe["min_channels"]
sfreq_ok = req["sfreq"] >= recipe["min_sfreq"]
eligible = channels_ok and sfreq_ok and not missing and not insufficient

result = {
    "eligible": eligible,
    "missing_markers": missing,
    "insufficient_present_markers": insufficient,
    "recipe_version": recipe["version"],
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result, indent=2))
