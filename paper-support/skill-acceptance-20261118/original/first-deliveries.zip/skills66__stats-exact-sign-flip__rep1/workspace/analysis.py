
import json, itertools

with open("/input/request.json") as f:
    req = json.load(f)
vals = [float(v) for v in req["input"]["contrasts"]]
n = len(vals)

def abs_mean(x):
    return abs(sum(x) / len(x))

observed = abs_mean(vals)
count_ext = 0
n_patterns = 0
for signs in itertools.product([1, -1], repeat=n):
    flipped = [s * v for s, v in zip(signs, vals)]
    stat = abs_mean(flipped)
    n_patterns += 1
    if stat >= observed - 1e-12:
        count_ext += 1
p_exact = count_ext / n_patterns

result = {
    "observed_abs_mean": observed,
    "n_patterns": n_patterns,
    "p_exact": p_exact,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
