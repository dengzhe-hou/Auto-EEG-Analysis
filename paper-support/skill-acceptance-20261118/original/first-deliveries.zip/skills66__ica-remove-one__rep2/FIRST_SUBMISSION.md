{"cleaned_uV": "saved in /workspace/result.json (3 x 40 array, channel by sample)", "applied_exclusions": [0]}
