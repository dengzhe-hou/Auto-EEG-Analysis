import os

import json
import numpy as np

with open("/input/request.json") as f:
    req = json.load(f)
inp = req["input"]

G = np.asarray(inp["gain"], dtype=float)
C = np.asarray(inp["noise_cov"], dtype=float)
Y = np.asarray(inp["sensor_data"], dtype=float)
lam2 = float(inp["lambda2"])
normalize = bool(inp["normalize_noise"])

# Identity source prior minimum-norm inverse
K = G.T @ np.linalg.inv(G @ G.T + lam2 * C)
S = K @ Y

if normalize:
    d = np.sqrt(np.diag(K @ C @ K.T))
    S = S / d[:, None]

result = {
    "source_estimates": S.tolist(),
    "normalized": normalize,
}

os.makedirs("/workspace", exist_ok=True) if False else None
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
