import json
req = json.load(open("/input/request.json"))["input"]
acq = req["acquisition"]; ex = req["execution"]
retained = ex["n_trials"] - ex["n_excluded"]
reference = acq["reference"] if acq["reference"] is not None else "not recorded"
epoch_start_s = ex["epoch_start_sample"] / acq["sampling_hz"]
epoch_end_s = ex["epoch_end_sample"] / acq["sampling_hz"]
seed = ex["executed_seed"]
result = {"sampling_hz": acq["sampling_hz"], "reference": reference,
          "retained_trials": retained, "seed": seed,
          "epoch_start_s": epoch_start_s, "epoch_end_s": epoch_end_s}
paragraph = (f"EEG was acquired at {acq['sampling_hz']} Hz with an online reference recorded as "
    f"{reference}. Epochs spanned {epoch_start_s} s to {epoch_end_s} s relative to event onset. "
    f"Of {ex['n_trials']} trials, {ex['n_excluded']} were excluded, leaving {retained} retained trials. "
    f"The executed random seed was {seed} (planned seed {ex['planned_seed']}). "
    f"Offline bandpass was {ex['band_hz'][0]}-{ex['band_hz'][1]} Hz.")
lines = [paragraph, ""]
for k in ["sampling_hz","reference","retained_trials","seed","epoch_start_s","epoch_end_s"]:
    lines.append(f"{k} = {result[k]}")
open("/workspace/methods.md","w").write("\n".join(lines)+"\n")
json.dump(result, open("/workspace/result.json","w"), indent=2)
