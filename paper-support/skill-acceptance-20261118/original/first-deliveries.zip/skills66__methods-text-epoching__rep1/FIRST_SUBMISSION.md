Deliverables saved:
- /workspace/methods.md: Methods paragraph plus the six field lines.
- /workspace/result.json: same field values.
- /workspace/analysis.py: reusable program, executed successfully.

Results:
- sampling_hz = 250
- reference = not recorded
- retained_trials = 16 (21 trials, 5 excluded)
- seed = 74 (executed; planned seed was 14)
- epoch_start_s = -0.12
- epoch_end_s = 0.64

Caveat: the Methods paragraph is a concise draft from the request record only. The full COBIDAS-MEEG checklist (demographics, preprocessing tool versions, ICA, statistics) was not populated because those source files are not in the workspace, and no such values were invented.
