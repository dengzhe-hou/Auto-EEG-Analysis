import json

req = json.load(open("/input/request.json"))["input"]

recipe_version = "v0.1.0"
min_channels = 16
min_sfreq = 200
min_trials = 30
required_markers = ["stimulus/related", "stimulus/unrelated"]

counts = req["marker_counts"]
present = set(counts.keys())
missing = sorted(m for m in required_markers if m not in present)
insufficient = sorted(m for m in required_markers if m in present and counts[m] < min_trials)

eligible = (
    not missing
    and not insufficient
    and req["channel_count"] >= min_channels
    and req["sfreq"] >= min_sfreq
)

result = {
    "eligible": bool(eligible),
    "missing_markers": missing,
    "insufficient_present_markers": insufficient,
    "recipe_version": recipe_version,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
