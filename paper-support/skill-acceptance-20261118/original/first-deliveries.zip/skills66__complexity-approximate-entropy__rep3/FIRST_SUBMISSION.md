Approximate entropy at m=2, r=0.65 (strict Chebyshev distance < r, self-matches included, mean log neighbor fraction over all fitting windows).

- phi_m: -2.090757288030014
- phi_m_plus_1: -2.7329804967013738
- approximate_entropy: 0.6422232086713597

Saved: /workspace/result.json (results) and /workspace/analysis.py (reusable program, executed to produce the result).
