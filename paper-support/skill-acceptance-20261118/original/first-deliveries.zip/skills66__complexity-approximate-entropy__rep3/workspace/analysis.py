
import json, numpy as np

def phi(x, m, r):
    x = np.asarray(x, dtype=float)
    N = len(x)
    n_windows = N - m + 1
    emb = np.array([x[i:i+m] for i in range(n_windows)])
    vals = []
    for i in range(n_windows):
        d = np.max(np.abs(emb - emb[i]), axis=1)
        c = np.sum(d < r) / n_windows  # self-match included
        vals.append(np.log(c))
    return float(np.mean(vals))

def approximate_entropy(x, m, r):
    pm = phi(x, m, r)
    pm1 = phi(x, m + 1, r)
    return pm, pm1, pm - pm1

if __name__ == "__main__":
    req = json.load(open("/input/request.json"))["input"]
    series, m, r = req["series"], req["m"], req["r"]
    pm, pm1, apen = approximate_entropy(series, m, r)
    out = {"phi_m": pm, "phi_m_plus_1": pm1, "approximate_entropy": apen}
    json.dump(out, open("/workspace/result.json", "w"), indent=2)
    print(json.dumps(out, indent=2))
