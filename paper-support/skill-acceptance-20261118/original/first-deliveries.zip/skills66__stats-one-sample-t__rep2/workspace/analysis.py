
import json
import numpy as np
from scipy import stats

with open("/input/request.json") as f:
    req = json.load(f)
x = np.asarray(req["input"]["contrasts"], dtype=float)
n = x.size
df = n - 1
t, p = stats.ttest_1samp(x, popmean=0.0, alternative="two-sided")
result = {"t": float(t), "df": int(df), "p_two_sided": float(p)}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
