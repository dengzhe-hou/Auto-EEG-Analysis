
import json, os, numpy as np, mne
from mne_bids import BIDSPath, write_raw_bids, read_raw_bids

req = json.load(open("/input/request.json"))
inp = req["input"]
data = np.array(inp["data_uV"], dtype=float) * 1e-6  # uV -> V
info = mne.create_info(inp["channel_names"], inp["sfreq"], inp["types"])
raw = mne.io.RawArray(data, info, first_samp=inp["first_samp"], verbose=False)
raw.info["bads"] = list(inp["bads"])

# Events: original absolute sample numbers; MNE events array keeps sample identities
events = np.array(inp["events_original_samples"], dtype=int)
event_id = {k: int(v) for k, v in inp["event_id"].items()}
annot_onsets = (events[:, 0] - raw.first_samp) / raw.info["sfreq"]
annot_desc = []
inv = {v: k for k, v in event_id.items()}
for e in events:
    annot_desc.append(inv[int(e[2])])
annotations = mne.Annotations(onset=annot_onsets, duration=np.zeros(len(events)), description=annot_desc)
raw.set_annotations(annotations)

bids_root = "/workspace/bids"
os.makedirs(bids_root, exist_ok=True)
bids_path = BIDSPath(subject="01", task="check", datatype="eeg", root=bids_root)
write_raw_bids(
    raw, bids_path, overwrite=True, allow_preload=True, format="BrainVision",
    event_id=event_id, verbose=False,
)

# Ensure reference and line frequency metadata
import glob
for f in glob.glob(os.path.join(bids_root, "sub-01", "eeg", "*_eeg.json")):
    meta = json.load(open(f))
    meta["EEGReference"] = "synthetic common reference"
    meta["PowerLineFrequency"] = inp["line_freq"]
    json.dump(meta, open(f, "w"), indent=2)

# Read back
raw2 = read_raw_bids(bids_path, verbose=False)
ann2 = raw2.annotations
first_saved = raw2.first_samp
rel = [int(round(o * raw2.info["sfreq"])) for o in ann2.onset]
bad_channels = list(raw2.info["bads"])
sfreq = float(raw2.info["sfreq"])
result = {
    "relative_event_samples": rel,
    "bad_channels": bad_channels,
    "sfreq": sfreq,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
