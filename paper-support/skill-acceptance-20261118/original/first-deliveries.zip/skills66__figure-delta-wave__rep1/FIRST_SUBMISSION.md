{"n_points": 5, "x_label": "Time (s)", "y_label": "Difference (uV)"}
