Saved /workspace/analysis.py and executed it; wrote /workspace/result.json.

{"coverage_pct": [40.0, 26.666666666666668, 33.33333333333333], "n_labeled": 15}
