import json
import numpy as np

with open("/input/request.json") as f:
    labels = np.array(json.load(f)["input"]["labels"])

labeled = labels[labels >= 0]
n_labeled = int(labeled.size)
coverage_pct = [float(np.sum(labeled == k) / n_labeled * 100.0) for k in (0, 1, 2)]

result = {"coverage_pct": coverage_pct, "n_labeled": n_labeled}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(result)
