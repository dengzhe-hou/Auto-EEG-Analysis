
import json
import numpy as np
from scipy.signal import get_window

req = json.load(open("/input/request.json"))
inp = req["input"]
x = np.asarray(inp["data_uV"], dtype=float)
fs = float(inp["sfreq"])
nperseg = int(inp["n_per_seg"])
nfft = int(inp["n_fft"])
noverlap = int(inp["n_overlap"])

win = get_window("hann", nperseg, fftbins=True)  # periodic Hann
step = nperseg - noverlap
starts = range(0, len(x) - nperseg + 1, step)
scale = fs * np.sum(win ** 2)
psds = []
for s in starts:
    seg = x[s:s + nperseg]
    seg = seg - seg.mean()
    X = np.fft.rfft(seg * win, n=nfft)
    p = (np.abs(X) ** 2) / scale
    # one-sided: double all bins except DC and Nyquist (nfft even)
    if nfft % 2 == 0:
        p[1:-1] *= 2.0
    else:
        p[1:] *= 2.0
    psds.append(p)
psd = np.mean(psds, axis=0)
freqs = np.fft.rfftfreq(nfft, d=1.0 / fs)

def band_sum(lo, hi):
    m = (freqs >= lo) & (freqs <= hi)
    return float(np.sum(psd[m]))

beta_fraction = band_sum(15, 30) / band_sum(2, 40)
result = {"beta_fraction": float(beta_fraction)}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
print("n_segments", len(psds), "freq_res", freqs[1] - freqs[0])
