
import json, numpy as np, mne
req = json.load(open("/input/request.json"))["input"]
raw_uV = np.array(req["raw_uV"], dtype=float)
sfreq = float(req["sfreq"])
ch_names = req["channel_names"]
events_arr = np.array(req["events"], dtype=int)
event_id = req["event_id"]
tmin, tmax = float(req["tmin"]), float(req["tmax"])
baseline = tuple(req["baseline"])
rej = req.get("reject_peak_to_peak_uV")

info = mne.create_info(ch_names, sfreq, ch_types="eeg")
raw = mne.io.RawArray(raw_uV * 1e-6, info, verbose=False)
reject = None
if rej is not None:
    reject = dict(eeg=float(rej) * 1e-6)
epochs = mne.Epochs(raw, events_arr, event_id=event_id, tmin=tmin, tmax=tmax,
                    baseline=baseline, reject=reject, preload=True, verbose=False)
epochs.save("/workspace/check-epo.fif", overwrite=True, verbose=False)

kept_idx = epochs.selection  # indices into original events
retained_event_samples = [int(events_arr[i, 0]) for i in kept_idx]
n_dropped = int(len(events_arr) - len(epochs))
times_s = [float(t) for t in epochs.times]
result = {
    "retained_event_samples": retained_event_samples,
    "times_s": times_s,
    "n_dropped": n_dropped,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
