
import json
import numpy as np

with open("/input/request.json") as f:
    req = json.load(f)["input"]

eeg_ids = req["eeg_trial_ids"]
eeg_uv = req["eeg_uV"]
beh_ids = req["behavior_trial_ids"]
rt = req["rt_ms"]

beh_map = {tid: r for tid, r in zip(beh_ids, rt)}
eeg_set = set(eeg_ids)

matched_ids, matched_eeg, matched_rt = [], [], []
for tid, u in zip(eeg_ids, eeg_uv):
    if tid in beh_map:
        matched_ids.append(tid)
        matched_eeg.append(float(u))
        matched_rt.append(float(beh_map[tid]))

missing_on_eeg = sorted([t for t in beh_ids if t not in eeg_set])

x = np.array(matched_eeg)
y = np.array(matched_rt)
X = np.column_stack([np.ones_like(x), x])
coef, *_ = np.linalg.lstsq(X, y, rcond=None)
slope = float(coef[1])

result = {
    "trial_ids": matched_ids,
    "missing_on_eeg": missing_on_eeg,
    "slope_ms_per_uV": slope,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
