
import json, math
import numpy as np

def sample_entropy_counts(x, m, r):
    x = np.asarray(x, dtype=float)
    N = len(x)
    # templates for length m and m+1 use same starting positions 0..N-m-1
    starts = range(N - m)  # positions permitting length m+1: i in 0..N-m-1
    def count(mm):
        idx = [i for i in range(N - m)]
        total = 0
        for a in range(len(idx)):
            for b in range(a + 1, len(idx)):
                i, j = idx[a], idx[b]
                d = np.max(np.abs(x[i:i+mm] - x[j:j+mm]))
                if d < r:
                    total += 1
        return total
    B = count(m)
    A = count(m + 1)
    return B, A

def run(path_in, path_out, m, r):
    with open(path_in) as f:
        req = json.load(f)
    series = req["input"]["series"]
    B, A = sample_entropy_counts(series, m, r)
    se = -math.log(A / B) if A > 0 and B > 0 else float("inf")
    result = {"counts_m": B, "counts_m_plus_1": A, "sample_entropy": se}
    with open(path_out, "w") as f:
        json.dump(result, f, indent=2)
    return result

if __name__ == "__main__":
    print(run("/input/request.json", "/workspace/result.json", 2, 0.45))
