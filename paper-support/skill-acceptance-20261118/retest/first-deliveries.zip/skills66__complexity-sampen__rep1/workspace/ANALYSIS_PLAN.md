Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-complexity. Input: /input/request.json. Use its input field.
Calculate standard sample entropy for the supplied single-channel series, m=2, threshold r=0.45 in the same units, Chebyshev strict distance < r. For both lengths use the same starting positions that permit length m+1; count unique unordered pairs and exclude self-matches. Report counts_m, counts_m_plus_1, and sample_entropy using natural logs.
Use full numeric precision in result.json. The required fields are counts_m, counts_m_plus_1, sample_entropy. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
