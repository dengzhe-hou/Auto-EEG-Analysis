{"trial_ids": [11, 13, 16, 15], "missing_on_eeg": [12, 14], "slope_ms_per_uV": 39.99999999999999}
