
import json
import numpy as np

req = json.load(open("/input/request.json"))["input"]
eeg_ids = req["eeg_trial_ids"]
eeg_uv = req["eeg_uV"]
beh_ids = req["behavior_trial_ids"]
rt_ms = req["rt_ms"]

rt_by_id = dict(zip(beh_ids, rt_ms))
eeg_by_id = dict(zip(eeg_ids, eeg_uv))

# Join strictly on trial ID, retaining EEG row order.
matched_ids = [t for t in eeg_ids if t in rt_by_id]
missing_on_eeg = sorted(t for t in beh_ids if t not in eeg_by_id)

x = np.array([eeg_by_id[t] for t in matched_ids], dtype=float)
y = np.array([rt_by_id[t] for t in matched_ids], dtype=float)

# OLS RT (ms) ~ EEG (uV) with intercept.
X = np.column_stack([np.ones_like(x), x])
beta, *_ = np.linalg.lstsq(X, y, rcond=None)
slope = float(beta[1])

result = {
    "trial_ids": matched_ids,
    "missing_on_eeg": missing_on_eeg,
    "slope_ms_per_uV": slope,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
