Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-behavior. Input: /input/request.json. Use its input field.
Join EEG and behavior strictly on the trial ID, retaining EEG row order and reporting unmatched behavior IDs. On the matched trials from one subject fit OLS RT in ms against EEG in uV with an intercept. Return trial_ids, missing_on_eeg, and slope_ms_per_uV. In result.json, missing_on_eeg is a list of unmatched behavior trial IDs sorted numerically.
Use full numeric precision in result.json. The required fields are trial_ids, missing_on_eeg, slope_ms_per_uV. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
