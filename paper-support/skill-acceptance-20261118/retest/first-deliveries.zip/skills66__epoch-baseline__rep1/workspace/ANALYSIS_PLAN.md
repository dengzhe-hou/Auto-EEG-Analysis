Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-epoch. Input: /input/request.json. Use its input field.
Using MNE, create epochs from the source EEG in uV (convert to V), with events on the supplied raw sample grid, the indicated inclusive time limits and baseline. If reject_peak_to_peak_uV is supplied, apply it to EEG channels only. Save epochs to check-epo.fif. Return retained_event_samples, times_s and n_dropped.
Use full numeric precision in result.json. The required fields are retained_event_samples, times_s, n_dropped. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
