
import json, numpy as np, mne
mne.set_log_level("WARNING")
req = json.load(open("/input/request.json"))["input"]
data = np.array(req["raw_uV"], dtype=float) * 1e-6  # uV -> V
ch_names = req["channel_names"]
sfreq = float(req["sfreq"])
events = np.array(req["events"], dtype=int)
event_id = req["event_id"]
tmin, tmax = float(req["tmin"]), float(req["tmax"])
baseline = tuple(req["baseline"])
rej_uV = req.get("reject_peak_to_peak_uV")

info = mne.create_info(ch_names, sfreq, ch_types="eeg")
raw = mne.io.RawArray(data, info, verbose=False)
epochs = mne.Epochs(raw, events, event_id=event_id, tmin=tmin, tmax=tmax,
                    baseline=baseline, preload=True, verbose=False)
n_before = len(epochs)
if rej_uV is not None:
    reject = dict(eeg=float(rej_uV) * 1e-6)
    epochs.drop_bad(reject=reject, verbose=False)
n_dropped = n_before - len(epochs)
retained = epochs.events[:, 0].astype(int).tolist()
times = epochs.times.tolist()
epochs.save("/workspace/check-epo.fif", overwrite=True, verbose=False)
result = {"retained_event_samples": retained, "times_s": times, "n_dropped": int(n_dropped)}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result)[:500])
