Epoching completed. I used the supplied 2-channel signal converted from µV to V, sfreq 100 Hz, three events with event_id {'stimulus': 1}, window -0.1 to 0.2 s, baseline [-0.1, 0]. No peak-to-peak rejection was requested (reject_peak_to_peak_uV = None), so no epochs were rejected.

Results (saved to /workspace/result.json):
- retained_event_samples: [35, 75, 114]
- times_s: 31 values from -0.1 to 0.2 s in 0.01 s steps
- n_dropped: 0

Saved artifacts:
- /workspace/analysis.py (reusable script)
- /workspace/check-epo.fif (epochs)
- /workspace/result.json
