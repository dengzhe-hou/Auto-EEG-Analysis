
import json, numpy as np, mne
req = json.load(open("/input/request.json"))["input"]
X = np.array(req["epochs_uV"], dtype=float)  # uV
labels = np.array(req["labels"])
ch = req["channel_names"]; sfreq = float(req["sfreq"]); tmin = float(req["tmin"])
info = mne.create_info(ch, sfreq, ch_types="eeg")
# MNE expects volts
ep = mne.EpochsArray(X * 1e-6, info, tmin=tmin, verbose=False)
ev_A = ep[labels == "A"].average()
ev_B = ep[labels == "B"].average()
diff = mne.combine_evoked([ev_B, ev_A], weights=[1, -1])
diff.comment = "B-A"
diff.save("/workspace/check-ave.fif", overwrite=True, verbose=False)
times = diff.times
win = (times >= 0.1 - 1e-9) & (times <= 0.3 + 1e-9)
roi_idx = [ch.index("Cz"), ch.index("Pz")]
data_uV = diff.data * 1e6
roi_mean = float(np.mean(data_uV[roi_idx][:, win]))
n_win = int(win.sum())
n_A = int(np.sum(labels == "A")); n_B = int(np.sum(labels == "B"))
result = {"roi_mean_uV": roi_mean, "n_window_samples": n_win,
          "n_condition_trials": [n_A, n_B]}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(result)
