{"roi_mean_uV": 4.999670508103991, "n_window_samples": 21, "n_condition_trials": [2, 3]}
