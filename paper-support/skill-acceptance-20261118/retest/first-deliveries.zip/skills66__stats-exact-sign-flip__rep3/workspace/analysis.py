
import json, itertools
import numpy as np

with open("/input/request.json") as f:
    data = json.load(f)
x = np.asarray(data["input"]["contrasts"], dtype=float)
n = len(x)

observed_abs_mean = abs(x.mean())

stats = []
for signs in itertools.product([1, -1], repeat=n):
    s = np.asarray(signs, dtype=float)
    stats.append(abs((s * x).mean()))
stats = np.asarray(stats)

n_patterns = len(stats)
p_exact = float(np.sum(stats >= observed_abs_mean - 1e-12) / n_patterns)

result = {
    "observed_abs_mean": float(observed_abs_mean),
    "n_patterns": int(n_patterns),
    "p_exact": p_exact,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
