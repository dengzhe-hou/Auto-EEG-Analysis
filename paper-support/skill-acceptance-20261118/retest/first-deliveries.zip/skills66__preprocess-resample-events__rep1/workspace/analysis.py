
import json
import numpy as np
import mne

req = json.load(open("/input/request.json"))
inp = req["input"]
data_uV = np.asarray(inp["raw_uV"], dtype=float)
names = inp["names"]
types = inp["types"]
sfreq = float(inp["sfreq"])
new_sfreq = float(inp["new_sfreq"])
events = np.asarray(inp["events"], dtype=int)

info = mne.create_info(ch_names=names, sfreq=sfreq, ch_types=types)
raw = mne.io.RawArray(data_uV * 1e-6, info, verbose=False)

raw_rs, ev_rs = raw.copy().resample(
    new_sfreq, npad=0, window="boxcar", method="fft",
    events=events, verbose=False)

new_sfreq_out = float(raw_rs.info["sfreq"])
samples_uV = raw_rs.get_data() * 1e6

result = {
    "new_sfreq": new_sfreq_out,
    "relative_event_samples": np.asarray(ev_rs).tolist(),
    "samples_uV": samples_uV.tolist(),
}
json.dump(result, open("/workspace/result.json", "w"))
print(new_sfreq_out, np.shape(samples_uV), np.asarray(ev_rs).shape)
