The approved resampling ran successfully. Saved `/workspace/analysis.py` and `/workspace/result.json`.

Result: new_sfreq = 50.0 Hz; relative_event_samples = 3 events (on the resampled grid); samples_uV = 3 channels (Fz, Cz, Pz) × 200 samples, full precision.

Method: MNE `resample` with method="fft", npad=0, window="boxcar", events passed jointly. No other preprocessing applied.
