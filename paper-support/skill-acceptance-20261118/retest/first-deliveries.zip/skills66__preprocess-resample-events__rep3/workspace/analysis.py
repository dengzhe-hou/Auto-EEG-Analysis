
import json
import numpy as np
import mne

req = json.load(open("/input/request.json"))
inp = req["input"]

data = np.array(inp["raw_uV"], dtype=float) * 1e-6  # uV -> V
info = mne.create_info(ch_names=inp["names"], sfreq=inp["sfreq"], ch_types=inp["types"])
raw = mne.io.RawArray(data, info, verbose=False)

events = np.array(inp["events"], dtype=int)
# Resample with fft method, no padding, boxcar window, jointly with events
raw_rs, events_rs = raw.copy().resample(
    sfreq=inp["new_sfreq"], npad=0, window="boxcar",
    method="fft", events=events, verbose=False
)

new_sfreq = float(raw_rs.info["sfreq"])
rel_samples = [int(e[0]) for e in events_rs]
samples_uV = raw_rs.get_data() * 1e6

result = {
    "new_sfreq": new_sfreq,
    "relative_event_samples": rel_samples,
    "samples_uV": samples_uV.tolist(),
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f)
print(new_sfreq, rel_samples, samples_uV.shape)
