Deliverables saved:
- /workspace/analysis.py (reusable program, executed)
- /workspace/result.json (full-precision JSON)

Result fields:
- new_sfreq: 50.0
- relative_event_samples: [20, 94, 106]
- samples_uV: 3 channels (Fz, Cz, Pz) × 200 samples at 50 Hz, full precision

Method: MNE 1.8.0 Raw.resample at 50 Hz, method="fft", npad=0, window="boxcar", with events resampled jointly. No further preprocessing was applied.
