
import json
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import LeaveOneGroupOut

req = json.load(open("/input/request.json"))
X = np.array(req["input"]["features"], dtype=float)
y = np.array(req["input"]["labels"])
groups = np.array(req["input"]["groups"])

n_trials, n_channels, n_times = X.shape
predictions = np.zeros((n_trials, n_times), dtype=y.dtype)
accuracy = []

logo = LeaveOneGroupOut()
for t in range(n_times):
    Xt = X[:, :, t]
    for train_idx, test_idx in logo.split(Xt, y, groups):
        clf = make_pipeline(
            StandardScaler(),
            LogisticRegression(C=1, solver="liblinear", random_state=42, max_iter=1000),
        )
        clf.fit(Xt[train_idx], y[train_idx])
        predictions[test_idx, t] = clf.predict(Xt[test_idx])
    accuracy.append(float(np.mean(predictions[:, t] == y)))

classes, counts = np.unique(y, return_counts=True)
chance_accuracy = float(counts.max() / counts.sum())

result = {
    "predictions": predictions.tolist(),
    "accuracy": accuracy,
    "chance_accuracy": chance_accuracy,
}
import os
os.makedirs("/workspace", exist_ok=True)
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(predictions.shape, accuracy, chance_accuracy)
