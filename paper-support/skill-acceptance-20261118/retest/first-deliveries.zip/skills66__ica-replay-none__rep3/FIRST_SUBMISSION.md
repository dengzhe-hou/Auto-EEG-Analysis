Saved /workspace/analysis.py and /workspace/result.json.

result.json fields:
- cleaned_uV: 3 × 40 array (channel by sample), full numeric precision
- applied_exclusions: [] (no approved component indices were supplied, so none were zeroed)

Method: applied the supplied fixed unmixing matrix to channel-centred data, zeroed no components, and reconstructed with the supplied mixing matrix. No refit was performed.
