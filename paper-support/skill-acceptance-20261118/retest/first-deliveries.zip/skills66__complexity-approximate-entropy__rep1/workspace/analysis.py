
import json, math
import numpy as np

def phi(x, m, r):
    N = len(x)
    n_templ = N - m + 1
    templates = np.array([x[i:i+m] for i in range(n_templ)])
    total = 0.0
    for i in range(n_templ):
        d = np.max(np.abs(templates - templates[i]), axis=1)
        count = np.sum(d < r)   # strict, includes self-match
        total += math.log(count / n_templ)
    return total / n_templ

with open("/input/request.json") as f:
    req = json.load(f)["input"]
x = np.asarray(req["series"], dtype=float)
m = int(req["m"]); r = float(req["r"])

phi_m = phi(x, m, r)
phi_m1 = phi(x, m + 1, r)
apen = phi_m - phi_m1

result = {"phi_m": float(phi_m), "phi_m_plus_1": float(phi_m1), "approximate_entropy": float(apen)}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
