
import json
import numpy as np
import mne

REQ = "/input/request.json"
OUT = "/workspace/result.json"

req = json.load(open(REQ))
inp = req["input"]
epochs = np.asarray(inp["epochs_uV"], dtype=float)  # trial, channel, time (uV)
sfreq = float(inp["sfreq"])
tmin = float(inp["tmin"])
sample_indices = [int(i) for i in inp["sample_indices"]]

freqs = np.array([10.0])
n_cycles = np.array([5.0])

# tfr_array_morlet expects V for consistent units; work in V, convert back to uV^2
epochs_V = epochs * 1e-6
power = mne.time_frequency.tfr_array_morlet(
    epochs_V, sfreq=sfreq, freqs=freqs, n_cycles=n_cycles,
    output="power", zero_mean=True, decim=1, n_jobs=1,
)  # shape: trial, channel, freq, time  (V^2)

avg_power_V2 = power.mean(axis=0)[:, 0, :]          # channel, time
avg_power_uV2 = avg_power_V2 * 1e12                  # V^2 -> uV^2

times = tmin + np.arange(epochs.shape[-1]) / sfreq
times_s = [float(times[i]) for i in sample_indices]
values = [[float(avg_power_uV2[c, i]) for i in sample_indices]
          for c in range(epochs.shape[1])]

result = {"values": values, "times_s": times_s}
json.dump(result, open(OUT, "w"), indent=2)
print(json.dumps(result))
