Saved /workspace/analysis.py and executed it. Results were written to /workspace/result.json:

{
  "statistic": 2.353835283221946,
  "p_value": 0.06524854507932806,
  "n_per_group": [6, 6]
}

Test: two-sided paired t-test on A minus B (participant-level values, paired subject as observation unit). No cluster inference was performed, as none was assigned.
