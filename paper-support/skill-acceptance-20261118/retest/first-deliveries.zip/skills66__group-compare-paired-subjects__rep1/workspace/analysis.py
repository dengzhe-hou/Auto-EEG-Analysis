import os
import json
from scipy import stats

with open("/input/request.json") as f:
    req = json.load(f)

A = req["input"]["A"]
B = req["input"]["B"]

diff = [a - b for a, b in zip(A, B)]
res = stats.ttest_rel(A, B, alternative="two-sided")

result = {
    "statistic": float(res.statistic),
    "p_value": float(res.pvalue),
    "n_per_group": [len(A), len(B)],
}

os.makedirs("/workspace", exist_ok=True)
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
