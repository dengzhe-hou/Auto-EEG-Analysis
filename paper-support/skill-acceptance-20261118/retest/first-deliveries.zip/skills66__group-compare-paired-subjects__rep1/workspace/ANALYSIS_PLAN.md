Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-group-compare. Input: /input/request.json. Use its input field.
Test independent participant-level summaries using two-sided paired t test on A minus B. Return statistic, p_value and n_per_group in input order. Each element is one participant value. Check the specified test path and unit of analysis; no cluster inference is assigned. Return n_per_group as [number of values in A, number of values in B] even when the sizes are equal. The observation unit remains the paired subject.
Use full numeric precision in result.json. The required fields are statistic, p_value, n_per_group. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
