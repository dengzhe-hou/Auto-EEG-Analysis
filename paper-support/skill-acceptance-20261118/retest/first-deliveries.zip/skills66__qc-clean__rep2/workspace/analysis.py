
import json, sys
sys.path.insert(0, "/workspace")
import numpy as np
import mne
from qc_amplitude import amplitude_qc

req = json.load(open("/input/request.json"))["input"]
signal_v = np.asarray(req["signal_uV"], dtype=float) * 1e-6  # uV -> V
names = list(req["channel_names"])
sfreq = float(req["sfreq"])

info = mne.create_info(names, sfreq, ch_types="eeg")
raw = mne.io.RawArray(signal_v, info, verbose=False)

findings = amplitude_qc(raw)

constant_channels = sorted({s["channel"] for s in findings["constant_segments"]})
rapid_change_channels = sorted({s["channel"] for s in findings["jump_segments"]})
bad_channel_candidates = sorted(findings["bad_channel_candidates"])

result = {
    "constant_channels": constant_channels,
    "rapid_change_channels": rapid_change_channels,
    "bad_channel_candidates": bad_channel_candidates,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
print(json.dumps(findings["per_channel"], indent=2))
