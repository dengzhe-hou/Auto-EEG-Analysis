QC on the two-channel input (Fz, Cz; 1000 Hz; 1000 samples each; µV converted to V) found no constant segments, no rapid-change segments, and no bad-channel candidates. The per-channel constant and jump fractions were both 0.0, and no candidate reasons were recorded. Low-amplitude warnings were not raised as bad channels. No cleaning or annotation changes were applied.

Saved artifacts:
- /workspace/analysis.py (reusable program that executes the AEA amplitude QC helper and writes result.json)
- /workspace/qc_amplitude.py (copy of the AEA amplitude helper, saved beside the program for replay)
- /workspace/result.json

Final result.json:
{
  "constant_channels": [],
  "rapid_change_channels": [],
  "bad_channel_candidates": []
}
