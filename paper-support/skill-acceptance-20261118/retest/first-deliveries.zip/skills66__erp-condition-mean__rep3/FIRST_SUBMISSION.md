{"roi_mean_uV": -0.0030618166539813107, "n_window_samples": 21, "n_condition_trials": [2, 3]}
