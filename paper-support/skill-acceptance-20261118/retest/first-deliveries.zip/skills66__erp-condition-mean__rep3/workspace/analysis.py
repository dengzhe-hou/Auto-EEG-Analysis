
import json
import numpy as np
import mne

req = json.load(open("/input/request.json"))
inp = req["input"]
epochs = np.array(inp["epochs_uV"], dtype=float)  # trials x ch x time, uV
labels = np.array(inp["labels"])
ch_names = inp["channel_names"]
sfreq = float(inp["sfreq"])
tmin = float(inp["tmin"])

# uV -> V for MNE
data = epochs * 1e-6
info = mne.create_info(ch_names, sfreq, ch_types="eeg")
idx_A = np.where(labels == "A")[0]
idx_B = np.where(labels == "B")[0]
data_A = data[idx_A]
n_A = int(len(idx_A))
n_B = int(len(idx_B))
info_A = info
epo_A = mne.EpochsArray(data_A, info_A, tmin=tmin, verbose=False)
evoked_A = epo_A.average()
evoked_A.save("/workspace/check-ave.fif", overwrite=True, verbose=False)

# ROI: Cz and Pz, 0.1-0.3 s inclusive
ev = evoked_A.copy().pick(["Cz", "Pz"])
t = ev.times
mask = (t >= 0.1 - 1e-9) & (t <= 0.3 + 1e-9)
n_window = int(mask.sum())
roi_uV = float(np.mean(ev.data[:, mask]) * 1e6)  # equal-weight channel x sample mean

result = {
    "roi_mean_uV": roi_uV,
    "n_window_samples": n_window,
    "n_condition_trials": [n_A, n_B],
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
