
import json, os
import numpy as np
import mne

req = json.load(open("/input/request.json"))
inp = req["input"]
data = np.array(inp["epochs_uV"], dtype=float)
labels = np.array(inp["labels"])
ch_names = inp["channel_names"]
sfreq = float(inp["sfreq"])
tmin = float(inp["tmin"])

# Convert uV to V for MNE
data_V = data * 1e-6
info = mne.create_info(ch_names, sfreq, ch_types="eeg")
epochs = mne.EpochsArray(data_V, info, tmin=tmin, events=None, verbose=False)
epochs.event_id = {"A": 1, "B": 2}
ev = np.array([[i, 0, 1 if l == "A" else 2] for i, l in enumerate(labels)])
epochs.events = ev

cond_A = epochs["A"]
n_condition_trials = [len(epochs["A"]), len(epochs["B"])]
evoked_A = cond_A.average()
evoked_A.save("/workspace/check-ave.fif", overwrite=True, verbose=False)

times = evoked_A.times
win = (times >= 0.1 - 1e-9) & (times <= 0.3 + 1e-9)
n_window_samples = int(win.sum())
roi_idx = [ch_names.index("Cz"), ch_names.index("Pz")]
roi_data_uV = evoked_A.data[roi_idx][:, win] * 1e6
roi_mean_uV = float(roi_data_uV.mean())

result = {
    "roi_mean_uV": roi_mean_uV,
    "n_window_samples": n_window_samples,
    "n_condition_trials": n_condition_trials,
}
os.makedirs("/workspace", exist_ok=True)
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
