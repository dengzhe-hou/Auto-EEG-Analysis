
import json
import numpy as np

with open("/input/request.json") as f:
    data = json.load(f)["input"]

label = np.asarray(data["label"])
gfp = np.asarray(data["gfp"], dtype=float)
corr = np.asarray(data["corr"], dtype=float)

denom = np.sum(gfp ** 2)
gev_by_state = []
for k in [0, 1, 2]:
    mask = label == k
    num = np.sum((gfp[mask] ** 2) * (corr[mask] ** 2))
    gev_by_state.append(float(num / denom))
gev_total = float(sum(gev_by_state))

result = {"gev_by_state": gev_by_state, "gev_total": gev_total}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
