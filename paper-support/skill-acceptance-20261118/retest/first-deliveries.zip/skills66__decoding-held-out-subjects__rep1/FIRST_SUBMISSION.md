Time-resolved leave-one-group-out decoding was completed on the 24-trial, 3-channel, 5-timepoint input. Each time point was fit independently with StandardScaler inside each fold and LogisticRegression(C=1, solver="liblinear", random_state=42, max_iter=1000).

Outputs:
- /workspace/analysis.py: reusable program, executed successfully.
- /workspace/result.json: contains the fields predictions (24 x 5 held-out predictions in original trial order), accuracy (per-time-point accuracy), and chance_accuracy.

Results:
- Predictions shape: (24, 5)
- Accuracy per time point: [0.4167, 0.4167, 1.0, 1.0, 0.75]
- Chance accuracy: 0.5

These are engineering fixture results on synthetic data, reported as computed, without inferential testing.
