
import json, numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.metrics import accuracy_score

req = json.load(open("/input/request.json"))["input"]
X = np.array(req["features"], dtype=float)   # trial x channel x time
y = np.array(req["labels"])
g = np.array(req["groups"])
n_trials, n_ch, n_times = X.shape

preds = np.zeros((n_trials, n_times), dtype=y.dtype)
acc = []
for t in range(n_times):
    Xt = X[:, :, t]
    for grp in np.unique(g):
        test = g == grp
        train = ~test
        clf = make_pipeline(StandardScaler(),
                            LogisticRegression(C=1, solver="liblinear",
                                               random_state=42, max_iter=1000))
        clf.fit(Xt[train], y[train])
        preds[test, t] = clf.predict(Xt[test])
    acc.append(accuracy_score(y, preds[:, t]))

acc = np.array(acc, dtype=float)
chance = float(max(np.mean(y == c) for c in np.unique(y)))
result = {
    "predictions": preds.tolist(),
    "accuracy": acc.tolist(),
    "chance_accuracy": chance,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(preds.shape, acc, chance)
