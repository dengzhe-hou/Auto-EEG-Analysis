
import json, re

req = json.load(open("/input/request.json"))["input"]
txt = open("/workspace/aea/recipes/n400-semantic/RECIPE.md").read()
header = txt.split("---")[1]

def field(name):
    m = re.search(rf"^{name}:\s*(.+)$", header, re.M)
    return m.group(1).strip().strip('"')

min_channels = int(field("min_channels"))
min_sfreq = float(field("min_sfreq"))
min_trials = int(field("min_trials_per_condition"))
required = re.search(r"required_markers:\s*\[(.*)\]", header).group(1)
required = sorted(x.strip() for x in required.split(","))
recipe_version = field("version")

counts = req["marker_counts"]
present = set(counts.keys())
missing_markers = sorted(m for m in required if m not in present)
insufficient = sorted(m for m in required if m in present and counts[m] < min_trials)

eligible = (req["channel_count"] >= min_channels
            and req["sfreq"] >= min_sfreq
            and not missing_markers
            and not insufficient)

result = {
    "eligible": bool(eligible),
    "missing_markers": missing_markers,
    "insufficient_present_markers": insufficient,
    "recipe_version": recipe_version,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result, indent=2))
