import json
import numpy as np

req = json.load(open("/input/request.json"))
labels = req["input"]["labels"]
K = [0, 1, 2]
idx = {k: i for i, k in enumerate(K)}
counts = np.zeros((3, 3), dtype=int)

for a, b in zip(labels[:-1], labels[1:]):
    if a == -1 or b == -1:
        continue
    if a not in idx or b not in idx:
        continue
    if a == b:
        continue
    counts[idx[a], idx[b]] += 1

probs = np.zeros((3, 3), dtype=float)
for i in range(3):
    s = counts[i].sum()
    if s > 0:
        probs[i] = counts[i] / s

result = {
    "counts": counts.tolist(),
    "probabilities": [[float(x) for x in row] for row in probs.tolist()],
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
