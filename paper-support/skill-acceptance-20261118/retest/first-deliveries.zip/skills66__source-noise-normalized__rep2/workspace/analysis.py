
import json
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
G = np.array(inp["gain"], dtype=float)
C = np.array(inp["noise_cov"], dtype=float)
Y = np.array(inp["sensor_data"], dtype=float)
lam2 = float(inp["lambda2"])
normalize = bool(inp["normalize_noise"])

# K = G^T (G G^T + lambda2 C)^{-1}
K = G.T @ np.linalg.inv(G @ G.T + lam2 * C)
S = K @ Y

if normalize:
    d = np.sqrt(np.diag(K @ C @ K.T))
    S = S / d[:, None]

result = {
    "source_estimates": S.tolist(),
    "normalized": normalize,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
