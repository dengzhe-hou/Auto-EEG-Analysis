
import json, runpy, sys
import numpy as np
import mne
from mne_bids import BIDSPath, write_raw_bids, read_raw_bids
import pandas as pd

sys.path.insert(0, "/workspace/aea/skills/eeg-bids/scripts")
from events import prepare_event_export, check_exported_events

req = json.load(open("/input/request.json"))["input"]
data = np.asarray(req["data_uV"], dtype=float) * 1e-6
info = mne.create_info(req["channel_names"], req["sfreq"], req["types"])
raw = mne.io.RawArray(data, info, first_samp=req["first_samp"], verbose=False)
raw.info["bads"] = list(req["bads"])

src_events = np.asarray(req["events_original_samples"], dtype=int)
event_id = req["event_id"]
out, write_kwargs, receipt = prepare_event_export(
    raw, source="external", event_id=event_id,
    additional_annotation_event_id={}, events=src_events)

bids_root = "/workspace/bids"
bids_path = BIDSPath(subject="01", task="check", datatype="eeg", root=bids_root)
write_raw_bids(out, bids_path, overwrite=True, allow_preload=True, format="BrainVision",
               event_id=write_kwargs["event_id"], events=None, verbose=False)

# Set reference and line frequency in sidecar
import glob
json_path = glob.glob(f"{bids_root}/sub-01/eeg/*_eeg.json")[0]
sc = json.load(open(json_path))
sc["EEGReference"] = "synthetic common reference"
sc["PowerLineFrequency"] = req["line_freq"]
json.dump(sc, open(json_path, "w"), indent=4)

events_path = glob.glob(f"{bids_root}/sub-01/eeg/*_events.tsv")[0]
check = check_exported_events(events_path, receipt=receipt, time_atol_s=1e-6)

back = read_raw_bids(bids_path, verbose=False)
sc2 = json.load(open(json_path))
assert sc2["EEGReference"] == "synthetic common reference"
assert sc2["PowerLineFrequency"] == req["line_freq"]

ev_tsv = pd.read_csv(events_path, sep="\t")
rel_samples = [int(s) for s in ev_tsv["sample"].tolist()] if "sample" in ev_tsv else None
if rel_samples is None:
    ev, _ = mne.events_from_annotations(back, verbose=False)
    rel_samples = [int(s) for s in ev[:, 0] - back.first_samp]
rel_samples = sorted(rel_samples)

result = {
    "relative_event_samples": rel_samples,
    "bad_channels": list(back.info["bads"]),
    "sfreq": float(back.info["sfreq"]),
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result), check, sc2["EEGReference"], sc2["PowerLineFrequency"])
