{"relative_event_samples": [113, 256, 381], "bad_channels": [], "sfreq": 128.0}
