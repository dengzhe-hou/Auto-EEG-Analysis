
import json
import numpy as np
from scipy.signal import get_window

req = json.load(open("/input/request.json"))["input"]
x = np.asarray(req["data_uV"], dtype=float)
fs = float(req["sfreq"])
nperseg = int(req["n_per_seg"])
nfft = int(req["n_fft"])
noverlap = int(req["n_overlap"])
step = nperseg - noverlap

win = get_window("hann", nperseg, fftbins=True)  # periodic Hann
scale = fs * np.sum(win ** 2)

segs = []
start = 0
while start + nperseg <= len(x):
    seg = x[start:start + nperseg]
    seg = seg - seg.mean()
    segs.append(seg)
    start += step
segs = np.array(segs)

spec = np.fft.rfft(segs * win, n=nfft, axis=1)
pxx = (np.abs(spec) ** 2) / scale
# one-sided: double all bins except DC and Nyquist (nfft even)
if nfft % 2 == 0:
    pxx[:, 1:-1] *= 2
else:
    pxx[:, 1:] *= 2
psd = pxx.mean(axis=0)
freqs = np.fft.rfftfreq(nfft, d=1.0 / fs)
df = freqs[1] - freqs[0]

mask = (freqs >= 8) & (freqs <= 12)
alpha_power = float(np.sum(psd[mask]) * df)

result = {"alpha_power_uV2": alpha_power}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
print("n_segments", len(segs), "df", df, "bins", int(mask.sum()))
