Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-spectral. Input: /input/request.json. Use its input field.
Compute one-sided mean Welch PSD in uV^2/Hz using periodic Hann, segment demeaning and explicit n_fft, n_per_seg and overlap. Return alpha_power_uV2 as sum of PSD bins from 8 through 12 Hz inclusive times df.
Use full numeric precision in result.json. The required fields are alpha_power_uV2. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
