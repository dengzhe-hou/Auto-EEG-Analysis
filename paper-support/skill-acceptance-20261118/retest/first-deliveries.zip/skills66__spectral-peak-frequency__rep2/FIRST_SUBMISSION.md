Analysis complete. The reusable program is saved at /workspace/analysis.py and was executed; the result is saved at /workspace/result.json.

Settings used: sfreq=128 Hz, n_per_seg=128, n_fft=128, n_overlap=64 (50%), periodic Hann window, per-segment demeaning, one-sided mean Welch PSD in uV^2/Hz (no extra factor-2 applied beyond the one-sided convention in the helper).

Result (alpha band search over 8–12 Hz, maximum bin):
{
  "alpha_peak_hz": 11.0,
  "psd_uV2_per_hz": 0.8533333333333337
}
