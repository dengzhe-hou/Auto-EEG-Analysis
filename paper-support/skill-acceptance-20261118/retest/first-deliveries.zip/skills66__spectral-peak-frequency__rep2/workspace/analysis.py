
import json
import numpy as np
from scipy.signal import get_window

def welch_mean_psd(x, sfreq, n_per_seg, n_fft, n_overlap):
    x = np.asarray(x, dtype=float)
    step = n_per_seg - n_overlap
    win = get_window("hann", n_per_seg, fftbins=True)  # periodic Hann
    scale = sfreq * np.sum(win ** 2)
    segs = []
    for start in range(0, len(x) - n_per_seg + 1, step):
        seg = x[start:start + n_per_seg]
        seg = seg - seg.mean()  # segment demeaning
        spec = np.fft.rfft(seg * win, n=n_fft)
        p = (np.abs(spec) ** 2) / scale
        if n_fft % 2 == 0:
            p[1:-1] *= 2.0
        else:
            p[1:] *= 2.0
        segs.append(p)
    psd = np.mean(segs, axis=0)
    freqs = np.fft.rfftfreq(n_fft, d=1.0 / sfreq)
    return freqs, psd

def alpha_peak(freqs, psd, lo=8.0, hi=12.0):
    mask = (freqs >= lo) & (freqs <= hi)
    idx = np.where(mask)[0]
    k = idx[np.argmax(psd[idx])]
    return float(freqs[k]), float(psd[k])

if __name__ == "__main__":
    req = json.load(open("/input/request.json"))["input"]
    x = np.array(req["data_uV"], dtype=float)
    freqs, psd = welch_mean_psd(x, req["sfreq"], req["n_per_seg"], req["n_fft"], req["n_overlap"])
    f_pk, p_pk = alpha_peak(freqs, psd)
    result = {"alpha_peak_hz": f_pk, "psd_uV2_per_hz": p_pk}
    with open("/workspace/result.json", "w") as fh:
        json.dump(result, fh, indent=2)
    print(json.dumps(result))
