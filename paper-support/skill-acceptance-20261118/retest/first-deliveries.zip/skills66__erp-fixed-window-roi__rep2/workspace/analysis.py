
import json
import numpy as np
import mne

req = json.load(open("/input/request.json"))
inp = req["input"]
E = np.array(inp["epochs_uV"], dtype=float)          # (n_epochs, n_ch, n_times), in uV
labels = np.array([str(x) for x in inp["labels"]])
ch_names = list(inp["channel_names"])
sfreq = float(inp["sfreq"])
tmin = float(inp["tmin"])

# MNE expects Volts
data_V = E * 1e-6
info = mne.create_info(ch_names, sfreq, ch_types="eeg")
epochs = mne.EpochsArray(data_V, info, tmin=tmin, verbose=False)
epochs.events = np.column_stack([np.arange(len(labels)), np.zeros(len(labels), int), np.arange(len(labels))])
epochs.event_id = {"A": 1, "B": 2}
epochs.events[:, 2] = np.array([1 if l == "A" else 2 for l in labels])

evk_A = epochs["A"].average()
evk_B = epochs["B"].average()
diff = mne.combine_evoked([evk_B, evk_A], weights=[1, -1])   # B - A
diff.comment = "B-A"
mne.write_evokeds("/workspace/check-ave.fif", [diff], verbose=False)

times = diff.times
win = (times >= 0.1 - 1e-12) & (times <= 0.3 + 1e-12)
n_window = int(win.sum())
roi_idx = [ch_names.index("Cz"), ch_names.index("Pz")]
roi_mean_uV = float(diff.data[roi_idx][:, win].mean() * 1e6)

n_A = int(np.sum(labels == "A"))
n_B = int(np.sum(labels == "B"))

result = {
    "roi_mean_uV": roi_mean_uV,
    "n_window_samples": n_window,
    "n_condition_trials": [n_A, n_B],
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
