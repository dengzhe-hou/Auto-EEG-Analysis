Epoching completed. Program saved at /workspace/analysis.py, epochs saved at /workspace/check-epo.fif, and results saved at /workspace/result.json.

Result:
- retained_event_samples: [35, 75, 114]
- n_dropped: 0
- times_s: 31 samples from -0.1 to 0.2 s (inclusive, 100 Hz grid)

Settings applied: raw µV converted to V, tmin=-0.1, tmax=0.2, no baseline, no rejection (reject_peak_to_peak_uV not supplied).
