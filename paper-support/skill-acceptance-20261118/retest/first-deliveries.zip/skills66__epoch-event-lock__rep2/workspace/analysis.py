
import json, os
import numpy as np
import mne

req = json.load(open("/input/request.json"))
inp = req["input"]
sfreq = float(inp["sfreq"])
ch_names = inp["channel_names"]
data_uV = np.asarray(inp["raw_uV"], dtype=float)
data_V = data_uV * 1e-6
events = np.asarray(inp["events"], dtype=int)
event_id = inp["event_id"]
tmin = float(inp["tmin"]); tmax = float(inp["tmax"])
baseline = inp.get("baseline")
if baseline is not None:
    baseline = tuple(baseline)
reject_thr = inp.get("reject_peak_to_peak_uV")

info = mne.create_info(ch_names, sfreq, ch_types="eeg")
raw = mne.io.RawArray(data_V, info, verbose=False)

reject = None
if reject_thr is not None:
    reject = dict(eeg=float(reject_thr) * 1e-6)

epochs = mne.Epochs(raw, events, event_id=event_id, tmin=tmin, tmax=tmax,
                    baseline=baseline, reject=reject, preload=True,
                    verbose=False)
epochs.save("/workspace/check-epo.fif", overwrite=True, verbose=False)

n_total = len(events)
retained = [int(s) for s in epochs.events[:, 0]]
times_s = [float(t) for t in epochs.times]
n_dropped = int(n_total - len(epochs))
result = {
    "retained_event_samples": retained,
    "times_s": times_s,
    "n_dropped": n_dropped,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps({"n_retained": len(retained), "n_dropped": n_dropped,
                  "retained": retained, "n_times": len(times_s),
                  "t0": times_s[0], "t1": times_s[-1]}))
