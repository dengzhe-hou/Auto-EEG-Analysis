Saved /workspace/analysis.py and /workspace/result.json.

Result: channel_names = ["Pz", "Fz"] (requested order), samples_uV has shape 2 × 78, the crop [45, 123) of the original 400-sample recording, with full numeric precision and no other processing.
