import os

import json
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
raw = np.asarray(inp["raw_uV"], dtype=float)
names = list(inp["names"])
pick = list(inp["pick"])
start, stop = inp["samples"]

idx = [names.index(p) for p in pick]
data = raw[idx, start:stop]
samples_uV = data.tolist()
channel_names = pick

result = {"samples_uV": samples_uV, "channel_names": channel_names}
os.makedirs("/workspace", exist_ok=True)
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print("channels:", channel_names, "shape:", data.shape)
