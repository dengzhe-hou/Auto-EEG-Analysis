Saved /workspace/result.json and /workspace/analysis.py.

- channel_names: ["Pz", "Fz"] (requested order)
- samples_uV: 2 channels × 78 samples, from the half-open interval [45, 123) of the original recording, full numeric precision, no other processing.
