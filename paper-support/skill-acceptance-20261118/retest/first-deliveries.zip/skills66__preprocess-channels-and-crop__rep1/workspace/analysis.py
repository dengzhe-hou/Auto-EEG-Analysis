import json
import os
import numpy as np

req = json.load(open("/input/request.json"))["input"]
names = req["names"]
raw = np.asarray(req["raw_uV"], dtype=float)
pick = req["pick"]
start, stop = req["samples"]

idx = [names.index(p) for p in pick]
data = raw[idx, start:stop]

result = {
    "samples_uV": data.tolist(),
    "channel_names": list(pick),
}
os.makedirs("/workspace", exist_ok=True)
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(len(result["channel_names"]), len(result["samples_uV"][0]))
