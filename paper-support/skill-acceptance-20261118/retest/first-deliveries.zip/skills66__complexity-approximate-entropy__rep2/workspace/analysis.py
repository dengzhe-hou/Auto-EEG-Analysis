
import json
import numpy as np

def phi(x, m, r):
    x = np.asarray(x, dtype=float)
    n = len(x)
    N = n - m + 1
    emb = np.array([x[i:i+m] for i in range(N)])
    vals = []
    for i in range(N):
        d = np.max(np.abs(emb - emb[i]), axis=1)
        count = np.sum(d < r)  # includes self-match
        vals.append(count / N)
    return float(np.mean(np.log(np.array(vals))))

def approximate_entropy(x, m, r):
    p_m = phi(x, m, r)
    p_m1 = phi(x, m + 1, r)
    return p_m, p_m1, p_m - p_m1

if __name__ == "__main__":
    req = json.load(open("/input/request.json"))["input"]
    x = req["series"]
    m = int(req["m"])
    r = float(req["r"])
    p_m, p_m1, apen = approximate_entropy(x, m, r)
    result = {"phi_m": p_m, "phi_m_plus_1": p_m1, "approximate_entropy": apen}
    json.dump(result, open("/workspace/result.json", "w"), indent=2)
    print(json.dumps(result))
