Approximate entropy was computed with m=2 and Chebyshev strict distance r=0.65 (self-matches included, mean log neighbor fraction over all fitting windows). The program is saved at /workspace/analysis.py, and it was executed. The output is saved at /workspace/result.json:

{
  "phi_m": -2.090757288030014,
  "phi_m_plus_1": -2.7329804967013738,
  "approximate_entropy": 0.6422232086713597
}
