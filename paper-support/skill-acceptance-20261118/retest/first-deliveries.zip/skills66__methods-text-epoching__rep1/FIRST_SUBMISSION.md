Deliverables saved:
- /workspace/analysis.py (reusable program, executed)
- /workspace/methods.md (Methods paragraph plus field = value lines)
- /workspace/result.json

Result fields:
{"sampling_hz": 250, "reference": "not recorded", "retained_trials": 16, "seed": 74, "epoch_start_s": -0.12, "epoch_end_s": 0.64}

Notes: retained_trials = 21 total − 5 excluded = 16. The executed seed is 74 (the planned seed was 14, which is noted in the paragraph). The online reference is absent in the request and is recorded as "not recorded". Epoch times convert samples −30 and 160 at 250 Hz to −0.12 s and 0.64 s.
