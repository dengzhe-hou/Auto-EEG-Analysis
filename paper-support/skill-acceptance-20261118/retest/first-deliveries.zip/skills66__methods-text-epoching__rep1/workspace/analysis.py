
import json, os

req = json.load(open("/input/request.json"))["input"]
acq = req["acquisition"]
ex = req["execution"]

sfreq = acq["sampling_hz"]
reference = acq["reference"] if acq["reference"] is not None else "not recorded"
retained = ex["n_trials"] - ex["n_excluded"]
seed = ex["executed_seed"]
epoch_start_s = ex["epoch_start_sample"] / sfreq
epoch_end_s = ex["epoch_end_sample"] / sfreq

fields = {
    "sampling_hz": sfreq,
    "reference": reference,
    "retained_trials": retained,
    "seed": seed,
    "epoch_start_s": epoch_start_s,
    "epoch_end_s": epoch_end_s,
}

paragraph = (
    f"EEG was acquired at a sampling rate of {sfreq} Hz with an online reference of {reference}. "
    f"Epochs spanned {epoch_start_s} s to {epoch_end_s} s relative to event onset, with a bandpass of "
    f"{ex['band_hz'][0]}-{ex['band_hz'][1]} Hz applied. Of {ex['n_trials']} trials, {ex['n_excluded']} were excluded, "
    f"leaving {retained} retained trials. The executed random seed was {seed} (planned seed {ex['planned_seed']})."
)

lines = [paragraph, ""]
for k, v in fields.items():
    lines.append(f"{k} = {v}")
open("/workspace/methods.md", "w").write("\n".join(lines) + "\n")
json.dump(fields, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(fields))
