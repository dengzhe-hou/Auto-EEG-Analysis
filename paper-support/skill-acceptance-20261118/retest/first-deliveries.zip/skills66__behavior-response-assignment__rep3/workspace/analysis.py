
import json

req = json.load(open("/input/request.json"))["input"]
stim_ms = req["stimulus_ms"]; stim_blk = req["stimulus_blocks"]
resp_ms = req["response_ms"]; resp_blk = req["response_blocks"]
resp_ids = req["response_ids"]
lo, hi = 100, 350

used = set()
rt_ms = []
for s_t, s_b in zip(stim_ms, stim_blk):
    chosen = None
    for r_t, r_b, r_id in sorted(zip(resp_ms, resp_blk, resp_ids), key=lambda x: x[0]):
        if r_id in used or r_b != s_b:
            continue
        rt = r_t - s_t
        if lo <= rt < hi:
            chosen = (r_id, rt)
            break
    if chosen is None:
        rt_ms.append(None)
    else:
        used.add(chosen[0])
        rt_ms.append(chosen[1])

unused = sorted(r for r in resp_ids if r not in used)
result = {"rt_ms": rt_ms, "unused_response_ids": unused}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
