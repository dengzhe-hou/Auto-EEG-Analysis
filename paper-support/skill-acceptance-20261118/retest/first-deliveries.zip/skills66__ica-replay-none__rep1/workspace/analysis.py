
import json
import numpy as np

req = json.load(open("/input/request.json"))["input"]
X = np.array(req["channel_data_uV"], dtype=float)
W = np.array(req["unmixing"], dtype=float)
A = np.array(req["mixing"], dtype=float)
excl = [int(i) for i in req.get("approved_exclusions", [])]

Xc = X - X.mean(axis=1, keepdims=True)
S = W @ Xc
S_clean = S.copy()
for i in excl:
    S_clean[i, :] = 0.0
cleaned = A @ S_clean

result = {
    "cleaned_uV": cleaned.tolist(),
    "applied_exclusions": excl,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f)
print("shape", cleaned.shape, "exclusions", excl)
