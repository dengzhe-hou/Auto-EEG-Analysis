
import json
import numpy as np

req = json.load(open("/input/request.json"))["input"]
eeg_ids = req["eeg_trial_ids"]
eeg_uv = req["eeg_uV"]
beh_ids = req["behavior_trial_ids"]
rt = req["rt_ms"]

rt_map = dict(zip(beh_ids, rt))
eeg_set = set(eeg_ids)

trial_ids = []
x = []
y = []
for tid, uv in zip(eeg_ids, eeg_uv):
    if tid in rt_map:
        trial_ids.append(tid)
        x.append(float(uv))
        y.append(float(rt_map[tid]))

missing_on_eeg = sorted(t for t in beh_ids if t not in eeg_set)

X = np.column_stack([np.ones(len(x)), np.array(x)])
beta = np.linalg.lstsq(X, np.array(y), rcond=None)[0]
slope = float(beta[1])

result = {
    "trial_ids": trial_ids,
    "missing_on_eeg": missing_on_eeg,
    "slope_ms_per_uV": slope,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
