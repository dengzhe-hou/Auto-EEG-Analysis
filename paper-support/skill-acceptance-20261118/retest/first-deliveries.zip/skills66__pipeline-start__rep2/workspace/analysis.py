
import json
req = json.load(open("/input/request.json"))["input"]
deps = req["dependencies"]
status = req.get("status", {})
passed = {s for s, v in status.items() if v == "passed"}
failed = {s for s, v in status.items() if v == "failed"}
reused, runnable, blocked = [], [], []
for stage in sorted(deps):
    if stage in passed:
        reused.append(stage)
        continue
    if stage in failed:
        blocked.append(stage)
        continue
    unmet = [d for d in deps[stage] if d not in passed]
    if unmet:
        blocked.append(stage)
    else:
        runnable.append(stage)
result = {"reused": sorted(reused), "runnable": sorted(runnable), "blocked": sorted(blocked)}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
