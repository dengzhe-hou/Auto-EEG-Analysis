
import json, numpy as np, mne
req = json.load(open("/input/request.json"))
inp = req["input"]
X = np.array(inp["epochs_uV"], dtype=float)        # (n_ep, n_ch, n_t) in uV
labels = inp["labels"]
ch_names = inp["channel_names"]
sfreq = float(inp["sfreq"]); tmin = float(inp["tmin"])
# MNE expects Volts
data = X * 1e-6
info = mne.create_info(ch_names, sfreq, ch_types="eeg")
events = np.zeros((len(labels), 3), dtype=int)
events[:, 0] = np.arange(len(labels))
events[:, 2] = [1 if l == "A" else 2 for l in labels]
epochs = mne.EpochsArray(data, info, events=events, tmin=tmin, event_id={"A": 1, "B": 2}, verbose=False)
evA = epochs["A"].average()
evB = epochs["B"].average()
diff = mne.combine_evoked([evB, evA], weights=[1, -1])
diff.save("/workspace/check-ave.fif", overwrite=True)
n_A = int(np.sum(np.array(labels) == "A")); n_B = int(np.sum(np.array(labels) == "B"))
roi = ["Cz", "Pz"]
idx = [ch_names.index(c) for c in roi]
times = diff.times
mask = (times >= 0.1 - 1e-12) & (times <= 0.3 + 1e-12)
n_win = int(mask.sum())
roi_mean_uV = float(diff.data[idx][:, mask].mean() * 1e6)
result = {"roi_mean_uV": roi_mean_uV, "n_window_samples": n_win, "n_condition_trials": [n_A, n_B]}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
