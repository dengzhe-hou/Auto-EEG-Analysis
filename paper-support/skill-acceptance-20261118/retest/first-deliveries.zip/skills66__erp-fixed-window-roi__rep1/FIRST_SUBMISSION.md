{"roi_mean_uV": 7.500976459851711, "n_window_samples": 21, "n_condition_trials": [2, 3]}
