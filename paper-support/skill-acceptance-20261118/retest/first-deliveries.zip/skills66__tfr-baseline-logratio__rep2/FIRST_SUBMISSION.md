Completed the eeg-tfr test. The program is saved at /workspace/analysis.py and was executed; the result is saved at /workspace/result.json.

Method: MNE tfr_array_morlet, 10 Hz, 5 cycles, decim=1, zero_mean=True, power on V-scaled input converted back to uV^2. Log10(power / mean baseline power) per channel, baseline inclusive [-0.5, -0.125] s, averaged over epochs before the ratio. No other preprocessing.

Output: values is a 2×5 matrix (channels Fz, Cz by sample indices 144, 156, 180, 220, 270); times_s = [0.125, 0.21875, 0.40625, 0.71875, 1.109375]. All values are finite.

Fields in result.json: values, times_s (plus channels for reference).
