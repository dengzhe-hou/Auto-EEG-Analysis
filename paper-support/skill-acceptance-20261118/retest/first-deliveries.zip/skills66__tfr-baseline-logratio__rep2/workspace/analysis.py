
import json
import numpy as np
from mne.time_frequency import tfr_array_morlet

req = json.load(open("/input/request.json"))["input"]
X_uV = np.array(req["epochs_uV"], dtype=float)
sfreq = float(req["sfreq"])
tmin = float(req["tmin"])
sample_indices = [int(i) for i in req["sample_indices"]]
channels = req["channels"]

# Convert uV -> V for MNE, convert power back to uV^2 afterwards
X_V = X_uV * 1e-6
freqs = np.array([10.0])
n_cycles = np.array([5.0])

tfr = tfr_array_morlet(
    X_V, sfreq=sfreq, freqs=freqs, n_cycles=n_cycles,
    decim=1, output="power", zero_mean=True, n_jobs=1,
)
# shape: epochs, channels, freqs, times
power_uV2 = tfr[:, :, 0, :] * 1e12  # V^2 -> uV^2
times = tmin + np.arange(X_uV.shape[-1]) / sfreq

# Baseline: inclusive [-0.5, -0.125] s, mean over epochs first (per channel)
base_mask = (times >= -0.5 - 1e-12) & (times <= -0.125 + 1e-12)
mean_power_epochs = power_uV2.mean(axis=0)  # channels, times
baseline_mean = mean_power_epochs[:, base_mask].mean(axis=1)  # per channel

ratio = mean_power_epochs / baseline_mean[:, None]
log_ratio = np.log10(ratio)

values = log_ratio[:, sample_indices]
times_s = times[sample_indices]

result = {
    "values": values.tolist(),
    "times_s": times_s.tolist(),
    "channels": channels,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print("shape", values.shape)
print("times_s", times_s.tolist())
