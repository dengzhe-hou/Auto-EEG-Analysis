The AEA amplitude QC rule was evaluated on the two channels (Fz, Cz) of the synthetic input, on the original samples with no cleaning or annotation changes, and the sampling rate is 1000 Hz. The helper was given data converted from µV to V.

Results:
- constant_channels: []
- rapid_change_channels: []
- bad_channel_candidates: []

Supporting detail from amplitude_findings.json: no constant segments, no low-amplitude warnings, and no jump segments were found. Both Fz and Cz have constant_fraction 0.0 and jump_fraction 0.0, so neither channel reaches the 5% duration criterion.

Deliverables saved:
- /workspace/analysis.py (reusable program, executed)
- /workspace/qc_amplitude.py (amplitude helper, saved beside the program for replay)
- /workspace/result.json (required fields: constant_channels, rapid_change_channels, bad_channel_candidates)
- /workspace/amplitude_findings.json (full diagnostic findings and settings)
