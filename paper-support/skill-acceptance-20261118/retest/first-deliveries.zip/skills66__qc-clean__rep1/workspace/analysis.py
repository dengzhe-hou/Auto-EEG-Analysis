
import json, sys
from pathlib import Path
import numpy as np
import mne
sys.path.insert(0, str(Path(__file__).resolve().parent))
from qc_amplitude import amplitude_qc

req = json.load(open("/input/request.json"))
inp = req["input"]
sfreq = float(inp["sfreq"])
names = list(inp["channel_names"])
data_v = np.asarray(inp["signal_uV"], dtype=float) * 1e-6  # uV -> V

info = mne.create_info(names, sfreq, ch_types="eeg")
raw = mne.io.RawArray(data_v, info, verbose=False)

findings = amplitude_qc(
    raw,
    constant_min_duration=0.020,
    low_amplitude_window=0.100,
    low_amplitude_ptp=0.5e-6,
    jump_threshold=150e-6,
    jump_min_duration=0.005,
    bad_percent=5.0,
)

constant_channels = sorted({s["channel"] for s in findings["constant_segments"]})
rapid_change_channels = sorted({s["channel"] for s in findings["jump_segments"]})
bad_channel_candidates = sorted(findings["bad_channel_candidates"])

result = {
    "constant_channels": constant_channels,
    "rapid_change_channels": rapid_change_channels,
    "bad_channel_candidates": bad_channel_candidates,
}
Path("/workspace/result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
Path("/workspace/amplitude_findings.json").write_text(json.dumps(findings, indent=2), encoding="utf-8")
print(json.dumps(result, indent=2))
