Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-qc. Input: /input/request.json. Use its input field.
Evaluate the AEA amplitude QC rule on two EEG channels. Convert uV to V for the amplitude helper. Report sorted constant_channels and rapid_change_channels by their segment names, and bad_channel_candidates using the declared 5% duration criterion. Run QC on the original samples without applying cleaning or annotation changes.
Use full numeric precision in result.json. The required fields are constant_channels, rapid_change_channels, bad_channel_candidates. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
