import json
import os
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
G = np.array(inp["gain"], dtype=float)
C = np.array(inp["noise_cov"], dtype=float)
Y = np.array(inp["sensor_data"], dtype=float)
lambda2 = float(inp["lambda2"])
normalize_noise = bool(inp["normalize_noise"])

# Identity-source-prior minimum-norm inverse
K = G.T @ np.linalg.inv(G @ G.T + lambda2 * C)
source_estimates = K @ Y

if normalize_noise:
    noise_var = np.diag(K @ C @ K.T)
    source_estimates = source_estimates / np.sqrt(noise_var)[:, None]

result = {
    "source_estimates": source_estimates.tolist(),
    "normalized": normalize_noise,
}
os.makedirs("/workspace", exist_ok=True)
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
