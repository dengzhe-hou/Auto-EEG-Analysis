import json
from scipy import stats

with open("/input/request.json") as f:
    req = json.load(f)
x = req["input"]["contrasts"]
res = stats.ttest_1samp(x, popmean=0.0, alternative="two-sided")
out = {
    "t": float(res.statistic),
    "df": int(len(x) - 1),
    "p_two_sided": float(res.pvalue),
}
with open("/workspace/result.json", "w") as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))
