## Methods (EEG)

EEG was acquired at 250 Hz with an online reference of FCz. Data were bandpass filtered between 0.2 and 35 Hz. Of 20 trials, 3 were excluded, leaving 17 retained trials. Epochs spanned -0.1 s to 0.6 s relative to event onset. The executed random seed was 73 (planned seed 14).

sampling_hz = 250
reference = FCz
retained_trials = 17
seed = 73
epoch_start_s = -0.1
epoch_end_s = 0.6
