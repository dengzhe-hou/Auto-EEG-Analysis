
import json
req = json.load(open("/input/request.json"))["input"]
acq = req["acquisition"]; ex = req["execution"]
sampling_hz = acq["sampling_hz"]
reference = acq.get("reference", "not recorded")
retained_trials = ex["n_trials"] - ex["n_excluded"]
seed = ex["executed_seed"]
epoch_start_s = ex["epoch_start_sample"] / sampling_hz
epoch_end_s = ex["epoch_end_sample"] / sampling_hz
result = {
    "sampling_hz": sampling_hz,
    "reference": reference,
    "retained_trials": retained_trials,
    "seed": seed,
    "epoch_start_s": epoch_start_s,
    "epoch_end_s": epoch_end_s,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
lines = [
    "## Methods (EEG)",
    "",
    f"EEG was acquired at {sampling_hz} Hz with an online reference of {reference}. "
    f"Data were bandpass filtered between {ex['band_hz'][0]} and {ex['band_hz'][1]} Hz. "
    f"Of {ex['n_trials']} trials, {ex['n_excluded']} were excluded, leaving {retained_trials} retained trials. "
    f"Epochs spanned {epoch_start_s} s to {epoch_end_s} s relative to event onset. "
    f"The executed random seed was {seed} (planned seed {ex['planned_seed']}).",
    "",
    f"sampling_hz = {sampling_hz}",
    f"reference = {reference}",
    f"retained_trials = {retained_trials}",
    f"seed = {seed}",
    f"epoch_start_s = {epoch_start_s}",
    f"epoch_end_s = {epoch_end_s}",
]
open("/workspace/methods.md", "w").write("\n".join(lines) + "\n")
