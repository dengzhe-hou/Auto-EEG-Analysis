Saved /workspace/analysis.py and /workspace/result.json.

Two-sided independent Welch t-test (unequal variances), unit of analysis = one participant value per element.

{
  "statistic": 1.1299504949724615,
  "p_value": 0.2881594335471797,
  "n_per_group": [7, 5]
}
