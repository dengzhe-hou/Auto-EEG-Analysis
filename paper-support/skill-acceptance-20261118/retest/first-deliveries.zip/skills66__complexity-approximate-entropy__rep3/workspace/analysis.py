import os

import json, math
import numpy as np

req = json.load(open("/input/request.json"))["input"]
x = np.asarray(req["series"], dtype=float)
m = int(req["m"])
r = float(req["r"])
N = len(x)

def phi(mm):
    n_templates = N - mm + 1
    emb = np.array([x[i:i+mm] for i in range(n_templates)])
    logs = []
    for i in range(n_templates):
        d = np.max(np.abs(emb - emb[i]), axis=1)
        count = np.sum(d < r)  # includes self-match
        logs.append(math.log(count / n_templates))
    return float(np.mean(logs))

phi_m = phi(m)
phi_m1 = phi(m + 1)
apen = phi_m - phi_m1

result = {"phi_m": phi_m, "phi_m_plus_1": phi_m1, "approximate_entropy": apen}
os.makedirs("/workspace", exist_ok=True) if False else None
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result, indent=2))
