
import json, sys
import numpy as np
import mne
sys.path.insert(0, "/workspace")
from qc_amplitude import amplitude_qc

req = json.load(open("/input/request.json"))["input"]
signal_uv = np.array(req["signal_uV"], dtype=float)
ch_names = list(req["channel_names"])
sfreq = float(req["sfreq"])

data_v = signal_uv * 1e-6  # uV -> V for the amplitude helper
info = mne.create_info(ch_names, sfreq, ch_types="eeg")
raw = mne.io.RawArray(data_v, info, verbose=False)

findings = amplitude_qc(raw)

constant_channels = sorted({s["channel"] for s in findings["constant_segments"]})
rapid_change_channels = sorted({s["channel"] for s in findings["jump_segments"]})
bad_channel_candidates = sorted(findings["bad_channel_candidates"])

result = {
    "constant_channels": constant_channels,
    "rapid_change_channels": rapid_change_channels,
    "bad_channel_candidates": bad_channel_candidates,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
print(json.dumps(findings, indent=2, default=float))
