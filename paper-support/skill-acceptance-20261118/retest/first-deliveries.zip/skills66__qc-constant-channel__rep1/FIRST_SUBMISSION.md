{"constant_channels": ["Cz"], "rapid_change_channels": [], "bad_channel_candidates": ["Cz"]}
