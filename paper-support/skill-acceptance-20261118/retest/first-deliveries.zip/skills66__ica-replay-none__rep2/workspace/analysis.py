
import json
import numpy as np

req = json.load(open("/input/request.json"))["input"]
X = np.asarray(req["channel_data_uV"], dtype=float)
W = np.asarray(req["unmixing"], dtype=float)
A = np.asarray(req["mixing"], dtype=float)
excl = [int(i) for i in req["approved_exclusions"]]

# Centre channels (per channel mean over samples)
Xc = X - X.mean(axis=1, keepdims=True)

S = W @ Xc
S_clean = S.copy()
for i in excl:
    S_clean[i, :] = 0.0
cleaned = A @ S_clean

result = {
    "cleaned_uV": cleaned.tolist(),
    "applied_exclusions": excl,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print("channels:", X.shape, "exclusions:", excl)
print("max abs reconstruction error vs centred:", float(np.max(np.abs(cleaned - Xc))))
