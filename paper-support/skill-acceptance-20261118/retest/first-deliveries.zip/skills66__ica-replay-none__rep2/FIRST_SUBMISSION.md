{"cleaned_uV": "saved at /workspace/result.json (3 channels x 40 samples, full precision; equals the centred input since approved_exclusions is empty)", "applied_exclusions": []}
