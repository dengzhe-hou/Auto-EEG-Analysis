The analysis ran and wrote `/workspace/result.json` (and the reusable program `/workspace/analysis.py`).

Result (ITC at 10 Hz, 5 cycles, MNE tfr_array_morlet with zero_mean=True, decim=1, tmin=-1 s, sfreq=128 Hz; no extra preprocessing; input converted uV→V for MNE and ITC is dimensionless):

- Channels: ["Fz", "Cz"]
- times_s: [0.125, 0.21875, 0.40625, 0.71875, 1.109375]
- values:
  - Fz: [0.9928883764737766, 0.9957803175470118, 0.998854417308005, 0.9892431041269778, 0.9923586133835554]
  - Cz: [0.9995949711728874, 0.9990756043280258, 0.9992166389980843, 0.9980671154621756, 0.9958783502597773]

Caveat: with only 4 trials, ITC is strongly biased upward, so these high values (~0.99) should not be interpreted as strong phase locking without accounting for the small trial count.
