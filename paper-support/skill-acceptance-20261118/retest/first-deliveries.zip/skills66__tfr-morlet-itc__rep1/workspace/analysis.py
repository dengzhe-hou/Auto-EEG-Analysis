
import json
import numpy as np
import mne
from mne.time_frequency import tfr_array_morlet

req = json.load(open("/input/request.json"))
inp = req["input"]

E = np.array(inp["epochs_uV"], dtype=float) * 1e-6  # uV -> V for MNE
sfreq = float(inp["sfreq"])
tmin = float(inp["tmin"])
sample_indices = [int(i) for i in inp["sample_indices"]]

freqs = np.array([10.0])
n_cycles = np.array([5.0])

# complex coefficients: (trials, channels, freqs, times)
coef = tfr_array_morlet(E, sfreq=sfreq, freqs=freqs, n_cycles=n_cycles,
                        zero_mean=True, output="complex", decim=1, n_jobs=1)
coef = coef[:, :, 0, :]  # (trials, channels, times)

# ITC = |mean over trials of unit-phasor|
phase = coef / np.maximum(np.abs(coef), np.finfo(float).tiny)
itc = np.abs(np.mean(phase, axis=0))  # (channels, times)

times = tmin + np.arange(E.shape[-1]) / sfreq
times_s = [float(times[i]) for i in sample_indices]
values = [[float(itc[c, i]) for i in sample_indices] for c in range(itc.shape[0])]

result = {"values": values, "times_s": times_s}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
