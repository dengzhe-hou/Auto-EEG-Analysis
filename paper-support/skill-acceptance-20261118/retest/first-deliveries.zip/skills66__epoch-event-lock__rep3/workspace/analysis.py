
import json, numpy as np, mne
mne.set_log_level("WARNING")
req = json.load(open("/input/request.json"))["input"]
data = np.array(req["raw_uV"], dtype=float) * 1e-6  # uV -> V
info = mne.create_info(req["channel_names"], req["sfreq"], ch_types="eeg")
raw = mne.io.RawArray(data, info, verbose=False)
events = np.array(req["events"], dtype=int)
event_id = req["event_id"]
reject = None
if req.get("reject_peak_to_peak_uV") is not None:
    reject = {"eeg": req["reject_peak_to_peak_uV"] * 1e-6}
epochs = mne.Epochs(raw, events, event_id=event_id, tmin=req["tmin"], tmax=req["tmax"],
                    baseline=req["baseline"], reject=reject, preload=True, verbose=False)
epochs.save("/workspace/check-epo.fif", overwrite=True, verbose=False)
n_total = len(events)
retained = epochs.events[:, 0].astype(int).tolist()
n_dropped = n_total - len(epochs)
times = [float(t) for t in epochs.times]
result = {"retained_event_samples": retained, "times_s": times, "n_dropped": int(n_dropped)}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps({"retained_event_samples": retained, "n_dropped": n_dropped, "n_times": len(times)}))
