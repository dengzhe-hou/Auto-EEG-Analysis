Epoching completed. Artifacts are saved:
- /workspace/analysis.py (reusable MNE program, executed successfully)
- /workspace/check-epo.fif (epochs file)
- /workspace/result.json

Results:
- retained_event_samples: [35, 75, 114]
- n_dropped: 0
- times_s: 31 samples from -0.1 to 0.2 s (inclusive, 100 Hz)

No baseline correction or peak-to-peak rejection was applied, since baseline and reject_peak_to_peak_uV were null in the request.
