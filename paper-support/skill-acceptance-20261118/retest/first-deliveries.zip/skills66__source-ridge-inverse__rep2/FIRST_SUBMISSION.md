Saved /workspace/analysis.py and /workspace/result.json.

result.json contents:
- source_estimates: [[1.9928866346049747, 1.0087370683656256, 3.8431657568775455, 2.8639336910634516], [2.97564445544094, 1.9755671362518683, 0.29344797191766264, -0.5115313838588501]]
- normalized: false

Method: K = G.T @ inv(G @ G.T + 0.25 * C), source_estimates = K @ sensor_data, no per-source normalization because normalize_noise is false.
