
import json, math, os
import numpy as np

def count_matches(x, m, r, starts):
    # starts: positions shared for both lengths
    n = len(starts)
    cnt = 0
    for a in range(n):
        ia = starts[a]
        for b in range(a + 1, n):
            ib = starts[b]
            d = 0.0
            ok = True
            for k in range(m):
                dk = abs(x[ia + k] - x[ib + k])
                if dk >= r:
                    ok = False
                    break
            if ok:
                cnt += 1
    return cnt

def sample_entropy(series, m, r):
    x = np.asarray(series, dtype=float)
    N = len(x)
    # starting positions permitting length m+1: 0..N-m-1
    starts = list(range(N - m))
    counts_m = count_matches(x, m, r, starts)
    # length m+1 uses the same start positions; the extra element must exist
    counts_m1 = 0
    n = len(starts)
    for a in range(n):
        ia = starts[a]
        for b in range(a + 1, n):
            ib = starts[b]
            ok = True
            for k in range(m + 1):
                if abs(x[ia + k] - x[ib + k]) >= r:
                    ok = False
                    break
            if ok:
                counts_m1 += 1
    se = -math.log(counts_m1 / counts_m) if counts_m > 0 and counts_m1 > 0 else float("nan")
    return counts_m, counts_m1, se

if __name__ == "__main__":
    req = json.load(open("/input/request.json"))
    inp = req["input"]
    cm, cm1, se = sample_entropy(inp["series"], int(inp["m"]), float(inp["r"]))
    os.makedirs("/workspace", exist_ok=True)
    out = {"counts_m": cm, "counts_m_plus_1": cm1, "sample_entropy": se}
    json.dump(out, open("/workspace/result.json", "w"), indent=2)
    print(out)
