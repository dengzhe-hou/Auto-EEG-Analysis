# REPRO_RECEIPT

- Source artifact: request.json
- Executed seed: 33
- Planned seed (from request, not used for execution): 7
- Stage status: available
- Facts recorded: roi_mean_uV=-1.465, n_trials=45, status=available, seed=33
