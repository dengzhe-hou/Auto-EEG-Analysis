import json
req = json.load(open("/input/request.json"))
rec = req["input"]["executed_stage"]
src = req["input"]["source_file"]
planned_seed = req["input"]["planned_seed"]
result = {k: rec[k] for k in ["roi_mean_uV","n_trials","status","seed"]}
def fmt(v):
    if v is None: return "null"
    if isinstance(v, float): return f"{v:.3f}"
    return str(v)
html = "<!DOCTYPE html>\n<html><head><meta charset=\"utf-8\"><title>EEG Report</title></head>\n<body>\n<h1>EEG Report (eeg-report)</h1>\n"
for k in ["roi_mean_uV","n_trials","status","seed"]:
    html += f'<p>{k}: <span id="{k}">{fmt(result[k])}</span></p>\n'
html += "</body></html>\n"
receipt = f"""# REPRO_RECEIPT

- Source artifact: {src}
- Executed seed: {result['seed']}
- Planned seed (from request, not used for execution): {planned_seed}
- Stage status: {result['status']}
- Facts recorded: roi_mean_uV={result['roi_mean_uV']}, n_trials={result['n_trials']}, status={result['status']}, seed={result['seed']}
"""
open("/workspace/report.html","w").write(html)
open("/workspace/REPRO_RECEIPT.md","w").write(receipt)
json.dump(result, open("/workspace/result.json","w"), indent=2)
