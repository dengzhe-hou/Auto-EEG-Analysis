
import json, os

req = json.load(open("/input/request.json"))["input"]
acq = req["acquisition"]
ex = req["execution"]

sampling_hz = acq["sampling_hz"]
reference = acq.get("reference", "not recorded")
retained_trials = ex["n_trials"] - ex["n_excluded"]
seed = ex["executed_seed"]
epoch_start_s = ex["epoch_start_sample"] / sampling_hz
epoch_end_s = ex["epoch_end_sample"] / sampling_hz
band = ex["band_hz"]

result = {
    "sampling_hz": sampling_hz,
    "reference": reference,
    "retained_trials": retained_trials,
    "seed": seed,
    "epoch_start_s": epoch_start_s,
    "epoch_end_s": epoch_end_s,
}

os.makedirs("/workspace", exist_ok=True)
json.dump(result, open("/workspace/result.json", "w"), indent=2)

paragraph = (
    f"EEG was recorded at a sampling rate of {sampling_hz} Hz with {reference} as the "
    f"reference electrode. Data were band-pass filtered between {band[0]} and {band[1]} Hz. "
    f"Epochs spanned {epoch_start_s} s to {epoch_end_s} s relative to event onset. "
    f"Of {ex['n_trials']} trials, {ex['n_excluded']} were excluded, leaving {retained_trials} "
    f"retained trials. The executed random seed was {seed} (planned seed {ex['planned_seed']})."
)

lines = [
    "# Methods",
    "",
    paragraph,
    "",
    "## Machine-readable results",
] + [f"{k} = {v}" for k, v in result.items()]
open("/workspace/methods.md", "w").write("\n".join(lines) + "\n")

print(json.dumps(result, indent=2))
