# Methods

EEG was recorded at a sampling rate of 250 Hz with FCz as the reference electrode. Data were band-pass filtered between 0.2 and 35 Hz. Epochs spanned -0.1 s to 0.6 s relative to event onset. Of 20 trials, 3 were excluded, leaving 17 retained trials. The executed random seed was 73 (planned seed 14).

## Machine-readable results
sampling_hz = 250
reference = FCz
retained_trials = 17
seed = 73
epoch_start_s = -0.1
epoch_end_s = 0.6
