Saved /workspace/analysis.py and /workspace/result.json.

Test: one-way between-subject ANOVA (scipy f_oneway) on participant-level summaries, one value per participant, input order preserved.

{
  "statistic": 1.95547958489678,
  "p_value": 0.1782642854604834,
  "n_per_group": [7, 5, 5]
}

Group sizes are unequal (7, 5, 5); the scalar one-way ANOVA is valid for independent groups, so no fallback model was needed. No cluster inference was performed, as assigned.
