import json
import numpy as np
from scipy.stats import f_oneway

with open("/input/request.json") as fh:
    request = json.load(fh)

groups = [np.asarray(g, dtype=float) for g in request["input"]["groups"]]
statistic, p_value = f_oneway(*groups)

result = {
    "statistic": float(statistic),
    "p_value": float(p_value),
    "n_per_group": [int(g.size) for g in groups],
}

with open("/workspace/result.json", "w") as fh:
    json.dump(result, fh, indent=2)
print(json.dumps(result, indent=2))
