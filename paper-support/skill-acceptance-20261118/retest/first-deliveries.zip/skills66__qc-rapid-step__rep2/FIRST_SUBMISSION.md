{
  "constant_channels": [],
  "rapid_change_channels": ["Fz"],
  "bad_channel_candidates": [],
  "details": {
    "jump_segments": [{"channel": "Fz", "onset": 0.349, "duration": 0.006}],
    "per_channel": {
      "Fz": {"constant_fraction": 0.0, "jump_fraction": 0.006006006006006006},
      "Cz": {"constant_fraction": 0.0, "jump_fraction": 0.0}
    }
  },
  "artifacts": ["/workspace/analysis.py", "/workspace/result.json", "/workspace/analysis/qc_amplitude.py"]
}
