
import json, sys
import numpy as np
import mne
sys.path.insert(0, "/workspace/analysis")
from qc_amplitude import amplitude_qc

req = json.load(open("/input/request.json"))["input"]
sfreq = float(req["sfreq"])
names = list(req["channel_names"])
data_V = np.asarray(req["signal_uV"], dtype=float) * 1e-6
info = mne.create_info(names, sfreq, ch_types="eeg")
raw = mne.io.RawArray(data_V, info, verbose=False)

res = amplitude_qc(raw)

constant_channels = sorted({s["channel"] for s in res["constant_segments"]})
rapid_change_channels = sorted({s["channel"] for s in res["jump_segments"]})
bad_channel_candidates = sorted(res["bad_channel_candidates"])

out = {
    "constant_channels": constant_channels,
    "rapid_change_channels": rapid_change_channels,
    "bad_channel_candidates": bad_channel_candidates,
    "details": res,
}
json.dump(out, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(out, indent=2))
