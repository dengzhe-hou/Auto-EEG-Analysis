import os

import json

req = json.load(open("/input/request.json"))["input"]
recipe_version = "v0.1.0"
min_channels, min_sfreq, min_trials = 16, 200, 30
required = ["stimulus/related", "stimulus/unrelated"]

counts = req["marker_counts"]
missing = sorted([m for m in required if m not in counts])
insufficient = sorted([m for m in required if m in counts and counts[m] < min_trials])
eligible = (
    len(missing) == 0
    and len(insufficient) == 0
    and req["channel_count"] >= min_channels
    and req["sfreq"] >= min_sfreq
)

result = {
    "eligible": bool(eligible),
    "missing_markers": missing,
    "insufficient_present_markers": insufficient,
    "recipe_version": recipe_version,
}
os.makedirs("/workspace", exist_ok=True)
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
