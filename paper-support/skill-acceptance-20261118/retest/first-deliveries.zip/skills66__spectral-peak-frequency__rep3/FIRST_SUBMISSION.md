{
  "alpha_peak_hz": 11.0,
  "psd_uV2_per_hz": 0.8533333333333337
}

Files:
- /workspace/analysis.py (reusable program, executed)
- /workspace/result.json

Settings used: sfreq=128 Hz, n_per_seg=128, n_fft=128, n_overlap=64 (50%), periodic Hann window, per-segment mean removal, one-sided PSD in uV^2/Hz (DC and Nyquist not doubled), averaged over 5 segments. The alpha peak is the maximum bin in [8, 12] Hz.
