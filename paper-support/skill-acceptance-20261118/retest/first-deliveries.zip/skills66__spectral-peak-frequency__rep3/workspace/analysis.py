
import json
import numpy as np
from scipy.signal import get_window, csd

req = json.load(open("/input/request.json"))
inp = req["input"]
x = np.asarray(inp["data_uV"], dtype=float)
fs = float(inp["sfreq"])
nperseg = int(inp["n_per_seg"])
nfft = int(inp["n_fft"])
noverlap = int(inp["n_overlap"])

win = get_window("hann", nperseg, fftbins=True)  # periodic Hann
step = nperseg - noverlap
starts = np.arange(0, len(x) - nperseg + 1, step)
scale = fs * np.sum(win**2)
psd_acc = np.zeros(nfft // 2 + 1)
for s in starts:
    seg = x[s:s + nperseg]
    seg = seg - seg.mean()
    spec = np.fft.rfft(seg * win, n=nfft)
    p = (np.abs(spec) ** 2) / scale
    p[1:-1] *= 2.0  # one-sided, DC and Nyquist undoubled
    psd_acc += p
psd = psd_acc / len(starts)
freqs = np.fft.rfftfreq(nfft, d=1.0 / fs)

mask = (freqs >= 8) & (freqs <= 12)
idx = np.where(mask)[0][np.argmax(psd[mask])]
result = {
    "alpha_peak_hz": float(freqs[idx]),
    "psd_uV2_per_hz": float(psd[idx]),
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(result, len(starts))
