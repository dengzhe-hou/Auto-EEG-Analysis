The analysis was run with /workspace/analysis.py (MNE tfr_array_morlet, 10 Hz, 5 cycles, decim=1, zero_mean=True, power in uV^2 averaged over the 4 trials). The result is saved to /workspace/result.json with fields values (2 channels x 5 selected samples) and times_s.

values:
[[8.35012663, 8.15056445, 7.56982641, 8.24094313, 8.01437769],
 [30.77551883, 28.39032968, 28.81604973, 34.64908879, 31.36049459]]

times_s: [0.125, 0.21875, 0.40625, 0.71875, 1.109375]
