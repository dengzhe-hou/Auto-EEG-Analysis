Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-tfr. Input: /input/request.json. Use its input field.
Compute zero-mean Morlet at 10 Hz, 5 cycles, decim=1, from the supplied epoched signals with tmin=-1 s. No other preprocessing. Return values equal to average power in uV^2 for each channel at the given zero-based sample_indices, and times_s at those sample indices. Use MNE tfr_array_morlet with zero_mean=True and the stated cycles and decimation. Return the selected matrix as channel rows by sample columns. For power, preserve the supplied uV units through the calculation or convert V-squared back to uV-squared. No additional signal demeaning is specified.
Use full numeric precision in result.json. The required fields are values, times_s. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
