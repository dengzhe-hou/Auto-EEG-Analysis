
import json
import numpy as np
import mne
from mne.time_frequency import tfr_array_morlet

req = json.load(open("/input/request.json"))["input"]
epochs_uV = np.asarray(req["epochs_uV"], dtype=float)  # trials x channels x samples (uV)
sfreq = float(req["sfreq"])
tmin = float(req["tmin"])
sample_indices = [int(i) for i in req["sample_indices"]]
channels = req["channels"]

# convert uV -> V for MNE, power returned in V^2, convert back to uV^2 (x 1e12)
data_V = epochs_uV * 1e-6
freqs = np.array([10.0])
n_cycles = np.array([5.0])

power = tfr_array_morlet(
    data_V, sfreq=sfreq, freqs=freqs, n_cycles=n_cycles,
    output="power", decim=1, zero_mean=True, n_jobs=1,
)
# shape: trials x channels x freqs x times
power_uV2 = power[:, :, 0, :] * 1e12
avg = power_uV2.mean(axis=0)  # channels x times

times = tmin + np.arange(epochs_uV.shape[2]) / sfreq
values = avg[:, sample_indices]
times_s = [float(times[i]) for i in sample_indices]

result = {"values": values.tolist(), "times_s": times_s}
os.makedirs("/workspace", exist_ok=True) if False else None
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(values)
print(times_s)
