
import json, numpy as np, mne

req = json.load(open("/input/request.json"))["input"]
data = np.array(req["raw_uV"], dtype=float) * 1e-6  # uV -> V
ch_names = req["channel_names"]
sfreq = float(req["sfreq"])
events_list = req["events"]
event_id = req["event_id"]
tmin, tmax = float(req["tmin"]), float(req["tmax"])
baseline = tuple(req["baseline"])
rej_p2p = req.get("reject_peak_to_peak_uV")

info = mne.create_info(ch_names, sfreq, ch_types="eeg")
raw = mne.io.RawArray(data, info, verbose=False)
events = np.array(events_list, dtype=int)

reject = None
if rej_p2p is not None:
    reject = dict(eeg=float(rej_p2p) * 1e-6)

epochs = mne.Epochs(raw, events, event_id=event_id, tmin=tmin, tmax=tmax,
                    baseline=baseline, reject=reject, preload=True,
                    reject_by_annotation=False, verbose=False)
epochs.save("/workspace/check-epo.fif", overwrite=True, verbose=False)

n_total = len(events)
retained = epochs.events[:, 0].astype(int).tolist()
n_dropped = int(n_total - len(epochs))
times_s = [float(t) for t in epochs.times]

result = {
    "retained_event_samples": retained,
    "times_s": times_s,
    "n_dropped": n_dropped,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
