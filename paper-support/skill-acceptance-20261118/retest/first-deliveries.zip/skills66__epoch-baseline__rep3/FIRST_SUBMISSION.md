Epoching completed. The reusable program is saved at /workspace/analysis.py and was executed. The epochs are saved at /workspace/check-epo.fif, and the results are in /workspace/result.json.

Results:
- retained_event_samples: [35, 75, 114]
- times_s: [-0.1, -0.09, ..., 0.19, 0.2] (31 samples at 100 Hz, from -0.1 to 0.2 s inclusive)
- n_dropped: 0

Settings: EEG converted from uV to V; channels Fz and Cz; baseline [-0.1, 0] s applied; no peak-to-peak rejection (reject_peak_to_peak_uV was not supplied).
