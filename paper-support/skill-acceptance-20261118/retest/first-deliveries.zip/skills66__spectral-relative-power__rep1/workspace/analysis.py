
import json
import numpy as np

req = json.load(open("/input/request.json"))["input"]
x = np.asarray(req["data_uV"], dtype=float)
fs = float(req["sfreq"])
nperseg = int(req["n_per_seg"])
nfft = int(req["n_fft"])
noverlap = int(req["n_overlap"])

step = nperseg - noverlap
starts = range(0, len(x) - nperseg + 1, step)
win = 0.5 - 0.5 * np.cos(2 * np.pi * np.arange(nperseg) / nperseg)  # periodic Hann
scale = fs * np.sum(win ** 2)

segs = []
for s in starts:
    seg = x[s:s + nperseg]
    seg = seg - seg.mean()
    spec = np.fft.rfft(seg * win, n=nfft)
    segs.append(np.abs(spec) ** 2 / scale)
psd = np.mean(segs, axis=0)
psd[1:-1] *= 2.0  # one-sided: double non-DC, non-Nyquist bins
freqs = np.fft.rfftfreq(nfft, d=1.0 / fs)

def band_sum(lo, hi):
    m = (freqs >= lo) & (freqs <= hi)
    return float(np.sum(psd[m]))

beta_fraction = band_sum(15, 30) / band_sum(2, 40)
result = {"beta_fraction": float(beta_fraction)}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(result)
