Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-spectral. Input: /input/request.json. Use its input field.
Compute one-sided mean Welch PSD in uV^2/Hz using periodic Hann, segment demeaning and explicit n_fft, n_per_seg and overlap. Return beta_fraction from sum of PSD bins in [15,30] Hz divided by sum in [2,40] Hz.
Use full numeric precision in result.json. The required fields are beta_fraction. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
