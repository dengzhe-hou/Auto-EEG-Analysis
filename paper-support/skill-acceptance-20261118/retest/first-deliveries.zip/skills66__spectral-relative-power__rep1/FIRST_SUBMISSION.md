{"beta_fraction": 0.20984455958549228}
