import json

with open("/input/request.json") as f:
    labels = json.load(f)["input"]["labels"]

labeled = [x for x in labels if x != -1]
n_labeled = len(labeled)
coverage_pct = [100.0 * sum(1 for x in labeled if x == s) / n_labeled for s in (0, 1, 2)]

result = {"coverage_pct": coverage_pct, "n_labeled": n_labeled}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(result)
