import json
import numpy as np

req = json.load(open("/input/request.json"))
x = np.asarray(req["input"]["imaginary_cross_spectrum"], dtype=float)

# Ordinary wPLI: sum|Im|-weighted sign average
abs_x = np.abs(x)
wpli = np.sum(np.abs(x) * np.sign(x)) / np.sum(abs_x) if np.sum(abs_x) > 0 else float("nan")
wpli = float(np.sum(x) / np.sum(abs_x))

# Debiased wPLI^2 (Vinck et al. 2011): remove self-products in numerator and denominator
n = x.size
num_full = np.sum(x) ** 2
num_self = np.sum(x ** 2)
numerator = num_full - num_self
dfull = np.sum(abs_x) ** 2
dself = np.sum(abs_x ** 2)
denominator = dfull - dself
wpli2 = float(numerator / denominator)

result = {"wpli": float(wpli), "wpli2": float(wpli2)}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
