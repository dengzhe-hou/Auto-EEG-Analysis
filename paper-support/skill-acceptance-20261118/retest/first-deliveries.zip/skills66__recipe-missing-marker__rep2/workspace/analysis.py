
import json

RECIPE_PATH = "/workspace/aea/recipes/n400-semantic/RECIPE.md"
REQUEST_PATH = "/input/request.json"
RESULT_PATH = "/workspace/result.json"

def parse_header(path):
    txt = open(path).read()
    block = txt.split("---")[1]
    hdr = {}
    for line in block.splitlines():
        if ":" in line and not line.startswith(" "):
            k, v = line.split(":", 1)
            hdr[k.strip()] = v.strip()
    return hdr

def parse_list(s):
    s = s.strip().strip("[]")
    return [x.strip() for x in s.split(",") if x.strip()]

hdr = parse_header(RECIPE_PATH)
recipe_version = hdr["version"].strip('"')
min_channels = int(hdr["min_channels"])
min_sfreq = float(hdr["min_sfreq"])
min_trials = int(hdr["min_trials_per_condition"])
required = parse_list(hdr["required_markers"])

req = json.load(open(REQUEST_PATH))["input"]
channel_count = int(req["channel_count"])
sfreq = float(req["sfreq"])
counts = {k: int(v) for k, v in req["marker_counts"].items()}

missing = sorted([m for m in required if m not in counts])
insufficient = sorted([m for m in required if m in counts and counts[m] < min_trials])

eligible = (
    channel_count >= min_channels
    and sfreq >= min_sfreq
    and len(missing) == 0
    and len(insufficient) == 0
)

result = {
    "eligible": bool(eligible),
    "missing_markers": missing,
    "insufficient_present_markers": insufficient,
    "recipe_version": recipe_version,
}
json.dump(result, open(RESULT_PATH, "w"), indent=2)
print(json.dumps(result))
