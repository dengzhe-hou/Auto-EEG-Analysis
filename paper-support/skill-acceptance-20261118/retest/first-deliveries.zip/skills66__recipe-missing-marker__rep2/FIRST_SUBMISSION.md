{"eligible": false, "missing_markers": ["stimulus/unrelated"], "insufficient_present_markers": [], "recipe_version": "v0.1.0"}
