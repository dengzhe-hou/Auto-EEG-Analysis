{"relative_event_samples": [87, 301, 402], "bad_channels": ["Fz"], "sfreq": 128.0}
