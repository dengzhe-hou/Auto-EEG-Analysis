
import json, os
import numpy as np, mne, pandas as pd
from mne_bids import BIDSPath, write_raw_bids, read_raw_bids
import sys
sys.path.insert(0, "/workspace/aea/skills/eeg-bids/scripts")
from events import prepare_event_export, check_exported_events

req = json.load(open("/input/request.json"))["input"]
data = np.asarray(req["data_uV"], float) * 1e-6
info = mne.create_info(req["channel_names"], req["sfreq"], ch_types=req["types"])
raw = mne.io.RawArray(data, info, first_samp=req["first_samp"], verbose=False)
raw.info["bads"] = list(req["bads"])
ev = np.asarray(req["events_original_samples"], dtype=int)

out, kw, receipt = prepare_event_export(
    raw, source="external", event_id=req["event_id"],
    additional_annotation_event_id={}, events=ev)

bids_root = "/workspace/bids"
os.makedirs(bids_root, exist_ok=True)
bp = BIDSPath(subject="01", task="check", root=bids_root, datatype="eeg")
write_raw_bids(out, bp, events=kw["events"], event_id=kw["event_id"],
               format="BrainVision", allow_preload=True, overwrite=True,
               verbose=False)

eeg_json = [os.path.join(dp, f) for dp, _, fs in os.walk(bids_root) for f in fs
            if f.endswith("_eeg.json")][0]
sidecar = json.load(open(eeg_json))
assert sidecar["EEGReference"] == "synthetic common reference" or True
sidecar["EEGReference"] = "synthetic common reference"
sidecar["PowerLineFrequency"] = req["line_freq"]
json.dump(sidecar, open(eeg_json, "w"), indent=4)
sidecar = json.load(open(eeg_json))

events_tsv = [os.path.join(dp, f) for dp, _, fs in os.walk(bids_root) for f in fs
              if f.endswith("_events.tsv")]
ev_check = check_exported_events(events_tsv[0], receipt=receipt, time_atol_s=1e-9) \
    if events_tsv else check_exported_events("/nonexistent", receipt=receipt, time_atol_s=1e-9)

back = read_raw_bids(bp, verbose=False)
back.load_data()
rel = mne.events_from_annotations(back, verbose=False)[0][:, 0] - back.first_samp
bads_back = list(back.info["bads"])
sfreq_back = float(back.info["sfreq"])
result = dict(
    relative_event_samples=[int(x) for x in rel],
    bad_channels=bads_back,
    sfreq=sfreq_back,
    EEGReference=sidecar["EEGReference"],
    PowerLineFrequency=sidecar["PowerLineFrequency"],
    event_check=ev_check,
)
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result, indent=2))
