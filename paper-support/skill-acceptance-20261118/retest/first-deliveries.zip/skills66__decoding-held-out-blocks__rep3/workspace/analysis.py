
import json
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

req = json.load(open("/input/request.json"))
inp = req["input"]
X = np.array(inp["features"], dtype=float)   # trial x channel x time
y = np.array(inp["labels"])
g = np.array(inp["groups"])

n_trials, n_ch, n_times = X.shape
preds = np.zeros((n_trials, n_times), dtype=int)
groups = np.unique(g)

for t in range(n_times):
    for grp in groups:
        test = g == grp
        train = ~test
        clf = make_pipeline(
            StandardScaler(),
            LogisticRegression(C=1, solver="liblinear", random_state=42, max_iter=1000),
        )
        clf.fit(X[train, :, t], y[train])
        preds[test, t] = clf.predict(X[test, :, t])

accuracy = [float(np.mean(preds[:, t] == y)) for t in range(n_times)]
counts = np.bincount(y)
chance_accuracy = float(counts.max() / counts.sum())

result = {
    "predictions": preds.tolist(),
    "accuracy": accuracy,
    "chance_accuracy": chance_accuracy,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(preds.shape, accuracy, chance_accuracy)
