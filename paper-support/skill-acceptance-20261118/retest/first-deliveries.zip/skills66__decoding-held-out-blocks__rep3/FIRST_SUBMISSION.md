{"predictions": "saved in /workspace/result.json", "accuracy": [0.4166666666666667, 0.4583333333333333, 1.0, 1.0, 1.0], "chance_accuracy": 0.5}
