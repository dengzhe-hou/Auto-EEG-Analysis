
import json

req = json.load(open("/input/request.json"))["input"]

# Frozen header values from /workspace/aea/recipes/n400-semantic/RECIPE.md
MIN_CHANNELS = 16
MIN_SFREQ = 200
MIN_TRIALS = 30
REQUIRED_MARKERS = ["stimulus/related", "stimulus/unrelated"]
RECIPE_VERSION = "v0.1.0"

counts = req["marker_counts"]

missing_markers = sorted([m for m in REQUIRED_MARKERS if m not in counts])
insufficient_present_markers = sorted(
    [m for m in REQUIRED_MARKERS if m in counts and counts[m] < MIN_TRIALS]
)

channels_ok = req["channel_count"] >= MIN_CHANNELS
sfreq_ok = req["sfreq"] >= MIN_SFREQ
eligible = (
    channels_ok
    and sfreq_ok
    and len(missing_markers) == 0
    and len(insufficient_present_markers) == 0
)

result = {
    "eligible": eligible,
    "missing_markers": missing_markers,
    "insufficient_present_markers": insufficient_present_markers,
    "recipe_version": RECIPE_VERSION,
}

with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
