import json
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]

X = np.array(inp["channel_data_uV"], dtype=float)   # channels x samples (centered)
W = np.array(inp["unmixing"], dtype=float)          # components x channels
A = np.array(inp["mixing"], dtype=float)            # channels x components
exclude = [int(i) for i in inp["approved_exclusions"]]

# Sources from the fixed unmixing, zero approved components, reconstruct with fixed mixing.
S = W @ X
S_clean = S.copy()
S_clean[exclude, :] = 0.0
cleaned = A @ S_clean

result = {
    "cleaned_uV": cleaned.tolist(),
    "applied_exclusions": exclude,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
