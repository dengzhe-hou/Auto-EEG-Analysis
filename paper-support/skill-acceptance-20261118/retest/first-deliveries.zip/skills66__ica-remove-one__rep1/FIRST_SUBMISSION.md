{"cleaned_uV": "saved in /workspace/result.json (3 channels x 40 samples, full precision)", "applied_exclusions": [0]}
