import json, html

with open("/input/request.json") as f:
    req = json.load(f)
inp = req["input"]
es = inp["executed_stage"]
source_file = inp["source_file"]

def val(v):
    return "null" if v is None else str(v)

def rnd(v):
    return "null" if v is None else (f"{v:.3f}" if isinstance(v, float) else str(v))

result = {
    "roi_mean_uV": es.get("roi_mean_uV"),
    "n_trials": es.get("n_trials"),
    "status": es.get("status"),
    "seed": es.get("seed"),
}

rows = "".join(
    f'<tr><td>{k}</td><td id="{k}">{html.escape(rnd(result[k]))}</td></tr>\n'
    for k in ["roi_mean_uV", "n_trials", "status", "seed"]
)
page = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>EEG report</title></head>
<body>
<h1>EEG report</h1>
<table>
{rows}</table>
</body></html>
"""
with open("/workspace/report.html", "w") as f:
    f.write(page)

receipt = f"""# REPRO_RECEIPT

- Source artifact: {source_file}
- Executed seed: {val(result["seed"])}
- Planned seed (from input): {val(inp.get("planned_seed"))}
- Input file: /input/request.json
- Program: /workspace/analysis.py
"""
with open("/workspace/REPRO_RECEIPT.md", "w") as f:
    f.write(receipt)

with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
