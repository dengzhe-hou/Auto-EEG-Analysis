Deliverables are saved under /workspace:

- /workspace/analysis.py — reusable program, executed successfully.
- /workspace/result.json — {"roi_mean_uV": null, "n_trials": 44, "status": "unavailable", "seed": 32}
- /workspace/report.html — HTML elements with ids roi_mean_uV ("null"), n_trials ("44"), status ("unavailable"), seed ("32").
- /workspace/REPRO_RECEIPT.md — records source artifact "request.json" and executed seed 32 (planned seed 7 noted separately).

Note: roi_mean_uV is missing in the supplied executed-stage record, so it is reported as null and the status is unavailable. No values were fabricated.
