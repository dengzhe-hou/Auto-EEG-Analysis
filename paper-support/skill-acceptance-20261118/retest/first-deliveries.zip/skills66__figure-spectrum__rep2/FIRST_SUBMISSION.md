The EEG figure was rendered and saved, and the result was written to /workspace/result.json.

- Program saved at /workspace/analysis.py and executed successfully (return code 0).
- Figure saved at /workspace/fig.svg with figsize=(4,3), axes at [.2,.2,.6,.6], xlim=(-1,5), ylim=(-3,3), line gid="aea-data" (confirmed present in the SVG), and no tight crop.

result.json:
{
  "n_points": 5,
  "x_label": "Frequency (Hz)",
  "y_label": "Power (uV^2/Hz)"
}
