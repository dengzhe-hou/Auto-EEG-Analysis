
import json
import numpy as np

def load_input(path="/input/request.json"):
    with open(path) as f:
        return np.asarray(json.load(f)["input"]["imaginary_cross_spectrum"], dtype=float)

def wpli_and_debiased_wpli2(im):
    im = np.asarray(im, dtype=float)
    abs_im = np.abs(im)
    num = np.sum(im)
    den = np.sum(abs_im)
    wpli = float(np.abs(num) / den)
    num2 = num**2 - np.sum(im**2)
    den2 = den**2 - np.sum(abs_im**2)
    wpli2 = float(num2 / den2)
    return wpli, wpli2

if __name__ == "__main__":
    im = load_input()
    wpli, wpli2 = wpli_and_debiased_wpli2(im)
    result = {"wpli": wpli, "wpli2": wpli2}
    with open("/workspace/result.json", "w") as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result))
