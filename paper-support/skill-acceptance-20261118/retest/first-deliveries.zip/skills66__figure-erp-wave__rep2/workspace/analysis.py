
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

req = json.load(open("/input/request.json"))
d = req["input"]
x = d["x"]; y = d["y"]

fig = plt.figure(figsize=(4, 3))
ax = fig.add_axes([.2, .2, .6, .6])
line, = ax.plot(x, y, gid="aea-data")
ax.set_xlim(-1, 5)
ax.set_ylim(-3, 3)
ax.set_xlabel(d["x_label"])
ax.set_ylabel(d["y_label"])
fig.savefig("/workspace/fig.svg", format="svg")
plt.close(fig)

result = {"n_points": len(x), "x_label": d["x_label"], "y_label": d["y_label"]}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
