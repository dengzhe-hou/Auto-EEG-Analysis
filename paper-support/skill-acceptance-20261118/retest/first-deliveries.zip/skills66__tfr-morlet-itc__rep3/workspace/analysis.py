import os

import json
import numpy as np
import mne
from mne.time_frequency import tfr_array_morlet

req = json.load(open('/input/request.json'))
inp = req['input']
data = np.asarray(inp['epochs_uV'], dtype=float)  # trials x channels x times, uV
sfreq = float(inp['sfreq'])
tmin = float(inp['tmin'])
idx = np.asarray(inp['sample_indices'], dtype=int)

# ITC from single-trial complex Morlet coefficients (MNE, zero_mean=True)
# data in uV; ITC is unitless so units do not matter
freqs = np.array([10.0])
n_cycles = np.array([5.0])
coef = tfr_array_morlet(data, sfreq=sfreq, freqs=freqs, n_cycles=n_cycles,
                        output='complex', decim=1, zero_mean=True)
# coef shape: trials x channels x freqs x times
coef = coef[:, :, 0, :]
phase = coef / np.abs(coef)
itc = np.abs(np.mean(phase, axis=0))  # channels x times

n_times = data.shape[-1]
times = tmin + np.arange(n_times) / sfreq

values = itc[:, idx]
times_s = times[idx]

result = {"values": values.tolist(), "times_s": times_s.tolist()}
os.makedirs('/workspace', exist_ok=True)
json.dump(result, open('/workspace/result.json', 'w'), indent=2)
print(json.dumps(result))
