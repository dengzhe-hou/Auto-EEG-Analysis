import json
import numpy as np

req = json.load(open("/input/request.json"))
phase_a = np.asarray(req["input"]["phase_a"], dtype=float)
phase_b = np.asarray(req["input"]["phase_b"], dtype=float)

n_samples = int(phase_a.size)
phase_diff = phase_a - phase_b
plv = float(np.abs(np.mean(np.exp(1j * phase_diff))))

result = {"plv": plv, "n_samples": n_samples}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
