{"constant_channels": [], "rapid_change_channels": ["Fz"], "bad_channel_candidates": []}
