
import json, sys
import numpy as np
import mne
sys.path.insert(0, "/workspace")
from qc_amplitude import amplitude_qc

req = json.load(open("/input/request.json"))["input"]
data = np.asarray(req["signal_uV"], dtype=float) * 1e-6   # uV -> V
names = [str(n) for n in req["channel_names"]]
sfreq = float(req["sfreq"])
info = mne.create_info(names, sfreq, ch_types="eeg")
raw = mne.io.RawArray(data, info, verbose=False)

findings = amplitude_qc(raw)

constant_channels = sorted({s["channel"] for s in findings["constant_segments"]})
rapid_change_channels = sorted({s["channel"] for s in findings["jump_segments"]})
bad_channel_candidates = sorted(findings["bad_channel_candidates"])

result = {
    "constant_channels": constant_channels,
    "rapid_change_channels": rapid_change_channels,
    "bad_channel_candidates": bad_channel_candidates,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
json.dump(findings, open("/workspace/findings.json", "w"), indent=2)
print(json.dumps(result))
