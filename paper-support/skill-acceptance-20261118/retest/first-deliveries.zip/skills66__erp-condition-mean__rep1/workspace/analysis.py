
import json, os
import numpy as np
import mne

req = json.load(open("/input/request.json"))["input"]
data = np.array(req["epochs_uV"], dtype=float)  # (n_epochs, n_ch, n_times) in uV
labels = np.array(req["labels"])
ch_names = req["channel_names"]
sfreq = float(req["sfreq"])
tmin = float(req["tmin"])

data_V = data * 1e-6
info = mne.create_info(ch_names, sfreq, ch_types="eeg")

# build events with explicit condition codes
event_id = {"A": 1, "B": 2}
codes = np.array([event_id[l] for l in labels])
events = np.column_stack([np.arange(len(codes)), np.zeros(len(codes), int), codes])
epochs = mne.EpochsArray(data_V, info, events=events, event_id=event_id, tmin=tmin, verbose=False)

evk_A = epochs["A"].average()
n_A = int(np.sum(labels == "A"))
n_B = int(np.sum(labels == "B"))
evk_A.save("/workspace/check-ave.fif", overwrite=True, verbose=False)

times = evk_A.times
win = (times >= 0.1 - 1e-9) & (times <= 0.3 + 1e-9)
n_win = int(np.sum(win))
picks = [ch_names.index("Cz"), ch_names.index("Pz")]
roi_mean_uV = float(np.mean(evk_A.data[picks][:, win]) * 1e6)

result = {
    "roi_mean_uV": roi_mean_uV,
    "n_window_samples": n_win,
    "n_condition_trials": [n_A, n_B],
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
