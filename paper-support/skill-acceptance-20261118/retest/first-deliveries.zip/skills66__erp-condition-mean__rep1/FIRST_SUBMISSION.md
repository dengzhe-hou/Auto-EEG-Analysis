Results saved to /workspace/result.json. Program saved at /workspace/analysis.py. Evoked saved to /workspace/check-ave.fif.

{"roi_mean_uV": -0.0030618166539813107, "n_window_samples": 21, "n_condition_trials": [2, 3]}
