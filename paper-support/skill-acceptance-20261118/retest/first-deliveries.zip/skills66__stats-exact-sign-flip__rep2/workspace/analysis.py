import os, json, itertools
import numpy as np

req = json.load(open("/input/request.json"))
c = np.array(req["input"]["contrasts"], dtype=float)
observed = abs(c.mean())
signs = np.array(list(itertools.product([1, -1], repeat=len(c))))
stats = np.abs((signs * c).mean(axis=1))
n_patterns = len(stats)
p_exact = float(np.sum(stats >= observed - 1e-12) / n_patterns)
result = {
    "observed_abs_mean": float(observed),
    "n_patterns": int(n_patterns),
    "p_exact": p_exact,
}
os.makedirs("/workspace", exist_ok=True)
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
