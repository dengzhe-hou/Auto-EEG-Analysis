Deliverables are saved under /workspace:
- /workspace/analysis.py (reusable program, executed)
- /workspace/report.html (ids: roi_mean_uV, n_trials, status, seed; roi_mean_uV = "null")
- /workspace/REPRO_RECEIPT.md (source artifact: request.json; executed seed: 32; planned seed: 7; status: unavailable)
- /workspace/result.json:

{"roi_mean_uV": null, "n_trials": 44, "status": "unavailable", "seed": 32}

Note: roi_mean_uV is missing in the supplied executed-stage record, so it is null and the status is unavailable. No value was fabricated.
