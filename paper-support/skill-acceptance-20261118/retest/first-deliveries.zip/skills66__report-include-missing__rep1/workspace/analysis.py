import json, os
req = json.load(open("/input/request.json"))["input"]
es = req["executed_stage"]
src = req["source_file"]
def fmt(v):
    if v is None: return "null"
    if isinstance(v, float): return f"{v:.3f}"
    return str(v)
keys = ["roi_mean_uV","n_trials","status","seed"]
vals = {k: es.get(k) for k in keys}
os.makedirs("/workspace", exist_ok=True)
rows = "\n".join(f'<p>{k}: <span id="{k}">{fmt(vals[k])}</span></p>' for k in keys)
open("/workspace/report.html","w").write(f"<html><body><h1>EEG report</h1>\n{rows}\n</body></html>\n")
receipt = f"""# REPRO_RECEIPT

- Source artifact: {src}
- Executed seed: {es.get('seed')}
- Planned seed: {req.get('planned_seed')}
- Status: {es.get('status')}
"""
open("/workspace/REPRO_RECEIPT.md","w").write(receipt)
json.dump({k: vals[k] for k in keys}, open("/workspace/result.json","w"), indent=2)
