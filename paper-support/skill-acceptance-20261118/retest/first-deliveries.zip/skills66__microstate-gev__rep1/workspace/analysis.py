
import json

def compute_gev(label, gfp, corr, states=(0, 1, 2)):
    total_power = sum(g * g for g in gfp)
    gev_by_state = []
    for s in states:
        num = sum((g * g) * (c * c) for l, g, c in zip(label, gfp, corr) if l == s)
        gev_by_state.append(num / total_power)
    gev_total = sum(gev_by_state)
    return gev_by_state, gev_total

if __name__ == "__main__":
    with open("/input/request.json") as f:
        data = json.load(f)["input"]
    gev_by_state, gev_total = compute_gev(data["label"], data["gfp"], data["corr"])
    result = {"gev_by_state": gev_by_state, "gev_total": gev_total}
    with open("/workspace/result.json", "w") as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result, indent=2))
