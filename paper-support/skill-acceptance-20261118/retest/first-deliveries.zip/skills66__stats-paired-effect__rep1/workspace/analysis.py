
import json
import numpy as np
from scipy import stats

with open("/input/request.json") as f:
    req = json.load(f)
x = np.asarray(req["input"]["contrasts"], dtype=float)
n = x.size
mean_diff = float(np.mean(x))
sd = float(np.std(x, ddof=1))
dz = mean_diff / sd
se = sd / np.sqrt(n)
tcrit = float(stats.t.ppf(0.975, df=n - 1))
ci95 = [mean_diff - tcrit * se, mean_diff + tcrit * se]
result = {"dz": dz, "mean_difference": mean_diff, "ci95": ci95}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
