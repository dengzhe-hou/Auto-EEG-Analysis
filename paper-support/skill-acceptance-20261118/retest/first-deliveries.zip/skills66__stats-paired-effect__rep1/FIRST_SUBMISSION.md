Saved /workspace/analysis.py and executed it. Results written to /workspace/result.json:

{
  "dz": 1.3917848787223193,
  "mean_difference": 1.1666666666666665,
  "ci95": [0.2869749854331318, 2.046358347900201]
}

Computed on the 6 paired contrasts in /input/request.json: dz uses ddof=1 SD, mean_difference is the mean of contrasts, and ci95 is the two-sided 95% t interval on the mean (df=5).
