
import json
req = json.load(open("/input/request.json"))
ap = req["input"]["analysis_plan"]
er = req["input"]["execution_receipt"]
issues = sorted([k for k in ap if ap[k] != er.get(k)])
verdict = "pass" if not issues else "fail"
result = {"verdict": verdict, "issues": issues}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(result)
