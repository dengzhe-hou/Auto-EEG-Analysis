
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

with open("/input/request.json") as f:
    req = json.load(f)
data = req["input"]
x = data["x"]
y = data["y"]
x_label = data["x_label"]
y_label = data["y_label"]

fig = plt.figure(figsize=(4, 3))
ax = fig.add_axes([.2, .2, .6, .6])
line, = ax.plot(x, y, gid="aea-data")
ax.set_xlim(-1, 5)
ax.set_ylim(-3, 3)
ax.set_xlabel(x_label)
ax.set_ylabel(y_label)
fig.savefig("/workspace/fig.svg")
plt.close(fig)

result = {
    "n_points": len(x),
    "x_label": x_label,
    "y_label": y_label,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
