
import json
import numpy as np
from scipy import stats

req = json.load(open("/input/request.json"))
x = np.asarray(req["input"]["contrasts"], dtype=float)
t, p = stats.ttest_1samp(x, popmean=0.0, alternative="two-sided")
result = {
    "t": float(t),
    "df": int(len(x) - 1),
    "p_two_sided": float(p),
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
