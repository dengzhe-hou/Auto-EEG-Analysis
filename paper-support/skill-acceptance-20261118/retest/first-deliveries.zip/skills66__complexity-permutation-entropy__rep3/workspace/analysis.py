import json, math
from collections import Counter
from itertools import permutations

req = json.load(open("/input/request.json"))
x = req["input"]["series"]
order, delay = 3, 1
patterns = [tuple(p) for p in permutations(range(order))]
counts = Counter()
for i in range(len(x) - (order - 1) * delay):
    window = [x[i + j * delay] for j in range(order)]
    pat = tuple(sorted(range(order), key=lambda k: (window[k], k)))
    counts[pat] += 1
pattern_counts = [counts.get(p, 0) for p in patterns]
total = sum(pattern_counts)
probs = [c / total for c in pattern_counts if c > 0]
H = -sum(p * math.log(p) for p in probs)
npe = H / math.log(math.factorial(order))
result = {"pattern_counts": pattern_counts, "normalized_perm_entropy": npe}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(result)
