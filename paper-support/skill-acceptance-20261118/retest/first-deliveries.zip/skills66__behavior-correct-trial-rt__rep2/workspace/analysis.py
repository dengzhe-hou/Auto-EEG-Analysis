import json
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
cond = inp["condition"]
correct = inp["correct"]
rt = inp["rt_ms"]

accuracy = []
mean_rt_ms = []
retained_rt_trials = []
for c in ["A", "B"]:
    idx = [i for i, x in enumerate(cond) if x == c]
    acc = float(np.mean([bool(correct[i]) for i in idx])) if idx else float("nan")
    accuracy.append(acc)
    good = [rt[i] for i in idx if bool(correct[i])]
    retained_rt_trials.append(len(good))
    mean_rt_ms.append(float(np.mean(good)) if good else float("nan"))

result = {
    "accuracy": accuracy,
    "mean_rt_ms": mean_rt_ms,
    "retained_rt_trials": retained_rt_trials,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(result)
