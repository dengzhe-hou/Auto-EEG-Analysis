The analysis program was saved to /workspace/analysis.py and executed; results were saved to /workspace/result.json.

{
  "accuracy": [0.6666666666666666, 0.6666666666666666],
  "mean_rt_ms": [345.0, 430.0],
  "retained_rt_trials": [2, 2]
}

Accuracy is computed over all trials per condition (A, B). Mean RT is computed over correct trials only, per condition. Retained RT trial counts are the number of correct trials contributing to each mean.
