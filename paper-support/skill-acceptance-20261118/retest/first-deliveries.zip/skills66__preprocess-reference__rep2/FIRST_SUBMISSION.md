Saved /workspace/analysis.py (reusable program) and /workspace/result.json.

Method: average reference applied to the EEG channels only (Fz, Cz, Pz); the VEOG channel is left unchanged. No projection or filtering was applied. samples_uV is the full 4 x 400 array in original row order, and channel_names = ["Fz", "Cz", "Pz", "VEOG"].

Checks: the mean across the three EEG channels is ~5.9e-16 (zero within numerical precision), and VEOG matches the input exactly.
