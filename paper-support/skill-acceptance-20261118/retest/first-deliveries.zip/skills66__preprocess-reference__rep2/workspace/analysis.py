
import json
import numpy as np

req = json.load(open("/input/request.json"))["input"]
X = np.asarray(req["raw_uV"], dtype=float)
names = list(req["names"])
types = list(req["types"])

eeg_idx = [i for i, t in enumerate(types) if str(t).lower() == "eeg"]
out = X.copy()
# Average reference across EEG channels only; EOG kept unchanged.
avg = X[eeg_idx].mean(axis=0)
out[eeg_idx] = X[eeg_idx] - avg

result = {
    "samples_uV": out.tolist(),
    "channel_names": names,
}
json.dump(result, open("/workspace/result.json", "w"))
print("eeg_idx", eeg_idx, "shape", out.shape)
