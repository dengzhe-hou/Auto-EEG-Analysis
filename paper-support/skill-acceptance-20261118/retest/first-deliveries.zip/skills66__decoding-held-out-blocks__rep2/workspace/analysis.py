
import json
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression

req = json.load(open("/input/request.json"))
inp = req["input"]
X = np.array(inp["features"], dtype=float)
y = np.array(inp["labels"])
g = np.array(inp["groups"])
n_trials, n_ch, n_times = X.shape

preds = np.zeros((n_trials, n_times), dtype=int)
accuracy = []
for t in range(n_times):
    Xt = X[:, :, t]
    for grp in np.unique(g):
        test = g == grp
        train = ~test
        clf = make_pipeline(StandardScaler(),
                            LogisticRegression(C=1, solver="liblinear",
                                               random_state=42, max_iter=1000))
        clf.fit(Xt[train], y[train])
        preds[test, t] = clf.predict(Xt[test])
    accuracy.append(float(np.mean(preds[:, t] == y)))

chance = float(max(np.mean(y == c) for c in np.unique(y)))
result = {
    "predictions": preds.tolist(),
    "accuracy": accuracy,
    "chance_accuracy": chance,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(preds.shape, accuracy, chance)
