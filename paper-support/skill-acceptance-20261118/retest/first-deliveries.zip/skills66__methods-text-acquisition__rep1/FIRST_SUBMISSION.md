Deliverables saved:
- /workspace/analysis.py (reusable program, executed)
- /workspace/methods.md (Methods paragraph plus machine-readable field lines)
- /workspace/result.json (result fields)

result.json:
{
  "sampling_hz": 250,
  "reference": "FCz",
  "retained_trials": 17,
  "seed": 73,
  "epoch_start_s": -0.1,
  "epoch_end_s": 0.6
}

Methods paragraph (in methods.md):
EEG was recorded at a sampling rate of 250 Hz and referenced to FCz. Data were band-pass filtered between 0.2 and 35 Hz. Epochs spanned -0.1 s to 0.6 s relative to event onset. Of 20 trials, 17 were retained after exclusion of 3 trials. Analyses used the executed random seed 73 (planned seed 14); this deviation from the planned seed is reported here.

Machine-readable fields (in methods.md):
sampling_hz = 250
reference = FCz
retained_trials = 17
seed = 73
epoch_start_s = -0.1
epoch_end_s = 0.6
