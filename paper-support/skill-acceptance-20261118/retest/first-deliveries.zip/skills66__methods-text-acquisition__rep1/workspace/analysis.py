
import json

req = json.load(open("/input/request.json"))["input"]
acq = req["acquisition"]
ex = req["execution"]

sampling_hz = acq["sampling_hz"]
reference = acq.get("reference", "not recorded")
retained_trials = ex["n_trials"] - ex["n_excluded"]
seed = ex["executed_seed"]
epoch_start_s = ex["epoch_start_sample"] / sampling_hz
epoch_end_s = ex["epoch_end_sample"] / sampling_hz
band = ex["band_hz"]

result = {
    "sampling_hz": sampling_hz,
    "reference": reference,
    "retained_trials": retained_trials,
    "seed": seed,
    "epoch_start_s": epoch_start_s,
    "epoch_end_s": epoch_end_s,
}

json.dump(result, open("/workspace/result.json", "w"), indent=2)

paragraph = (
    f"EEG was recorded at a sampling rate of {sampling_hz} Hz and referenced to {reference}. "
    f"Data were band-pass filtered between {band[0]} and {band[1]} Hz. "
    f"Epochs spanned {epoch_start_s} s to {epoch_end_s} s relative to event onset. "
    f"Of {ex['n_trials']} trials, {retained_trials} were retained after exclusion of {ex['n_excluded']} trials. "
    f"Analyses used the executed random seed {seed} (planned seed {ex['planned_seed']}); "
    f"this deviation from the planned seed is reported here."
)

lines = [
    "# Methods",
    "",
    paragraph,
    "",
    "## Machine-readable fields",
    f"sampling_hz = {sampling_hz}",
    f"reference = {reference}",
    f"retained_trials = {retained_trials}",
    f"seed = {seed}",
    f"epoch_start_s = {epoch_start_s}",
    f"epoch_end_s = {epoch_end_s}",
]
open("/workspace/methods.md", "w").write("\n".join(lines) + "\n")
print(json.dumps(result, indent=2))
