import json
req = json.load(open("/input/request.json"))["input"]
acq = req["acquisition"]; ex = req["execution"]
sfreq = acq["sampling_hz"]
reference = acq["reference"] if acq["reference"] is not None else "not recorded"
retained = ex["n_trials"] - ex["n_excluded"]
seed = ex["executed_seed"]
epoch_start_s = ex["epoch_start_sample"] / sfreq
epoch_end_s = ex["epoch_end_sample"] / sfreq
result = {"sampling_hz": sfreq, "reference": reference, "retained_trials": retained,
          "seed": seed, "epoch_start_s": epoch_start_s, "epoch_end_s": epoch_end_s}
paragraph = (f"EEG was recorded at a sampling rate of {sfreq} Hz with reference: {reference}. "
    f"Data were band-pass filtered between {ex['band_hz'][0]} and {ex['band_hz'][1]} Hz. "
    f"Epochs spanned {epoch_start_s} s to {epoch_end_s} s relative to event onset. "
    f"Of {ex['n_trials']} trials, {ex['n_excluded']} were excluded, leaving {retained} retained trials. "
    f"The executed random seed was {seed} (planned seed {ex['planned_seed']}).")
md = "# Methods\n\n" + paragraph + "\n\n" + "\n".join(f"{k} = {v}" for k, v in result.items()) + "\n"
open("/workspace/methods.md", "w").write(md)
json.dump(result, open("/workspace/result.json", "w"), indent=2)
