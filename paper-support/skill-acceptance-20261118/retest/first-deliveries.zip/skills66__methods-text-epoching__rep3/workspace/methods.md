# Methods

EEG was recorded at a sampling rate of 250 Hz with reference: not recorded. Data were band-pass filtered between 0.2 and 35 Hz. Epochs spanned -0.12 s to 0.64 s relative to event onset. Of 21 trials, 5 were excluded, leaving 16 retained trials. The executed random seed was 74 (planned seed 14).

sampling_hz = 250
reference = not recorded
retained_trials = 16
seed = 74
epoch_start_s = -0.12
epoch_end_s = 0.64
