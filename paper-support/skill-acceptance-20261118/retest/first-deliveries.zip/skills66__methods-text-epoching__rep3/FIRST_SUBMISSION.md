Deliverables saved:
- /workspace/analysis.py (reusable program; executed successfully)
- /workspace/methods.md (Methods paragraph plus field = value lines)
- /workspace/result.json

Results:
{
  "sampling_hz": 250,
  "reference": "not recorded",
  "retained_trials": 16,
  "seed": 74,
  "epoch_start_s": -0.12,
  "epoch_end_s": 0.64
}

Notes: reference was null in the acquisition record, so it is reported as "not recorded". Retained trials = 21 − 5 = 16. The executed seed (74) is reported rather than the planned seed (14), which is also noted in the paragraph. Epoch bounds were converted from samples to seconds at 250 Hz.
