The paired two-sided t test on A minus B was run by the saved program /workspace/analysis.py, and the results were written to /workspace/result.json.

Result (full precision):
- statistic: 2.353835283221946
- p_value: 0.06524854507932806
- n_per_group: [6, 6]

Both groups have 6 paired subject values, so n_per_group is [6, 6]. No cluster inference was performed, as the task did not assign it.
