
import json
import numpy as np
from scipy import stats

with open("/input/request.json") as f:
    req = json.load(f)
A = np.asarray(req["input"]["A"], dtype=float)
B = np.asarray(req["input"]["B"], dtype=float)
res = stats.ttest_rel(A, B, alternative="two-sided")
result = {
    "statistic": float(res.statistic),
    "p_value": float(res.pvalue),
    "n_per_group": [int(len(A)), int(len(B))],
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
