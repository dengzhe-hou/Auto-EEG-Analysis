The n400-semantic preflight did not pass. The request has stimulus/related with 44 post-rejection trials, which meets the minimum of 30. It has no stimulus/unrelated marker, so that required condition is missing. Channel count (32 ≥ 16) and sampling rate (256 ≥ 200) pass, but eligibility requires all required markers.

Result, saved to /workspace/result.json (program at /workspace/analysis.py, executed):
{
  "eligible": false,
  "missing_markers": ["stimulus/unrelated"],
  "insufficient_present_markers": [],
  "recipe_version": "v0.1.0"
}
