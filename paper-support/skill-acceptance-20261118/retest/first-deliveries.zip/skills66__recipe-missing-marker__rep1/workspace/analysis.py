
import json, re

REQ_PATH = "/input/request.json"
RECIPE_PATH = "/workspace/aea/recipes/n400-semantic/RECIPE.md"

req = json.load(open(REQ_PATH))["input"]
txt = open(RECIPE_PATH).read()
header = txt.split("---")[1]

def field(name):
    m = re.search(rf"^{name}:\s*(.+)$", header, re.M)
    return m.group(1).strip().strip('"') if m else None

version = field("version")
min_channels = int(field("min_channels"))
min_sfreq = float(field("min_sfreq"))
min_trials = int(field("min_trials_per_condition"))
req_markers_raw = re.search(r"required_markers:\s*\[(.*?)\]", header).group(1)
required = [m.strip() for m in req_markers_raw.split(",")]

counts = req["marker_counts"]
channels = req["channel_count"]
sfreq = req["sfreq"]

missing = sorted(m for m in required if m not in counts)
insufficient = sorted(m for m in required if m in counts and counts[m] < min_trials)
eligible = (not missing) and (not insufficient) and channels >= min_channels and sfreq >= min_sfreq

result = {
    "eligible": bool(eligible),
    "missing_markers": missing,
    "insufficient_present_markers": insufficient,
    "recipe_version": version,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result, indent=2))
