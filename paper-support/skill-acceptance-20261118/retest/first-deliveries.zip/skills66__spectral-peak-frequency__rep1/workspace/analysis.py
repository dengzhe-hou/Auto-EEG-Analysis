
import json
import numpy as np
from scipy.signal import get_window

req = json.load(open('/input/request.json'))['input']
x = np.asarray(req['data_uV'], dtype=float)
fs = float(req['sfreq'])
nps = int(req['n_per_seg'])
nfft = int(req['n_fft'])
nov = int(req['n_overlap'])

step = nps - nov
win = get_window('hann', nps, fftbins=True)  # periodic Hann
scale = fs * np.sum(win**2)

segs = []
for start in range(0, len(x) - nps + 1, step):
    seg = x[start:start+nps]
    seg = seg - seg.mean()  # segment demeaning
    segs.append(seg)
segs = np.array(segs)

spec = np.fft.rfft(segs * win, n=nfft, axis=1)
pxx = (np.abs(spec)**2) / scale
pxx[:, 1:-1] *= 2.0  # one-sided, DC and Nyquist not doubled
psd = pxx.mean(axis=0)
freqs = np.fft.rfftfreq(nfft, d=1.0/fs)

mask = (freqs >= 8) & (freqs <= 12)
idx = np.where(mask)[0][np.argmax(psd[mask])]
result = {
    "alpha_peak_hz": float(freqs[idx]),
    "psd_uV2_per_hz": float(psd[idx]),
}
with open('/workspace/result.json', 'w') as f:
    json.dump(result, f, indent=2)
print(result)
