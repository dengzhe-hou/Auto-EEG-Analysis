{"roi_mean_uV": 4.999670508103991, "n_window_samples": 21, "n_condition_trials": [2, 3]}

Deliverables saved:
- /workspace/analysis.py (reusable program, executed)
- /workspace/check-ave.fif (single evoked: B minus A, Fz/Cz/Pz)
- /workspace/result.json (roi_mean_uV, n_window_samples, n_condition_trials)
