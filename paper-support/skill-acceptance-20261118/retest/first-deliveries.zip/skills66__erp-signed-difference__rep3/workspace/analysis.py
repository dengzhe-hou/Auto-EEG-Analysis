
import json
import numpy as np
import mne

req = json.load(open("/input/request.json"))
inp = req["input"]
data = np.array(inp["epochs_uV"], dtype=float)  # (n_epochs, n_ch, n_times)
labels = np.array(inp["labels"])
ch_names = inp["channel_names"]
sfreq = float(inp["sfreq"])
tmin = float(inp["tmin"])
n_times = data.shape[2]
times = tmin + np.arange(n_times) / sfreq

info = mne.create_info(ch_names, sfreq, ch_types="eeg")

# Condition averages (uV -> V for MNE)
ave_A = data[labels == "A"].mean(axis=0) * 1e-6
ave_B = data[labels == "B"].mean(axis=0) * 1e-6
diff_V = ave_B - ave_A
diff_uV = diff_V * 1e6

evoked = mne.EvokedArray(diff_V, info, tmin=tmin, comment="B-A")
evoked.save("/workspace/check-ave.fif", overwrite=True)

roi_idx = [ch_names.index("Cz"), ch_names.index("Pz")]
win = (times >= 0.1 - 1e-9) & (times <= 0.3 + 1e-9)
n_window_samples = int(win.sum())
roi_mean_uV = float(diff_uV[roi_idx][:, win].mean())
n_A = int((labels == "A").sum())
n_B = int((labels == "B").sum())

result = {
    "roi_mean_uV": roi_mean_uV,
    "n_window_samples": n_window_samples,
    "n_condition_trials": [n_A, n_B],
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
