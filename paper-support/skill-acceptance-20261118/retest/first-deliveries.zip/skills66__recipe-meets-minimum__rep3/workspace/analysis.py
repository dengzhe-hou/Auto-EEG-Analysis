import json, re
txt = open("/workspace/aea/recipes/n400-semantic/RECIPE.md").read()
hdr = txt.split("---")[1]
version = re.search(r'version:\s*"?([^"\n]+)"?', hdr).group(1).strip()
min_ch = int(re.search(r'min_channels:\s*(\d+)', hdr).group(1))
min_sf = float(re.search(r'min_sfreq:\s*([\d.]+)', hdr).group(1))
min_tr = int(re.search(r'min_trials_per_condition:\s*(\d+)', hdr).group(1))
req = [r.strip() for r in re.search(r'required_markers:\s*\[(.*?)\]', hdr).group(1).split(",")]
inp = json.load(open("/input/request.json"))["input"]
counts = inp["marker_counts"]
missing = sorted([m for m in req if m not in counts])
insuff = sorted([m for m in req if m in counts and counts[m] < min_tr])
eligible = (not missing) and (not insuff) and inp["channel_count"] >= min_ch and inp["sfreq"] >= min_sf
result = {"eligible": eligible, "missing_markers": missing, "insufficient_present_markers": insuff, "recipe_version": version}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(result)
