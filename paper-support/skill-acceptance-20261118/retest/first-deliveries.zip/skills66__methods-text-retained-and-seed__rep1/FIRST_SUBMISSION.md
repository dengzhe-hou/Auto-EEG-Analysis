Deliverables saved:
- /workspace/analysis.py (reusable program; executed)
- /workspace/methods.md (Methods paragraph + field = value lines)
- /workspace/result.json (full-precision result fields)

Result:
{
  "sampling_hz": 250,
  "reference": "not recorded",
  "retained_trials": 15,
  "seed": 75,
  "epoch_start_s": -0.14,
  "epoch_end_s": 0.68
}

Notes: reference was null in the acquisition record, so it is reported as "not recorded". Retained trials = 22 − 7 = 15. The executed seed (75) differs from the planned seed (14); both are noted in the Methods paragraph. Epoch times are sample offsets divided by 250 Hz.
