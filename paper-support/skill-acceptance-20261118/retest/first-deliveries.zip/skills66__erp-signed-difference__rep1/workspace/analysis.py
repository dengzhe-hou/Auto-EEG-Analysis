
import json
import numpy as np
import mne

req = json.load(open("/input/request.json"))
inp = req["input"]
epochs_data = np.array(inp["epochs_uV"], dtype=float)  # (n_epochs, n_ch, n_times), uV
labels = np.array(inp["labels"])
ch_names = inp["channel_names"]
sfreq = float(inp["sfreq"])
tmin = float(inp["tmin"])

# MNE works in V
data_V = epochs_data * 1e-6
info = mne.create_info(ch_names=ch_names, sfreq=sfreq, ch_types="eeg")
n_times = epochs_data.shape[2]
events = np.column_stack([np.arange(len(labels)), np.zeros(len(labels), int), np.arange(len(labels)) + 1])
event_id = {"A": 1, "B": 2}
ev_codes = np.array([event_id[l] for l in labels])
events[:, 2] = ev_codes
epochs = mne.EpochsArray(data_V, info, events=events, event_id=event_id, tmin=tmin, verbose=False)

evA = epochs["A"].average()
evB = epochs["B"].average()
diff = mne.combine_evoked([evB, evA], weights=[1, -1])
diff.comment = "B-A"
diff.save("/workspace/check-ave.fif", overwrite=True, verbose=False)

times = diff.times
win = (times >= 0.1 - 1e-12) & (times <= 0.3 + 1e-12)
n_window_samples = int(win.sum())
roi_idx = [ch_names.index("Cz"), ch_names.index("Pz")]
roi_mean_V = diff.data[roi_idx][:, win].mean()  # equal weight over channels and samples
roi_mean_uV = float(roi_mean_V * 1e6)

n_A = int(np.sum(labels == "A"))
n_B = int(np.sum(labels == "B"))

result = {
    "roi_mean_uV": roi_mean_uV,
    "n_window_samples": n_window_samples,
    "n_condition_trials": [n_A, n_B],
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
