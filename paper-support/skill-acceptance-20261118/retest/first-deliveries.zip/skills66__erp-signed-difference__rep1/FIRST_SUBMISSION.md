The eeg-erp analysis ran from /workspace/analysis.py and produced the requested outputs.

- Result file: /workspace/result.json
- Evoked file: /workspace/check-ave.fif (B−A difference wave, all three channels)

Results:
- roi_mean_uV: 4.999670508103991 (equal-weight mean over Cz and Pz, 0.1–0.3 s inclusive)
- n_window_samples: 21
- n_condition_trials: [2, 3] (condition A, condition B)

Notes: The processing applied no additional steps beyond the supplied clean epochs. MNE emitted a RuntimeWarning that nave was converted to an integer when saving the evoked file; this does not affect the reported ROI mean or sample count.
