
import json
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
X = np.array(inp["channel_data_uV"], dtype=float)
U = np.array(inp["unmixing"], dtype=float)
M = np.array(inp["mixing"], dtype=float)
exclusions = [int(i) for i in inp["approved_exclusions"]]

# Apply fixed unmixing to get component activations, zero approved components, reconstruct.
S = U @ X
S_clean = S.copy()
S_clean[exclusions, :] = 0.0
cleaned = M @ S_clean

result = {
    "cleaned_uV": cleaned.tolist(),
    "applied_exclusions": exclusions,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f)
