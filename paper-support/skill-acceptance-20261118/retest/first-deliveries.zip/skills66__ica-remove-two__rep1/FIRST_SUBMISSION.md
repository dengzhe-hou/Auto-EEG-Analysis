Saved /workspace/analysis.py and executed it; /workspace/result.json was written.

result.json fields:
- cleaned_uV: 3 channels × 40 samples, full numeric precision. Computed as M @ (S with rows 1 and 2 zeroed), where S = U @ X, using the supplied fixed unmixing/mixing pair (no refit).
- applied_exclusions: [1, 2]

Checks: U·M equals the identity to within 3.6e-17, so the saved pair is a valid inverse and the reconstruction is consistent. The output shape is (3, 40).
