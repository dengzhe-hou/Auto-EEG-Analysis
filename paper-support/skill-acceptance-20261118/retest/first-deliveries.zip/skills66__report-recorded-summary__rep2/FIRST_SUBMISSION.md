{"roi_mean_uV": -1.725, "n_trials": 43, "status": "available", "seed": 31}

Deliverables saved under /workspace: analysis.py (reusable program, executed), report.html (ids roi_mean_uV, n_trials, status, seed; continuous value rounded to 3 decimals in HTML only), REPRO_RECEIPT.md (cites source artifact request.json and executed seed 31), and result.json (full precision).
