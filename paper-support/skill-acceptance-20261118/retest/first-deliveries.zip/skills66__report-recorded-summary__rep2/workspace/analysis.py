
import json, os, html

REQ = "/input/request.json"
OUT = "/workspace"
req = json.load(open(REQ))
rec = req["input"]["executed_stage"]
source_file = req["input"]["source_file"]
planned_seed = req["input"]["planned_seed"]

keys = ["roi_mean_uV", "n_trials", "status", "seed"]
vals = {k: rec.get(k) for k in keys}

def disp(k, v, rnd=True):
    if v is None:
        return "null"
    if rnd and isinstance(v, float):
        return f"{v:.3f}"
    return str(v)

rows = "\n".join(
    f'<tr><td>{k}</td><td id="{k}">{disp(k, vals[k])}</td></tr>' for k in keys
)
report = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>eeg-report</title></head>
<body>
<h1>Executed-stage report</h1>
<table>
{rows}
</table>
</body></html>
"""
open(os.path.join(OUT, "report.html"), "w").write(report)

receipt = f"""# REPRO_RECEIPT

- Source artifact: {source_file}
- Executed seed: {vals['seed']}
- Planned seed (informational): {planned_seed}
- Status: {vals['status']}
- Skill: eeg-report
"""
open(os.path.join(OUT, "REPRO_RECEIPT.md"), "w").write(receipt)

result = {k: vals[k] for k in keys}
json.dump(result, open(os.path.join(OUT, "result.json"), "w"), indent=2)
print(json.dumps(result))
