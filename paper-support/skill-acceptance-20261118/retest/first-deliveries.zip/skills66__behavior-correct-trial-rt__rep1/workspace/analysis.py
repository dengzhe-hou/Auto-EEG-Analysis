import json
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
cond = inp["condition"]
corr = inp["correct"]
rt = inp["rt_ms"]

accuracy_all = float(np.mean([bool(c) for c in corr]))

conds = ["A", "B"]
accuracy = []
mean_rt_ms = []
retained_rt_trials = []
for c in conds:
    idx = [i for i, x in enumerate(cond) if x == c]
    accuracy.append(float(np.mean([bool(corr[i]) for i in idx])))
    kept = [rt[i] for i in idx if bool(corr[i])]
    retained_rt_trials.append(len(kept))
    mean_rt_ms.append(float(np.mean(kept)) if kept else float("nan"))

result = {
    "accuracy": accuracy,
    "mean_rt_ms": mean_rt_ms,
    "retained_rt_trials": retained_rt_trials,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
