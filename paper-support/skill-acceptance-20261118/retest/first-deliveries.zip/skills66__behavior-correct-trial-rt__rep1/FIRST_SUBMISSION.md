The analysis ran from /workspace/analysis.py and wrote /workspace/result.json.

Per-condition accuracy (A, B) = [0.6666666666666666, 0.6666666666666666]. Mean RT in ms over correct trials only (A, B) = [345.0, 430.0]. Retained correct-RT trials (A, B) = [2, 2].

Overall accuracy across all 6 trials is 4/6 ≈ 0.6667.

result.json:
{"accuracy": [0.6666666666666666, 0.6666666666666666], "mean_rt_ms": [345.0, 430.0], "retained_rt_trials": [2, 2]}
