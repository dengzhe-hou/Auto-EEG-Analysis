import json, numpy as np
req = json.load(open("/input/request.json"))
inp = req["input"]
G = np.array(inp["gain"], dtype=float)
C = np.array(inp["noise_cov"], dtype=float)
Y = np.array(inp["sensor_data"], dtype=float)
lam = float(inp["lambda2"])
normalize = bool(inp["normalize_noise"])
K = G.T @ np.linalg.inv(G @ G.T + lam * C)
if normalize:
    d = np.sqrt(np.diag(K @ C @ K.T))
    K = K / d[:, None]
S = K @ Y
result = {"source_estimates": S.tolist(), "normalized": normalize}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
