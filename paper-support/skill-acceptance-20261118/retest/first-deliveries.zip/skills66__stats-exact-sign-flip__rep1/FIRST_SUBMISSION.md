Executed /workspace/analysis.py, which wrote /workspace/result.json:

{
  "observed_abs_mean": 2.2,
  "n_patterns": 32,
  "p_exact": 0.1875
}

Contrasts used: [1, 6, 3, -1, 2]. All 2^5 = 32 sign-flip patterns were enumerated; the statistic is the absolute mean, two-sided, ties counted as extreme (>= observed with a 1e-12 tolerance), and no pseudocount was added.

Artifacts: /workspace/analysis.py, /workspace/result.json
