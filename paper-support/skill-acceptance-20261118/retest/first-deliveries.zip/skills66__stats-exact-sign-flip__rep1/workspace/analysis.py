
import json, itertools
import numpy as np

req = json.load(open("/input/request.json"))
x = np.asarray(req["input"]["contrasts"], dtype=float)
n = len(x)

observed = abs(np.mean(x))
stats = []
for signs in itertools.product([1, -1], repeat=n):
    s = np.asarray(signs, dtype=float)
    stats.append(abs(np.mean(s * x)))
stats = np.asarray(stats)

n_patterns = len(stats)
p_exact = float(np.sum(stats >= observed - 1e-12) / n_patterns)

result = {
    "observed_abs_mean": float(observed),
    "n_patterns": int(n_patterns),
    "p_exact": p_exact,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result, indent=2))
