Saved /workspace/analysis.py and /workspace/result.json.

Transition counts (source row, destination column; labels 0,1,2):
[[0, 2, 1], [1, 0, 2], [1, 0, 0]]

Row-normalized probabilities:
[[0.0, 0.6666666666666666, 0.3333333333333333], [0.3333333333333333, 0.0, 0.6666666666666666], [1.0, 0.0, 0.0]]

Adjacent repeats and any pair touching -1 were skipped, with no bridging across gaps.

Note: the requested skill is EEG microstate analysis; this bounded calculation of the transition matrix was done directly on the supplied label sequence. The AEA procedure's fitting, backfitting, and sanity-check phases did not apply, since no EEG data was supplied; the Markov-null and biomarker cautions in the skill are not evaluated here.
