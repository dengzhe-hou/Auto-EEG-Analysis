
import json
import os
import numpy as np

with open("/input/request.json") as f:
    labels = json.load(f)["input"]["labels"]

K = [0, 1, 2]
idx = {k: i for i, k in enumerate(K)}
counts = np.zeros((3, 3), dtype=np.int64)

for a, b in zip(labels[:-1], labels[1:]):
    if a == -1 or b == -1:
        continue
    if a == b:
        continue
    counts[idx[a], idx[b]] += 1

probs = np.zeros((3, 3), dtype=np.float64)
for i in range(3):
    s = counts[i].sum()
    if s > 0:
        probs[i] = counts[i] / s

result = {
    "counts": counts.tolist(),
    "probabilities": [[float(x) for x in row] for row in probs],
}
os.makedirs("/workspace", exist_ok=True) if False else None
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
