
import json, numpy as np, mne

req = json.load(open("/input/request.json"))
inp = req["input"]
raw_uV = np.array(inp["raw_uV"], dtype=float)
ch_names = inp["channel_names"]
sfreq = float(inp["sfreq"])
events_list = inp["events"]
event_id = inp["event_id"]
tmin = float(inp["tmin"]); tmax = float(inp["tmax"])
baseline = inp["baseline"]
rej_uV = inp.get("reject_peak_to_peak_uV")

# convert uV -> V
raw_V = raw_uV * 1e-6
info = mne.create_info(ch_names, sfreq, ch_types="eeg")
raw = mne.io.RawArray(raw_V, info, verbose=False)

events = np.array(events_list, dtype=int)

reject = None
if rej_uV is not None:
    reject = dict(eeg=float(rej_uV) * 1e-6)

epochs = mne.Epochs(raw, events, event_id=event_id, tmin=tmin, tmax=tmax,
                    baseline=tuple(baseline) if baseline is not None else None,
                    reject=reject, preload=True, verbose=False)

epochs.save("/workspace/check-epo.fif", overwrite=True, verbose=False)

retained_event_samples = [int(s) for s in epochs.events[:, 0]]
times_s = [float(t) for t in epochs.times]
n_dropped = int(len(events) - len(epochs))

result = {
    "retained_event_samples": retained_event_samples,
    "times_s": times_s,
    "n_dropped": n_dropped,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
