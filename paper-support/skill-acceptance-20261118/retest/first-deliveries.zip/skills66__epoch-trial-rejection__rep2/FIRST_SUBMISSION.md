Epoching completed. Event 75 was dropped by the 75 µV peak-to-peak rejection (EEG channels only); events 35 and 114 were retained.

Saved artifacts:
- /workspace/analysis.py (reusable program, executed)
- /workspace/check-epo.fif (epochs)
- /workspace/result.json

Result:
{
  "retained_event_samples": [35, 114],
  "times_s": [-0.1, -0.09, -0.08, -0.07, -0.06, -0.05, -0.04, -0.03, -0.02, -0.01, 0.0, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.1, 0.11, 0.12, 0.13, 0.14, 0.15, 0.16, 0.17, 0.18, 0.19, 0.2],
  "n_dropped": 1
}
