
import json

def decide(request):
    deps = request["input"]["dependencies"]
    status = request["input"]["status"]
    reused, runnable, blocked = [], [], []
    for stage in deps:
        s = status.get(stage, "pending")
        if s == "passed":
            reused.append(stage)
        elif s == "pending":
            prereqs_ok = all(status.get(d) == "passed" for d in deps[stage])
            (runnable if prereqs_ok else blocked).append(stage)
        else:
            blocked.append(stage)
    return {
        "reused": sorted(reused),
        "runnable": sorted(runnable),
        "blocked": sorted(blocked),
    }

if __name__ == "__main__":
    with open("/input/request.json") as f:
        req = json.load(f)
    result = decide(req)
    with open("/workspace/result.json", "w") as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result))
