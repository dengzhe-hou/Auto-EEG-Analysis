import os
import json
req = json.load(open('/input/request.json'))['input']
deps = req['dependencies']
status = req['status']
memo = {}
def resolve(s):
    if s in memo: return memo[s]
    st = status.get(s, 'pending')
    if st == 'passed':
        memo[s] = 'reused'
    elif st == 'failed':
        memo[s] = 'blocked'
    else:
        ds = [resolve(d) for d in deps.get(s, [])]
        memo[s] = 'runnable' if all(x == 'reused' for x in ds) else 'blocked'
    return memo[s]
out = {"reused": [], "runnable": [], "blocked": []}
for s in deps:
    r = resolve(s)
    key = {'reused': 'reused', 'runnable': 'runnable'}.get(r, 'blocked')
    out[key].append(s)
for k in out: out[k] = sorted(out[k])
os.makedirs('/workspace', exist_ok=True)
json.dump(out, open('/workspace/result.json', 'w'), indent=2)
print(json.dumps(out))
