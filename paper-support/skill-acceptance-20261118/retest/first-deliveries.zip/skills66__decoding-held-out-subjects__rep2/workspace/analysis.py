
import json, numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

req = json.load(open("/input/request.json"))["input"]
X = np.array(req["features"], dtype=float)
y = np.array(req["labels"])
groups = np.array(req["groups"])
n_trials, n_ch, n_times = X.shape

preds = np.zeros((n_trials, n_times), dtype=int)
for t in range(n_times):
    Xt = X[:, :, t]
    for g in np.unique(groups):
        test = groups == g
        train = ~test
        clf = make_pipeline(StandardScaler(),
                            LogisticRegression(C=1, solver="liblinear",
                                               random_state=42, max_iter=1000))
        clf.fit(Xt[train], y[train])
        preds[test, t] = clf.predict(Xt[test])

accuracy = [float(np.mean(preds[:, t] == y)) for t in range(n_times)]
classes, counts = np.unique(y, return_counts=True)
chance_accuracy = float(np.max(counts) / counts.sum())

result = {"predictions": preds.tolist(),
          "accuracy": accuracy,
          "chance_accuracy": chance_accuracy}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(preds.shape, accuracy, chance_accuracy)
