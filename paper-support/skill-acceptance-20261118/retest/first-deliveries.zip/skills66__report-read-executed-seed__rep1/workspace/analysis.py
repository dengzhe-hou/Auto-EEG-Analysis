import json, html
req = json.load(open("/input/request.json"))
inp = req["input"]
es = inp["executed_stage"]
src = inp["source_file"]
seed = es["seed"]

result = {
    "roi_mean_uV": es["roi_mean_uV"],
    "n_trials": es["n_trials"],
    "status": es["status"],
    "seed": seed,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)

def fmt(v):
    if v is None:
        return "null"
    if isinstance(v, float):
        return f"{v:.3f}"
    return str(v)

rows = "".join(
    f'<li>{k}: <span id="{k}">{html.escape(fmt(result[k]))}</span></li>'
    for k in ["roi_mean_uV", "n_trials", "status", "seed"]
)
open("/workspace/report.html", "w").write(
    "<html><body><h1>EEG report</h1><ul>" + rows + "</ul></body></html>"
)

receipt = f"""# REPRO_RECEIPT

- Source artifact: {src}
- Executed seed: {seed}
- Planned seed (not used for execution): {inp.get("planned_seed")}
- Stage status: {es["status"]}
"""
open("/workspace/REPRO_RECEIPT.md", "w").write(receipt)
print(json.dumps(result))
