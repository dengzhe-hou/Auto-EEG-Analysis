{"roi_mean_uV": -1.465, "n_trials": 45, "status": "available", "seed": 33}
