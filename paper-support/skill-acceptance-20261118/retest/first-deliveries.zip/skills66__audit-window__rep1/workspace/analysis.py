
import json

with open("/input/request.json") as f:
    data = json.load(f)["input"]

plan = data["analysis_plan"]
receipt = data["execution_receipt"]

fields = ["roi", "window_ms", "contrast", "observation_unit", "unit", "correction"]
issues = sorted([k for k in fields if plan.get(k) != receipt.get(k)])
verdict = "pass" if not issues else "fail"

result = {"verdict": verdict, "issues": issues}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
