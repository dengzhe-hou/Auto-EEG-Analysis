{
  "verdict": "fail",
  "issues": ["window_ms"]
}
