
import json, numpy as np
import mne
from mne.time_frequency import tfr_array_morlet

req = json.load(open("/input/request.json"))
inp = req["input"]
E = np.array(inp["epochs_uV"], dtype=float)  # uV
sfreq = float(inp["sfreq"])
tmin = float(inp["tmin"])
sidx = [int(i) for i in inp["sample_indices"]]
channels = inp["channels"]

freq = np.array([10.0])
n_cycles = np.array([5.0])

# tfr_array_morlet expects V-scaled data in MNE conventions only if we keep units; we keep uV, power in uV^2
# Complex coefficients: (n_epochs, n_channels, n_freqs, n_times)
tfr = tfr_array_morlet(E, sfreq=sfreq, freqs=freq, n_cycles=n_cycles,
                       output="power", zero_mean=True, decim=1, n_jobs=1)
# tfr shape: (n_epochs, n_channels, n_freqs, n_times)
power = tfr.mean(axis=0)[:, 0, :]  # (n_channels, n_times), mean over trials
times = tmin + np.arange(E.shape[-1]) / sfreq

# baseline: inclusive [-0.5, -0.125] s
bmask = (times >= -0.5 - 1e-12) & (times <= -0.125 + 1e-12)
base = power[:, bmask].mean(axis=1, keepdims=True)
logr = np.log10(power / base)

values = logr[:, sidx]
times_s = times[sidx]

result = {"values": values.tolist(), "times_s": times_s.tolist()}
import os
os.makedirs("/workspace", exist_ok=True)
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(values.shape, times_s)
