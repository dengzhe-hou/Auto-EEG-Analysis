Saved /workspace/analysis.py and /workspace/result.json.

result.json: values (2 channels Fz, Cz × 5 samples), times_s = [0.125, 0.21875, 0.40625, 0.71875, 1.109375].

Method: MNE tfr_array_morlet, 10 Hz, 5 cycles, zero_mean=True, decim=1, output power in uV^2, trial-mean power, baseline mean over inclusive [-0.5, -0.125] s per channel, values = log10(power / baseline mean).
