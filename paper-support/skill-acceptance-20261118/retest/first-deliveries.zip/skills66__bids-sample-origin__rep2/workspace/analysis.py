
import json, os, shutil, sys
sys.path.insert(0, "/workspace/aea/skills/eeg-bids/scripts")
import numpy as np
import mne
from mne_bids import BIDSPath, write_raw_bids, read_raw_bids
from events import prepare_event_export, check_exported_events

req = json.load(open("/input/request.json"))["input"]
data = np.asarray(req["data_uV"], float) * 1e-6  # uV -> V
info = mne.create_info(req["channel_names"], req["sfreq"], req["types"])
raw = mne.io.RawArray(data, info, first_samp=req["first_samp"], verbose=False)
raw.info["bads"] = list(req["bads"])
raw.set_channel_types({c: t for c, t in zip(req["channel_names"], req["types"])})

events = np.array([[s, 0, c] for s, _, c in req["events_original_samples"]], dtype=int)
out_raw, kwargs, receipt = prepare_event_export(
    raw, source="external", event_id=req["event_id"],
    additional_annotation_event_id={}, events=events)

bids_root = "/workspace/bids"
if os.path.exists(bids_root):
    shutil.rmtree(bids_root)
os.makedirs(bids_root)
bp = BIDSPath(subject="01", task="check", root=bids_root, datatype="eeg", suffix="eeg")
write_raw_bids(out_raw, bp, format="BrainVision", allow_preload=True, overwrite=True,
               montage=None, verbose=False, **kwargs,)
# ensure reference and line freq in sidecar
import glob
sidecar = glob.glob(os.path.join(bids_root, "sub-01", "eeg", "*_eeg.json"))[0]
side = json.load(open(sidecar))
side["EEGReference"] = "synthetic common reference"
side["PowerLineFrequency"] = req["line_freq"]
json.dump(side, open(sidecar, "w"), indent=4)

side_rb = json.load(open(sidecar))
events_tsv = glob.glob(os.path.join(bids_root, "sub-01", "eeg", "*_events.tsv"))[0]
ev_check = check_exported_events(events_tsv, receipt=receipt, time_atol_s=1e-6)

rb = read_raw_bids(bp, verbose=False)
rb_events = mne.events_from_annotations(rb, verbose=False)[0]
relative_event_samples = [int(x) for x in rb_events[:, 0]]
result = dict(
    relative_event_samples=relative_event_samples,
    bad_channels=list(rb.info["bads"]),
    sfreq=float(rb.info["sfreq"]),
    EEGReference=side_rb["EEGReference"],
    PowerLineFrequency=side_rb["PowerLineFrequency"],
    events_check=ev_check,
)
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
