{"relative_event_samples": [117, 270, 439], "bad_channels": [], "sfreq": 128.0}

Details:
- EEG-BIDS BrainVision export written under /workspace/bids (sub-01, task-check, no session/run), with files sub-01_task-check_eeg.{vhdr,vmrk,eeg,json} and events.tsv.
- Sidecar read-back: EEGReference = "synthetic common reference", PowerLineFrequency = 50.
- Events check passed: 3 external events, identities and onsets verified against the events.tsv read-back.
- Saved program: /workspace/analysis.py (executed). Results: /workspace/result.json.
