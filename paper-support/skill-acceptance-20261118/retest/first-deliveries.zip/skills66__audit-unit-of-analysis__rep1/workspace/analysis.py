
import json

req = json.load(open("/input/request.json"))
inp = req["input"]
plan = inp["analysis_plan"]
receipt = inp["execution_receipt"]

fields = ["roi", "window_ms", "contrast", "observation_unit", "unit", "correction"]
issues = sorted([f for f in fields if plan.get(f) != receipt.get(f)])
verdict = "pass" if not issues else "fail"

result = {"verdict": verdict, "issues": issues}
with open("/workspace/result.json", "w") as fh:
    json.dump(result, fh, indent=2)
print(json.dumps(result))
