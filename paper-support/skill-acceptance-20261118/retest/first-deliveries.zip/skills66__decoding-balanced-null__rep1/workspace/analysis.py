import os

import json
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LogisticRegression

req = json.load(open("/input/request.json"))["input"]
X = np.asarray(req["features"], dtype=float)   # trial x channel x time
y = np.asarray(req["labels"])
groups = np.asarray(req["groups"])
n_trials, n_ch, n_times = X.shape

preds = np.zeros((n_trials, n_times), dtype=float)
accuracy = np.zeros(n_times, dtype=float)

for t in range(n_times):
    Xt = X[:, :, t]
    for g in np.unique(groups):
        test = groups == g
        train = ~test
        clf = make_pipeline(StandardScaler(),
                            LogisticRegression(C=1, solver="liblinear",
                                               random_state=42, max_iter=1000))
        clf.fit(Xt[train], y[train])
        preds[test, t] = clf.predict(Xt[test])
    accuracy[t] = np.mean(preds[:, t] == y)

classes, counts = np.unique(y, return_counts=True)
chance_accuracy = float(counts.max() / counts.sum())

result = {
    "predictions": preds.tolist(),
    "accuracy": accuracy.tolist(),
    "chance_accuracy": chance_accuracy,
}
os.makedirs("/workspace", exist_ok=True)
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(preds.shape, accuracy, chance_accuracy)
