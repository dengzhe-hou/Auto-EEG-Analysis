Decoding complete. The program is saved at /workspace/analysis.py and was executed; results are in /workspace/result.json.

- Design: time-resolved decoding, leave-one-group-out over 4 groups, StandardScaler + LogisticRegression(C=1, solver="liblinear", random_state=42, max_iter=1000) fitted inside each fold at each time sample.
- predictions: 24 trials × 5 time points, in original row order (trial by time).
- accuracy per time point: [0.41666667, 0.41666667, 0.5, 0.75, 0.5]
- chance_accuracy: 0.5

result.json contains the fields predictions, accuracy, and chance_accuracy, with full numeric precision.
