
import json

req = json.load(open("/input/request.json"))["input"]
text = open("/workspace/aea/recipes/n400-semantic/RECIPE.md").read()
header = text.split("---")[1]

meta = {}
for line in header.splitlines():
    if ":" in line and not line.startswith(" "):
        k, v = line.split(":", 1)
        meta[k.strip()] = v.strip().strip('"')

required = ["stimulus/related", "stimulus/unrelated"]
min_channels = int(meta["min_channels"])
min_sfreq = float(meta["min_sfreq"])
min_trials = int(meta["min_trials_per_condition"])

counts = req["marker_counts"]
missing = sorted(m for m in required if m not in counts)
insufficient = sorted(m for m in required if m in counts and counts[m] < min_trials)

eligible = (
    not missing and not insufficient
    and req["channel_count"] >= min_channels
    and req["sfreq"] >= min_sfreq
)

result = {
    "eligible": bool(eligible),
    "missing_markers": missing,
    "insufficient_present_markers": insufficient,
    "recipe_version": meta["version"],
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
