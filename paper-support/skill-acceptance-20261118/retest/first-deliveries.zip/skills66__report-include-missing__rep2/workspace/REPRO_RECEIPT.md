# REPRO_RECEIPT

- Source artifact: request.json
- Executed seed: 32
- Planned seed (not used for execution): 7
- Stage status: unavailable
- roi_mean_uV: null
- n_trials: 44
- Program: /workspace/analysis.py
