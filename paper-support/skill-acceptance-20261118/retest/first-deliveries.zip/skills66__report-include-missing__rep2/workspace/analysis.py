
import json, html

req = json.load(open("/input/request.json"))
inp = req["input"]
stage = inp["executed_stage"]
source_file = inp["source_file"]
planned_seed = inp["planned_seed"]

def fmt(v):
    return "null" if v is None else str(v)

def rnd(v):
    if v is None:
        return None
    return round(float(v), 3)

roi_mean_uV = stage["roi_mean_uV"]
n_trials = stage["n_trials"]
status = stage["status"]
seed = stage["seed"]

result = {
    "roi_mean_uV": roi_mean_uV,
    "n_trials": n_trials,
    "status": status,
    "seed": seed,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)

html_doc = f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>EEG report</title></head>
<body>
<h1>EEG stage report</h1>
<p>roi_mean_uV: <span id="roi_mean_uV">{fmt(rnd(roi_mean_uV))}</span></p>
<p>n_trials: <span id="n_trials">{fmt(n_trials)}</span></p>
<p>status: <span id="status">{fmt(status)}</span></p>
<p>seed: <span id="seed">{fmt(seed)}</span></p>
</body>
</html>
"""
open("/workspace/report.html", "w").write(html_doc)

receipt = f"""# REPRO_RECEIPT

- Source artifact: {source_file}
- Executed seed: {seed}
- Planned seed (not used for execution): {planned_seed}
- Stage status: {status}
- roi_mean_uV: {fmt(roi_mean_uV)}
- n_trials: {fmt(n_trials)}
- Program: /workspace/analysis.py
"""
open("/workspace/REPRO_RECEIPT.md", "w").write(receipt)
print(json.dumps(result))
