{"roi_mean_uV": null, "n_trials": 44, "status": "unavailable", "seed": 32}
