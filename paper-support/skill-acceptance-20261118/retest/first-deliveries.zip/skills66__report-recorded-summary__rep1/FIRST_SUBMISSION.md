{"roi_mean_uV": -1.725, "n_trials": 43, "status": "available", "seed": 31}
