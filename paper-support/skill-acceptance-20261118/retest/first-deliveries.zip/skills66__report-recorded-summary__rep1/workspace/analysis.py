
import json, html

req = json.load(open("/input/request.json"))
rec = req["input"]["executed_stage"]
source_file = req["input"]["source_file"]

facts = {
    "roi_mean_uV": rec["roi_mean_uV"],
    "n_trials": rec["n_trials"],
    "status": rec["status"],
    "seed": rec["seed"],
}

def disp(v, rnd=True):
    if v is None:
        return "null"
    if rnd and isinstance(v, float):
        return f"{v:.3f}"
    return str(v)

html_doc = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>EEG report</title></head>
<body>
<h1>EEG executed-stage report</h1>
<p>roi_mean_uV: <span id="roi_mean_uV">{disp(facts["roi_mean_uV"])}</span></p>
<p>n_trials: <span id="n_trials">{disp(facts["n_trials"])}</span></p>
<p>status: <span id="status">{disp(facts["status"])}</span></p>
<p>seed: <span id="seed">{disp(facts["seed"])}</span></p>
</body></html>
"""
open("/workspace/report.html", "w").write(html_doc)

receipt = f"""# REPRO_RECEIPT

- Source artifact: {source_file}
- Executed seed: {facts["seed"]}
- Planned seed (not used for results): {req["input"].get("planned_seed")}
- roi_mean_uV: {facts["roi_mean_uV"]}
- n_trials: {facts["n_trials"]}
- status: {facts["status"]}
"""
open("/workspace/REPRO_RECEIPT.md", "w").write(receipt)

json.dump(facts, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(facts))
