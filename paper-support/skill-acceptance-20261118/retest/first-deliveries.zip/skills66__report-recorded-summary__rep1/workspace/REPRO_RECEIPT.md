# REPRO_RECEIPT

- Source artifact: request.json
- Executed seed: 31
- Planned seed (not used for results): 7
- roi_mean_uV: -1.725
- n_trials: 43
- status: available
