
import json
import numpy as np

def compute_gev(label, gfp, corr):
    label = np.asarray(label)
    gfp = np.asarray(gfp, dtype=float)
    corr = np.asarray(corr, dtype=float)
    denom = np.sum(gfp ** 2)
    gev_by_state = []
    for s in [0, 1, 2]:
        mask = label == s
        num = np.sum((gfp[mask] ** 2) * (corr[mask] ** 2))
        gev_by_state.append(float(num / denom))
    gev_total = float(sum(gev_by_state))
    return gev_by_state, gev_total

if __name__ == "__main__":
    with open("/input/request.json") as f:
        req = json.load(f)["input"]
    gev_by_state, gev_total = compute_gev(req["label"], req["gfp"], req["corr"])
    result = {"gev_by_state": gev_by_state, "gev_total": gev_total}
    with open("/workspace/result.json", "w") as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result, indent=2))
