import json
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
channels = inp["channels"]
data = np.array(inp["signal"], dtype=float)

corr = np.corrcoef(data)
idx = {c: i for i, c in enumerate(channels)}
pairs = [("Fz", "Cz"), ("Fz", "Pz"), ("Cz", "Pz")]
edges = [float(corr[idx[a], idx[b]]) for a, b in pairs]

result = {"edges": edges}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
