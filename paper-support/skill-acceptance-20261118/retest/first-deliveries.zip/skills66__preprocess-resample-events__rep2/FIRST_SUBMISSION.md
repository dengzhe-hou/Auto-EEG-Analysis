Completed the bounded 50 Hz resample (MNE resample, method fft, npad=0, boxcar window, events resampled jointly).

Saved artifacts:
- /workspace/analysis.py (reusable program, executed)
- /workspace/result.json

Verified result.json fields:
- new_sfreq: 50.0
- relative_event_samples: [20, 94, 106]
- samples_uV: 3 channels × 200 samples, full precision

No further preprocessing was applied.
