
import json
import numpy as np
import mne

req = json.load(open("/input/request.json"))["input"]
raw_uV = np.asarray(req["raw_uV"], dtype=float)
names = list(req["names"])
types = list(req["types"])
sfreq = float(req["sfreq"])
new_sfreq = float(req["new_sfreq"])
events = np.asarray(req["events"], dtype=int)

# uV -> V for MNE
data_V = raw_uV * 1e-6
info = mne.create_info(ch_names=names, sfreq=sfreq, ch_types=["eeg"] * len(names))
raw = mne.io.RawArray(data_V, info, verbose=False)

# jointly resample signal and events
raw_rs, events_rs = raw.copy().resample(
    new_sfreq, npad=0, window="boxcar", method="fft",
    events=events, verbose=False)

out_uV = raw_rs.get_data() * 1e6
result = {
    "new_sfreq": float(raw_rs.info["sfreq"]),
    "relative_event_samples": [int(x) for x in events_rs[:, 0]],
    "samples_uV": out_uV.tolist(),
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print("new_sfreq", result["new_sfreq"])
print("n_samples", out_uV.shape)
print("events_rs", events_rs.tolist())
