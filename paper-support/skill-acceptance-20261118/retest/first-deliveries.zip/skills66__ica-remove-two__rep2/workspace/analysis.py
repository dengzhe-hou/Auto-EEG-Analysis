
import json
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
X = np.asarray(inp["channel_data_uV"], dtype=float)
W = np.asarray(inp["unmixing"], dtype=float)
A = np.asarray(inp["mixing"], dtype=float)
excl = [int(i) for i in inp["approved_exclusions"]]

# Centered data, fixed decomposition: sources = W X, zero approved components, reconstruct with A
S = W @ X
S_clean = S.copy()
S_clean[excl, :] = 0.0
X_clean = A @ S_clean

result = {
    "cleaned_uV": X_clean.tolist(),
    "applied_exclusions": excl,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print("shape", X_clean.shape, "exclusions", excl)
