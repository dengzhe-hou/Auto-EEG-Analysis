
import json
import numpy as np
from scipy import stats

req = json.load(open("/input/request.json"))
groups = [np.asarray(g, dtype=float) for g in req["input"]["groups"]]

statistic, p_value = stats.f_oneway(*groups)
result = {
    "statistic": float(statistic),
    "p_value": float(p_value),
    "n_per_group": [int(len(g)) for g in groups],
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
