Saved /workspace/analysis.py (one-way between-subject ANOVA via scipy.stats.f_oneway on the three participant-value groups from /input/request.json, input order preserved) and executed it. Saved /workspace/result.json:

{
  "statistic": 1.95547958489678,
  "p_value": 0.1782642854604834,
  "n_per_group": [7, 5, 5]
}
