import json
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
pa = np.asarray(inp["phase_a"], dtype=float)
pb = np.asarray(inp["phase_b"], dtype=float)
if pa.shape != pb.shape:
    raise ValueError("phase arrays must have equal length")
n = int(pa.size)
plv = float(np.abs(np.mean(np.exp(1j * (pa - pb)))))
result = {"plv": plv, "n_samples": n}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
