Temporal PLV was computed as |mean(exp(i(phase_a − phase_b)))| over the 7 samples. The reusable program is saved at /workspace/analysis.py and was executed; it wrote /workspace/result.json:

{
  "plv": 0.8274789078532228,
  "n_samples": 7
}
