{"relative_event_samples": [117, 270, 439], "bad_channels": [], "sfreq": 128.0}
