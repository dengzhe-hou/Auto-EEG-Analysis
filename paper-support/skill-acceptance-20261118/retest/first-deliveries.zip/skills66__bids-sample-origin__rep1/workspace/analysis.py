
import json, os, numpy as np, mne, pandas as pd
from mne_bids import BIDSPath, write_raw_bids, read_raw_bids

req = json.load(open("/input/request.json"))["input"]
data = np.asarray(req["data_uV"], dtype=float) * 1e-6
info = mne.create_info(req["channel_names"], req["sfreq"], req["types"])
raw = mne.io.RawArray(data, info, first_samp=req["first_samp"], verbose=False)
raw.info["bads"] = list(req["bads"])
raw.info["line_freq"] = float(req["line_freq"])
raw.set_eeg_reference(ref_channels="average", projection=False, verbose=False)
events = np.asarray(req["events_original_samples"], dtype=int)
event_id = dict(req["event_id"])

# Annotations from external events; onset shifted by first_time per MNE convention
desc = {v: k for k, v in event_id.items()}
onsets = (events[:, 0] - raw.first_samp) / raw.info["sfreq"]
annots = mne.Annotations(onset=onsets, duration=np.zeros(len(onsets)),
                         description=[desc[c] for c in events[:, 2]])
raw.set_annotations(annots)

bids_root = "/workspace/bids"
os.makedirs(bids_root, exist_ok=True)
bp = BIDSPath(subject="01", task="check", datatype="eeg", root=bids_root)
write_raw_bids(raw, bp, format="BrainVision", allow_preload=True, overwrite=True,
               events=None, event_id=event_id, verbose=False)
# enforce reference label in sidecar
for dp, _, fs in os.walk(bids_root):
    for f in fs:
        if f.endswith("_eeg.json"):
            p = os.path.join(dp, f); s = json.load(open(p)); s["EEGReference"] = "synthetic common reference"; json.dump(s, open(p, "w"), indent=2)


# Read back
raw2 = read_raw_bids(bp, verbose=False)
ev2, eid2 = mne.events_from_annotations(raw2, event_id=event_id, verbose=False)
rel = (ev2[:, 0] - raw2.first_samp).astype(int).tolist()
bad_channels = list(raw2.info["bads"])
sfreq = float(raw2.info["sfreq"])

sidecar_path = [os.path.join(dp, f) for dp, _, fs in os.walk(bids_root) for f in fs if f.endswith("_eeg.json")][0]
side = json.load(open(sidecar_path))
print("EEGReference", side.get("EEGReference"), "PowerLineFrequency", side.get("PowerLineFrequency"))

result = {"relative_event_samples": rel, "bad_channels": bad_channels, "sfreq": sfreq}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(result)
