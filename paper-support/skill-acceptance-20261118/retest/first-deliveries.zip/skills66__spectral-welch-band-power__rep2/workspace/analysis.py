
import json
import numpy as np

req = json.load(open("/input/request.json"))["input"]
x = np.asarray(req["data_uV"], dtype=float)
fs = float(req["sfreq"])
nperseg = int(req["n_per_seg"])
nfft = int(req["n_fft"])
noverlap = int(req["n_overlap"])

step = nperseg - noverlap
starts = range(0, len(x) - nperseg + 1, step)

# periodic Hann window
n = np.arange(nperseg)
win = 0.5 - 0.5 * np.cos(2 * np.pi * n / nperseg)
scale = fs * np.sum(win ** 2)

segs = []
for s in starts:
    seg = x[s:s + nperseg]
    seg = seg - seg.mean()
    segs.append(seg)
segs = np.array(segs)

X = np.fft.rfft(segs * win, n=nfft, axis=1)
Pxx = (np.abs(X) ** 2) / scale
# one-sided correction: double all bins except DC and Nyquist (nfft even)
Pxx[:, 1:-1] *= 2.0
psd = Pxx.mean(axis=0)
freqs = np.fft.rfftfreq(nfft, d=1.0 / fs)
df = freqs[1] - freqs[0]

mask = (freqs >= 8.0) & (freqs <= 12.0)
alpha_power = float(np.sum(psd[mask]) * df)

result = {"alpha_power_uV2": alpha_power}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
print("n_segments", len(starts), "df", df, "bins", int(mask.sum()))
