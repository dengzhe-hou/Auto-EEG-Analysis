{"alpha_power_uV2": 1.2800000000000002}
