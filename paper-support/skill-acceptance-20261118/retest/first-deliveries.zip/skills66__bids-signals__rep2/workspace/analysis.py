
import json, sys, shutil
import numpy as np, mne
from mne_bids import BIDSPath, write_raw_bids, read_raw_bids
sys.path.insert(0, "/workspace/aea/skills/eeg-bids/scripts")
from events import prepare_event_export, check_exported_events

req = json.load(open("/input/request.json"))["input"]
data = np.asarray(req["data_uV"], dtype=float) * 1e-6
info = mne.create_info(req["channel_names"], req["sfreq"], req["types"])
raw = mne.io.RawArray(data, info, first_samp=req["first_samp"], verbose=False)
raw.info["bads"] = list(req["bads"])
ev = np.asarray(req["events_original_samples"], dtype=int)
out, kw, receipt = prepare_event_export(raw, source="external", event_id=req["event_id"],
                                        additional_annotation_event_id={}, events=ev)
bids_root = "/workspace/bids"
shutil.rmtree(bids_root, ignore_errors=True)
bp = BIDSPath(subject="01", task="check", root=bids_root, datatype="eeg")
out.info["line_freq"] = float(req["line_freq"])
write_raw_bids(out, bp, format="BrainVision", allow_preload=True, overwrite=True,
               events=kw["events"], event_id=kw["event_id"], verbose=False)
import glob as _g, json as _j
side = _g.glob(bids_root + "/sub-01/eeg/*_eeg.json")[0]
sd = _j.load(open(side))
sd["EEGReference"] = "synthetic common reference"
sd["PowerLineFrequency"] = req["line_freq"]
_j.dump(sd, open(side, "w"), indent=2)
import glob
vhdr = glob.glob(bids_root + "/sub-01/eeg/*.vhdr")[0]
back = read_raw_bids(BIDSPath(subject="01", task="check", root=bids_root, datatype="eeg"),
                     verbose=False)
events_back, eid_back = mne.events_from_annotations(back, verbose=False)
rel = [int(s - back.first_samp) for s in events_back[:, 0]]
sidecar = glob.glob(bids_root + "/sub-01/eeg/*_eeg.json")[0]
sc = json.load(open(sidecar))
print("EEGReference", sc.get("EEGReference"), "PowerLineFrequency", sc.get("PowerLineFrequency"))
chk = check_exported_events(glob.glob(bids_root + "/sub-01/eeg/*_events.tsv")[0],
                            receipt=receipt, time_atol_s=1e-6)
result = {"relative_event_samples": rel, "bad_channels": list(back.info["bads"]),
          "sfreq": float(back.info["sfreq"])}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result), chk)
