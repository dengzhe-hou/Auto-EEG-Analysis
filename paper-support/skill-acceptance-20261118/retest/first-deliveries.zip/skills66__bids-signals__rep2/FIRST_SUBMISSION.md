{"relative_event_samples": [113, 256, 381], "bad_channels": [], "sfreq": 128.0}

Files saved:
- /workspace/analysis.py (reusable export program, executed successfully)
- /workspace/result.json
- /workspace/bids/ (EEG-BIDS BrainVision export, subject 01, task check, no session/run)

Verification: sidecar EEGReference = "synthetic common reference", PowerLineFrequency = 50; events TSV check status passed with 3 events.

Note: the installed mne-bids 0.15.0 `write_raw_bids` does not accept `eeg_reference` or `line_freq` keyword arguments, so `line_freq` was set on Raw info and the reference/line-frequency values were written into the `_eeg.json` sidecar directly after export.
