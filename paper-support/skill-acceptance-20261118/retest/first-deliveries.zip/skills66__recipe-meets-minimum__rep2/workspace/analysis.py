
import json

req = json.load(open("/input/request.json"))["input"]

min_channels = 16
min_sfreq = 200
min_trials = 30
required_markers = ["stimulus/related", "stimulus/unrelated"]
recipe_version = "v0.1.0"

counts = req["marker_counts"]
missing_markers = sorted([m for m in required_markers if m not in counts])
insufficient_present_markers = sorted([m for m in required_markers
                                       if m in counts and counts[m] < min_trials])

eligible = (
    len(missing_markers) == 0
    and len(insufficient_present_markers) == 0
    and req["channel_count"] >= min_channels
    and req["sfreq"] >= min_sfreq
)

result = {
    "eligible": bool(eligible),
    "missing_markers": missing_markers,
    "insufficient_present_markers": insufficient_present_markers,
    "recipe_version": recipe_version,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
