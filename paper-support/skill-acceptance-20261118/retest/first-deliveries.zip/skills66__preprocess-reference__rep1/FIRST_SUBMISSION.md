Average reference was applied to the three EEG channels (Fz, Cz, Pz) only. The VEOG channel was left unchanged. The mean across the EEG channels at each sample is ~0 (max |mean| ≈ 5.9e-16). The EOG row equals the input exactly.

Saved:
- /workspace/analysis.py (reusable program, executed)
- /workspace/result.json with fields samples_uV (4 channels × 400 samples, original row order, full precision) and channel_names ["Fz", "Cz", "Pz", "VEOG"]
