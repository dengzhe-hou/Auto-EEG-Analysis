Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-preprocess. Input: /input/request.json. Use its input field.
Apply average reference to EEG only with no projection or optional filtering. Keep EOG unchanged. Report full samples_uV in original row order and channel_names.
Use full numeric precision in result.json. The required fields are samples_uV, channel_names. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
