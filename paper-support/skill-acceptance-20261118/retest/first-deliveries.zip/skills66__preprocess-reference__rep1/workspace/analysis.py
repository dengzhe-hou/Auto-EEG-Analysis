import json
import numpy as np

req = json.load(open("/input/request.json"))
inp = req["input"]
names = inp["names"]
types = inp["types"]
data = np.array(inp["raw_uV"], dtype=float)

eeg_idx = [i for i, t in enumerate(types) if t == "eeg"]
out = data.copy()
mean_ref = data[eeg_idx].mean(axis=0)
out[eeg_idx] = data[eeg_idx] - mean_ref

result = {
    "samples_uV": out.tolist(),
    "channel_names": names,
}
json.dump(result, open("/workspace/result.json", "w"))
