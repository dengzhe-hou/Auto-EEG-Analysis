
import json, numpy as np

req = json.load(open("/input/request.json"))["input"]
X = np.array(req["channel_data_uV"], dtype=float)   # channels x samples, centered data
W = np.array(req["unmixing"], dtype=float)           # components x channels
A = np.array(req["mixing"], dtype=float)             # channels x components
excl = [int(i) for i in req["approved_exclusions"]]

S = W @ X                      # source activations
S_clean = S.copy()
S_clean[excl, :] = 0.0         # zero approved components only
cleaned = A @ S_clean          # reconstruct channels x samples

result = {
    "cleaned_uV": cleaned.tolist(),
    "applied_exclusions": excl,
}
json.dump(result, open("/workspace/result.json", "w"))
