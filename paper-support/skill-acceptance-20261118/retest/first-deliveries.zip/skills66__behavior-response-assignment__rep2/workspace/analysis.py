import json
req = json.load(open('/input/request.json'))
inp = req['input']
stim = list(zip(inp['stimulus_ms'], inp['stimulus_blocks']))
resp = list(zip(inp['response_ms'], inp['response_blocks'], inp['response_ids']))
lo, hi = 100.0, 350.0
used = set(); rt = []
for t, b in stim:
    hit = None
    for r_t, r_b, r_id in sorted(resp, key=lambda x: x[0]):
        if r_b != b or r_id in used: continue
        d = r_t - t
        if lo <= d < hi:
            hit = (r_id, d); break
    if hit is None: rt.append(None)
    else:
        used.add(hit[0]); rt.append(float(hit[1]))
unused = sorted(r_id for _, _, r_id in resp if r_id not in used)
json.dump({'rt_ms': rt, 'unused_response_ids': unused}, open('/workspace/result.json', 'w'), indent=2)
