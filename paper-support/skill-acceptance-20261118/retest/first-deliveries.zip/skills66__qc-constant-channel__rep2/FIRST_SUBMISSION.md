Results saved to /workspace/result.json (program: /workspace/analysis.py, helper copied to /workspace/qc_amplitude.py).

{
  "constant_channels": ["Cz"],
  "rapid_change_channels": [],
  "bad_channel_candidates": ["Cz"],
  "per_channel": {
    "Fz": {"constant_fraction": 0.0, "jump_fraction": 0.0, "candidate_reasons": []},
    "Cz": {"constant_fraction": 1.0, "jump_fraction": 0.0, "candidate_reasons": ["constant"]}
  },
  "low_amplitude_warnings": "10 windows (reported in result.json; not used for bad-channel candidacy)",
  "ignored_tail_samples": 0
}
