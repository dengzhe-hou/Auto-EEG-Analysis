
import json

req = json.load(open("/input/request.json"))["input"]
deps = req["dependencies"]
status = req["status"]

reused, runnable, blocked = set(), set(), set()
passed = lambda s: status.get(s) == "passed"

# Resolve in topological order
order = []
seen = set()
def visit(s):
    if s in seen:
        return
    for d in deps.get(s, []):
        visit(d)
    seen.add(s)
    order.append(s)
for s in deps:
    visit(s)

bad = set()  # stages that are failed or blocked (not passing downstream)
for s in order:
    st = status.get(s, "pending")
    if st == "passed":
        reused.add(s)
    elif st == "failed":
        blocked.add(s)
        bad.add(s)
    else:
        if any(d in bad or not passed(d) for d in deps.get(s, [])):
            blocked.add(s)
            bad.add(s)
        else:
            runnable.add(s)

result = {
    "reused": sorted(reused),
    "runnable": sorted(runnable),
    "blocked": sorted(blocked),
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(result)
