
import json

def decide(graph):
    deps = graph["dependencies"]
    status = graph["status"]
    reused, runnable, blocked = [], [], []
    for stage in sorted(deps):
        s = status.get(stage, "pending")
        if s == "passed":
            reused.append(stage)
            continue
        if s == "failed":
            blocked.append(stage)
            continue
        # pending: runnable only if all direct deps passed
        if all(status.get(d) == "passed" for d in deps[stage]):
            runnable.append(stage)
        else:
            blocked.append(stage)
    return {
        "reused": sorted(reused),
        "runnable": sorted(runnable),
        "blocked": sorted(blocked),
    }

if __name__ == "__main__":
    with open("/input/request.json") as f:
        req = json.load(f)
    result = decide(req["input"])
    with open("/workspace/result.json", "w") as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result))
