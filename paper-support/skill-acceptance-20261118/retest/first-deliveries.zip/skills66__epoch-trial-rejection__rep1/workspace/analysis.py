
import json
import numpy as np
import mne

req = json.load(open("/input/request.json"))["input"]
sfreq = float(req["sfreq"])
ch_names = req["channel_names"]
data_uV = np.array(req["raw_uV"], dtype=float)
data_V = data_uV * 1e-6  # uV -> V

info = mne.create_info(ch_names=ch_names, sfreq=sfreq, ch_types="eeg")
raw = mne.io.RawArray(data_V, info, verbose=False)

events = np.array(req["events"], dtype=int)
event_id = req["event_id"]
tmin = float(req["tmin"])
tmax = float(req["tmax"])
baseline = req["baseline"]
baseline = None if baseline is None else tuple(baseline)

reject = None
if req.get("reject_peak_to_peak_uV") is not None:
    reject = dict(eeg=float(req["reject_peak_to_peak_uV"]) * 1e-6)

epochs = mne.Epochs(raw, events, event_id=event_id, tmin=tmin, tmax=tmax,
                    baseline=baseline, reject=reject, preload=True,
                    verbose=False, reject_by_annotation=False)

n_total = len(events)
retained_event_samples = [int(s) for s in epochs.events[:, 0]]
n_dropped = int(n_total - len(epochs))
times_s = [float(t) for t in epochs.times]

epochs.save("/workspace/check-epo.fif", overwrite=True, verbose=False)

result = {
    "retained_event_samples": retained_event_samples,
    "times_s": times_s,
    "n_dropped": n_dropped,
}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
