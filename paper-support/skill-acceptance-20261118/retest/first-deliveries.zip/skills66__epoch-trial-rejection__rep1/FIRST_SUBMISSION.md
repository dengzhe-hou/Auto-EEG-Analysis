Epoching is complete. The script is saved at /workspace/analysis.py, epochs are saved to /workspace/check-epo.fif, and results are saved to /workspace/result.json.

Results:
- retained_event_samples: [35, 114]
- times_s: 31 values from -0.1 to 0.2 s in 0.01 s steps (inclusive)
- n_dropped: 1 (one of three events was rejected by the 75 µV peak-to-peak threshold applied to EEG channels only)
