
import json, glob, os, sys, numpy as np, mne
from mne_bids import BIDSPath, write_raw_bids, read_raw_bids
sys.path.insert(0, "/workspace/aea/skills/eeg-bids/scripts")
from events import prepare_event_export

req = json.load(open("/input/request.json"))["input"]
data = np.array(req["data_uV"], dtype=float) * 1e-6
info = mne.create_info(req["channel_names"], req["sfreq"], req["types"])
raw = mne.io.RawArray(data, info, first_samp=req["first_samp"], verbose=False)
raw.info["bads"] = list(req["bads"])
raw.info["line_freq"] = req["line_freq"]

events = np.array(req["events_original_samples"], dtype=int)
out, write_kw, receipt = prepare_event_export(
    raw, source="external", event_id=req["event_id"],
    additional_annotation_event_id={}, events=events)
out.info["line_freq"] = req["line_freq"]

bids_root = "/workspace/bids"
bp = BIDSPath(subject="01", task="check", root=bids_root, datatype="eeg")
write_raw_bids(out, bp, overwrite=True, allow_preload=True, format="BrainVision",
               events=write_kw["events"], event_id=write_kw["event_id"], verbose=False)

vhdr = glob.glob(os.path.join(bids_root, "sub-01", "eeg", "*_eeg.vhdr"))[0]
eegjson = vhdr.replace("_eeg.vhdr", "_eeg.json")
side = json.load(open(eegjson))
side["EEGReference"] = "synthetic common reference"
side["PowerLineFrequency"] = req["line_freq"]
json.dump(side, open(eegjson, "w"), indent=4)
side = json.load(open(eegjson))
assert side["EEGReference"] == "synthetic common reference"
assert side["PowerLineFrequency"] == req["line_freq"]

rb = read_raw_bids(bp, verbose=False)
ev, eid = mne.events_from_annotations(rb, verbose=False)
rel_samples = [int(s) for s in ev[:, 0] - rb.first_samp]
result = {
    "relative_event_samples": rel_samples,
    "bad_channels": list(rb.info["bads"]),
    "sfreq": float(rb.info["sfreq"]),
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
