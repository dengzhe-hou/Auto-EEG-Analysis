
import json, sys
from pathlib import Path
import numpy as np
import mne
sys.path.insert(0, str(Path(__file__).resolve().parent))
from qc_amplitude import amplitude_qc

req = json.load(open("/input/request.json"))["input"]
sfreq = float(req["sfreq"])
names = list(req["channel_names"])
data_v = np.asarray(req["signal_uV"], dtype=float) * 1e-6
info = mne.create_info(names, sfreq, ch_types=["eeg"] * len(names))
raw = mne.io.RawArray(data_v, info, verbose=False)

amp = amplitude_qc(
    raw,
    constant_min_duration=0.020,
    low_amplitude_window=0.100,
    low_amplitude_ptp=0.5e-6,
    jump_threshold=150e-6,
    jump_min_duration=0.005,
    bad_percent=5.0,
)
constant_channels = sorted({s["channel"] for s in amp["constant_segments"]})
rapid_change_channels = sorted({s["channel"] for s in amp["jump_segments"]})
bad_channel_candidates = sorted(amp["bad_channel_candidates"])
result = {
    "constant_channels": constant_channels,
    "rapid_change_channels": rapid_change_channels,
    "bad_channel_candidates": bad_channel_candidates,
}
Path("/workspace/result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
Path("/workspace/analysis/amplitude_findings.json").write_text(json.dumps(amp, indent=2), encoding="utf-8")
print(json.dumps(result))
