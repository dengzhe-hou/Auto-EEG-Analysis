Result saved to /workspace/result.json (program: /workspace/analysis.py, copied helper: /workspace/analysis/qc_amplitude.py, full findings: /workspace/analysis/amplitude_findings.json).

{
  "constant_channels": [],
  "rapid_change_channels": [],
  "bad_channel_candidates": []
}

Checks: Fz and Cz each had constant_fraction 0.0 and jump_fraction 0.0 (5% criterion not exceeded), and no constant, jump, or low-amplitude segments were found. Amplitude was converted from uV to V before QC, and no cleaning or annotation changes were applied.
