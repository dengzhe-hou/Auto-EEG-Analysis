Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-figure. Input: /input/request.json. Use its input field.
Render the supplied data as a line in Matplotlib, using figsize=(4,3), fig.add_axes([.2,.2,.6,.6]), xlim=(-1,5), ylim=(-3,3), and the supplied axis labels. Set line gid="aea-data". Save fig.svg without tight crop, so the actual SVG data path can be read back. Return n_points and x_label and y_label.
Use full numeric precision in result.json. The required fields are n_points, x_label, y_label. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
