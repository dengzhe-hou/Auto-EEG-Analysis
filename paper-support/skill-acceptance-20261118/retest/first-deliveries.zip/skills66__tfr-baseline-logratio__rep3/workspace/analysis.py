
import json, numpy as np
import mne
from mne.time_frequency import tfr_array_morlet

req = json.load(open("/input/request.json"))["input"]
X = np.array(req["epochs_uV"], dtype=float)   # (trials, channels, times) in uV
sfreq = float(req["sfreq"])
tmin = float(req["tmin"])
idx = np.array(req["sample_indices"], dtype=int)
channels = req["channels"]

n_trials, n_ch, n_times = X.shape
times = tmin + np.arange(n_times) / sfreq

freqs = np.array([10.0])
n_cycles = np.array([5.0])

# power per trial: (trials, channels, freqs, times), uV^2 preserved
tfr = tfr_array_morlet(X, sfreq=sfreq, freqs=freqs, n_cycles=n_cycles,
                       output="power", zero_mean=True, decim=1, n_jobs=1)
power = tfr[:, :, 0, :].mean(axis=0)   # average over trials -> (channels, times)

# baseline: inclusive [-0.5, -0.125] s, mean power per channel
bmask = (times >= -0.5 - 1e-12) & (times <= -0.125 + 1e-12)
base = power[:, bmask].mean(axis=1, keepdims=True)

logr = np.log10(power / base)
values = logr[:, idx]
times_s = times[idx]

result = {"values": values.tolist(), "times_s": times_s.tolist()}
with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)
print(values.shape, times_s)
