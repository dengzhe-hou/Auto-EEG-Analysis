
import json
import numpy as np

req = json.load(open("/input/request.json"))["input"]
raw = np.asarray(req["raw_uV"], dtype=float)
names = list(req["names"])
pick = list(req["pick"])
start, stop = int(req["samples"][0]), int(req["samples"][1])

idx = [names.index(p) for p in pick]
sel = raw[idx, :]
cropped = sel[:, start:stop]

result = {
    "samples_uV": cropped.tolist(),
    "channel_names": pick,
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(cropped.shape)
