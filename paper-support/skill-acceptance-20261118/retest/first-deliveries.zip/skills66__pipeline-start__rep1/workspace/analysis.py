
import json

def decide(request):
    deps = request["input"]["dependencies"]
    status = request["input"].get("status", {})
    passed = {s for s, v in status.items() if v == "passed"}
    failed = {s for s, v in status.items() if v == "failed"}
    reused, runnable, blocked = [], [], []
    for stage in sorted(deps):
        if stage in passed:
            reused.append(stage)
            continue
        if stage in failed:
            blocked.append(stage)
            continue
        unmet = [d for d in deps[stage] if d not in passed]
        if unmet:
            blocked.append(stage)
        else:
            runnable.append(stage)
    return {
        "reused": sorted(reused),
        "runnable": sorted(runnable),
        "blocked": sorted(blocked),
    }

if __name__ == "__main__":
    with open("/input/request.json") as f:
        req = json.load(f)
    result = decide(req)
    with open("/workspace/result.json", "w") as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result))
