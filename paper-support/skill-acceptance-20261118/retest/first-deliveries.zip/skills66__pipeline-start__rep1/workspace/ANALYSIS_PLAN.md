Run this approved, small engineering test of an EEG skill.
Assigned skill: eeg-pipeline. Input: /input/request.json. Use its input field.
Produce the execution decision for this declared stage graph and saved status receipts. Reuse only passed stages, start only pending stages whose direct dependencies passed, and put failed and dependency-blocked stages in blocked. A failed stage awaits review in this plan. Return sorted lists reused, runnable, blocked. Only the next execution decision is requested. In this readiness summary, blocked includes every stage that currently has an unmet dependency, even when that predecessor is pending or runnable.
Use full numeric precision in result.json. The required fields are reused, runnable, blocked. Save /workspace/result.json.
Save the actual reusable program as /workspace/analysis.py and execute that saved
program. Save named artifacts directly under /workspace at the requested paths.
Use the installed AEA resource, starting with the selected skill below and the matching
sections of its references in /workspace/aea. You may read linked helper resources.
Your result should be based on executing the program and inspecting its outputs.
All task settings are specified for these synthetic inputs. Do not add analysis
steps or request new scientific decisions. This is a bounded operation, with no
external reviewer or network service. Use bare Python in <execute> and send the
final <solution> after finishing. Finish by following the requested deliverables.
