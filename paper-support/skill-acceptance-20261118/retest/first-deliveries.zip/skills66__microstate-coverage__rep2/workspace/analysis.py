import json
import numpy as np

labels = json.load(open("/input/request.json"))["input"]["labels"]
arr = np.asarray(labels)
labeled = arr[arr >= 0]
n_labeled = int(labeled.size)
coverage_pct = [float(np.sum(labeled == k) / n_labeled * 100.0) for k in (0, 1, 2)]
result = {"coverage_pct": coverage_pct, "n_labeled": n_labeled}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(result)
