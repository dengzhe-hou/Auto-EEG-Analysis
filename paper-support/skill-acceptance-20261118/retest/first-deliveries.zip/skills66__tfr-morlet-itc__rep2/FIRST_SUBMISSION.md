The analysis is complete. The program is saved at /workspace/analysis.py and was executed; the result is saved at /workspace/result.json.

Method: MNE tfr_array_morlet on the supplied epochs (uV converted to V), freq 10 Hz, n_cycles 5, decim=1, zero_mean=True, output="complex". ITC = |mean over trials of (coef/|coef|)| per channel, with no further preprocessing. Times are tmin + sample_index/sfreq with tmin=-1 s, sfreq=128 Hz.

Result (channels Fz, Cz × sample_indices [144, 156, 180, 220, 270]):
- values: [[0.9928883764737766, 0.9957803175470118, 0.998854417308005, 0.9892431041269778, 0.9923586133835554], [0.9995949711728874, 0.9990756043280258, 0.9992166389980843, 0.9980671154621756, 0.9958783502597773]]
- times_s: [0.125, 0.21875, 0.40625, 0.71875, 1.109375]

Caveat: only 4 trials were supplied, and ITC is biased upward with few trials, so these high values should be read with that in mind.
