
import json, numpy as np
import mne
from mne.time_frequency import tfr_array_morlet

req = json.load(open("/input/request.json"))["input"]
epochs_uV = np.asarray(req["epochs_uV"], dtype=float)   # (trials, channels, times)
sfreq = float(req["sfreq"])
tmin = float(req["tmin"])
sample_indices = list(req["sample_indices"])

# uV -> V for MNE (SI units); ITC is unitless
epochs_V = epochs_uV * 1e-6

freqs = np.array([10.0])
n_cycles = np.array([5.0])

# complex coefficients: (trials, channels, freqs, times)
coef = tfr_array_morlet(
    epochs_V, sfreq=sfreq, freqs=freqs, n_cycles=n_cycles,
    output="complex", decim=1, zero_mean=True, n_jobs=1,
)[:, :, 0, :]

# ITC = |mean_trials(coef / |coef|)|
phase = coef / np.abs(coef)
itc = np.abs(phase.mean(axis=0))   # (channels, times)

n_times = epochs_uV.shape[-1]
times_s = tmin + np.arange(n_times) / sfreq

idx = np.asarray(sample_indices, dtype=int)
values = itc[:, idx]
times_sel = times_s[idx]

result = {
    "values": values.tolist(),
    "times_s": [float(t) for t in times_sel],
}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print("values shape:", values.shape)
print("times_s:", result["times_s"])
