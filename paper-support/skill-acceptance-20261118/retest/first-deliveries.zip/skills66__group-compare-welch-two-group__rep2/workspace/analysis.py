import json
import numpy as np
from scipy import stats

with open("/input/request.json") as f:
    req = json.load(f)

inp = req["input"]
group_a = np.asarray(inp["group_a"], dtype=float)
group_b = np.asarray(inp["group_b"], dtype=float)

t_stat, p_val = stats.ttest_ind(group_a, group_b, equal_var=False, alternative="two-sided")

result = {
    "statistic": float(t_stat),
    "p_value": float(p_val),
    "n_per_group": [int(group_a.size), int(group_b.size)],
}

with open("/workspace/result.json", "w") as f:
    json.dump(result, f, indent=2)

print(json.dumps(result, indent=2))
