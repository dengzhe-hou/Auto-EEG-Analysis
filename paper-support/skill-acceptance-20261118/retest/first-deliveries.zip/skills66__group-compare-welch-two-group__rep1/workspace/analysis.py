import json
import numpy as np
from scipy import stats

req = json.load(open("/input/request.json"))
inp = req["input"]
a = np.asarray(inp["group_a"], dtype=float)
b = np.asarray(inp["group_b"], dtype=float)

res = stats.ttest_ind(a, b, equal_var=False, alternative="two-sided")
out = {
    "statistic": float(res.statistic),
    "p_value": float(res.pvalue),
    "n_per_group": [int(a.size), int(b.size)],
}
json.dump(out, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(out, indent=2))
