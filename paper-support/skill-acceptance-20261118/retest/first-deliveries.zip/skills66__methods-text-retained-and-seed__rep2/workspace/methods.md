# Methods

EEG was recorded at a sampling rate of 250 Hz with reference: not recorded. Data were band-pass filtered between 0.2 and 35 Hz. Of 22 trials, 7 were excluded, leaving 15 retained trials. Random seed 75 was used (planned seed 14). Epochs spanned -0.14 s to 0.68 s relative to event onset.

sampling_hz = 250.0
reference = not recorded
retained_trials = 15
seed = 75
epoch_start_s = -0.14
epoch_end_s = 0.68
