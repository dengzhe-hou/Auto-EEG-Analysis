
import json

req = json.load(open("/input/request.json"))["input"]
acq = req["acquisition"]
ex = req["execution"]

sfreq = float(acq["sampling_hz"])
reference = acq["reference"] if acq["reference"] is not None else "not recorded"
retained_trials = int(ex["n_trials"]) - int(ex["n_excluded"])
seed = int(ex["executed_seed"])
epoch_start_s = float(ex["epoch_start_sample"]) / sfreq
epoch_end_s = float(ex["epoch_end_sample"]) / sfreq

result = {
    "sampling_hz": sfreq,
    "reference": reference,
    "retained_trials": retained_trials,
    "seed": seed,
    "epoch_start_s": epoch_start_s,
    "epoch_end_s": epoch_end_s,
}

json.dump(result, open("/workspace/result.json", "w"), indent=2)

paragraph = (
    f"EEG was recorded at a sampling rate of {sfreq:g} Hz with reference: {reference}. "
    f"Data were band-pass filtered between {ex['band_hz'][0]} and {ex['band_hz'][1]} Hz. "
    f"Of {ex['n_trials']} trials, {ex['n_excluded']} were excluded, leaving {retained_trials} retained trials. "
    f"Random seed {seed} was used (planned seed {ex['planned_seed']}). "
    f"Epochs spanned {epoch_start_s:g} s to {epoch_end_s:g} s relative to event onset."
)

lines = [
    "# Methods",
    "",
    paragraph,
    "",
    f"sampling_hz = {sfreq!r}",
    f"reference = {reference}",
    f"retained_trials = {retained_trials!r}",
    f"seed = {seed!r}",
    f"epoch_start_s = {epoch_start_s!r}",
    f"epoch_end_s = {epoch_end_s!r}",
    "",
]
open("/workspace/methods.md", "w").write("\n".join(lines))
print(json.dumps(result, indent=2))
