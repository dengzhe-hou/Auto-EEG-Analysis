Saved /workspace/analysis.py, /workspace/methods.md, and /workspace/result.json.

Methods paragraph (methods.md):
EEG was acquired at 250 Hz with online reference: not recorded. Data were band-pass filtered between 0.2 and 35 Hz. Epochs spanned -0.12 s to 0.64 s relative to event onset. 16 trials were retained after excluding 5 of 21. The executed random seed was 74 (planned seed 14).

result.json:
{
  "sampling_hz": 250,
  "reference": "not recorded",
  "retained_trials": 16,
  "seed": 74,
  "epoch_start_s": -0.12,
  "epoch_end_s": 0.64
}
