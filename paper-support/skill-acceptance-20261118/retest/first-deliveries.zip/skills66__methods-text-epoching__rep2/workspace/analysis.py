import json
req = json.load(open("/input/request.json"))["input"]
acq, ex = req["acquisition"], req["execution"]
sampling_hz = acq["sampling_hz"]
reference = acq["reference"] if acq["reference"] is not None else "not recorded"
retained_trials = ex["n_trials"] - ex["n_excluded"]
seed = ex["executed_seed"]
epoch_start_s = ex["epoch_start_sample"] / sampling_hz
epoch_end_s = ex["epoch_end_sample"] / sampling_hz
result = {"sampling_hz": sampling_hz, "reference": reference, "retained_trials": retained_trials,
          "seed": seed, "epoch_start_s": epoch_start_s, "epoch_end_s": epoch_end_s}
paragraph = (f"EEG was acquired at {sampling_hz} Hz with online reference: {reference}. "
    f"Data were band-pass filtered between {ex['band_hz'][0]} and {ex['band_hz'][1]} Hz. "
    f"Epochs spanned {epoch_start_s} s to {epoch_end_s} s relative to event onset. "
    f"{retained_trials} trials were retained after excluding {ex['n_excluded']} of {ex['n_trials']}. "
    f"The executed random seed was {seed} (planned seed {ex['planned_seed']}).")
lines = [paragraph, ""] + [f"{k} = {v}" for k, v in result.items()]
open("/workspace/methods.md", "w").write("\n".join(lines) + "\n")
json.dump(result, open("/workspace/result.json", "w"), indent=2)
