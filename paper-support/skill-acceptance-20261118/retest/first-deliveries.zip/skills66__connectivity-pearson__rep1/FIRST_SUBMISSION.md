The analysis program is saved at /workspace/analysis.py and was executed. It computed continuous Pearson correlations over the full supplied signal with no preprocessing, and the result is saved at /workspace/result.json.

{
  "edges": [
    -0.971270995623145,
    0.7417381199564247,
    -0.6282808624375432
  ]
}

The edges are, in order: Fz-Cz, Fz-Pz, Cz-Pz.
