import json
import numpy as np

req = json.load(open("/input/request.json"))["input"]
channels = req["channels"]
signal = np.array(req["signal"], dtype=float)
ch_index = {c: i for i, c in enumerate(channels)}
corr = np.corrcoef(signal)
pairs = [("Fz", "Cz"), ("Fz", "Pz"), ("Cz", "Pz")]
edges = [float(corr[ch_index[a], ch_index[b]]) for a, b in pairs]
result = {"edges": edges}
json.dump(result, open("/workspace/result.json", "w"), indent=2)
print(json.dumps(result))
