{"pattern_counts": [5, 6, 7, 6, 7, 8], "normalized_perm_entropy": 0.9938995258030404}
