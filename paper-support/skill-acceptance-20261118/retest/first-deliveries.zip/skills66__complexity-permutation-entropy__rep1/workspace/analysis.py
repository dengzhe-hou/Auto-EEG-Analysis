
import json, math, itertools
from collections import Counter

def permutation_entropy_counts(x, order=3, delay=1):
    perms = list(itertools.permutations(range(order)))  # lexicographic
    counts = Counter()
    n = len(x) - (order - 1) * delay
    for i in range(n):
        window = [x[i + j * delay] for j in range(order)]
        # ordinal pattern: argsort of window
        pattern = tuple(sorted(range(order), key=lambda k: (window[k], k)))
        counts[pattern] += 1
    pattern_counts = [counts.get(p, 0) for p in perms]
    total = sum(pattern_counts)
    probs = [c / total for c in pattern_counts if c > 0]
    H = -sum(p * math.log(p) for p in probs)
    normalized = H / math.log(math.factorial(order))
    return pattern_counts, normalized

if __name__ == "__main__":
    req = json.load(open("/input/request.json"))
    series = req["input"]["series"]
    pattern_counts, npe = permutation_entropy_counts(series, order=3, delay=1)
    result = {
        "pattern_counts": pattern_counts,
        "normalized_perm_entropy": npe,
    }
    with open("/workspace/result.json", "w") as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result))
