
import json
import os

def audit(path_in="/input/request.json", path_out="/workspace/result.json"):
    with open(path_in) as f:
        data = json.load(f)["input"]
    plan = data["analysis_plan"]
    receipt = data["execution_receipt"]
    fields = ["roi", "window_ms", "contrast", "observation_unit", "unit", "correction"]
    issues = sorted([k for k in fields if plan.get(k) != receipt.get(k)])
    verdict = "pass" if not issues else "fail"
    result = {"verdict": verdict, "issues": issues}
    os.makedirs(os.path.dirname(path_out), exist_ok=True)
    with open(path_out, "w") as f:
        json.dump(result, f, indent=2)
    return result

if __name__ == "__main__":
    print(audit())
